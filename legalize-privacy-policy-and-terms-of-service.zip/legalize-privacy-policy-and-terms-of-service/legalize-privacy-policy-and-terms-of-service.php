<?php
/** 
Plugin Name: Legalize! Privacy Policy and Terms of Service Generator
Plugin URI: http://codecanyon.net/user/CodeRevolution/portfolio
Description: This plugin automatically generate a Privacy Policy and a Terms of Service page, compliant with both US and UK cookie law (EU cookie directive) + eu cookie consent popup
Author: CodeRevolution
Version: 1.4
Author URI: https://codecanyon.net/user/CodeRevolution
*/
defined( 'ABSPATH' ) or die();
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/privacy/master/info.json", __FILE__, "legalize-privacy-policy-and-terms-of-service");
add_action('admin_menu', 'privacy_register_my_custom_menu_page');
add_action('network_admin_menu', 'privacy_register_my_custom_menu_page');
function privacy_register_my_custom_menu_page()
{
    add_menu_page('Legalize! Privacy Policy and Terms of Service Generator', 'Legalize! Privacy Policy and Terms of Service Generator', 'manage_options', 'privacy_admin_settings', 'privacy_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('privacy_admin_settings', 'Privacy Policy Settings', 'Privacy Policy Settings', 'manage_options', 'privacy_admin_settings');
    add_submenu_page("privacy_admin_settings", "Terms of Service Settings", "Terms of Service Settings", 'manage_options', "privacy_terms_settings", "privacy_terms_settings");
    add_submenu_page("privacy_admin_settings", "Cookie Consent Policy", "Cookie Consent Policy", 'manage_options', "privacy_fortune_cookie", "privacy_fortune_cookie");
    add_submenu_page("privacy_admin_settings", "Publish Changes", "Publish Changes", 'manage_options', "privacy_publish", "privacy_publish");
}

add_shortcode("legalize_get_cookies_opt_out_button", "legalize_get_cookies_opt_out_button");
function legalize_get_cookies_opt_out_button()
{
    $fortune_Main_Settings        = get_option('legalize_fortune_Main_Settings', false);
    if (isset($fortune_Main_Settings['fortune_cookie_accept_delete_text'])) {
        $fortune_cookie_accept_delete_text = $fortune_Main_Settings['fortune_cookie_accept_delete_text'];
    } else {
        $fortune_cookie_accept_delete_text = '';
    }
    if (isset($fortune_Main_Settings['fortune_cookie_delete_text'])) {
        $fortune_cookie_delete_text = $fortune_Main_Settings['fortune_cookie_delete_text'];
    } else {
        $fortune_cookie_delete_text = '';
    }
    $cookieCode ='<script>function fortune_delete_all_cookies(){if (confirm("' . $fortune_cookie_accept_delete_text . '") == true) {var data = {action: "fortune_my_action"};jQuery.post(ajaxurl, data, function(response) {location.reload();});}}</script><input type="button" id="fortune_clear_all_cookies" value="' . $fortune_cookie_delete_text . '" name="fortune_clear_all_cookies" onclick="fortune_delete_all_cookies()">';
    return $cookieCode;
}

function legalize_fortune_ajaxurl() {

    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
add_action('wp_head', 'legalize_fortune_ajaxurl');

$COOKIE_SET = 'false';
$dntEnabled = false;

register_activation_hook(__FILE__, 'legalize_fortune_check_version');
function legalize_fortune_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.3';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

function legalize_fortune_blocked_no_cookies()
{
    $fortune_Main_Settings        = get_option('legalize_fortune_Main_Settings', false);
    if (isset($fortune_Main_Settings['fortune_blocked_content_text'])) {
        $fortune_blocked_content_text = $fortune_Main_Settings['fortune_blocked_content_text'];
    } else {
        $fortune_blocked_content_text = '';
    }
    return $fortune_blocked_content_text;
}

function legalize_fortune_blocked_cookies($atts, $content = null)
{
    return $content;
}

function privacy_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=privacy_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
$plugin = plugin_basename(__FILE__);

add_action('wp_ajax_privacy_my_action', 'privacy_my_action_callback');
add_action('wp_ajax_terms_my_action', 'terms_my_action_callback');
function privacy_my_action_callback()
{
    legalize_my_plugin_install();
    echo "0";
    die();
}

register_activation_hook(__FILE__, 'legalize_fortune_activation_callback');
function legalize_fortune_activation_callback($default = FALSE)
{
    $fortune_Main_Settings = array(
        'fortune_enabled' => 'off',
        'fortune_popup_once' => 'on',
        'fortune_popup_style' => 'fortune_panel_top',
        'fortune_close_message' => 'Accept',
        'fortune_message' => 'This site uses cookies to deliver its services. By using this site, you agree to its use of cookies.',
        'fortune_more_info' => 'on',
        'fortune_more_link' => 'https://www.google.com/policies/technologies/cookies/',
        'fortune_popup_background' => '#aaaaaa',
        'fortune_popup_text_col' => '#3f4c52',
        'fortune_popup_links_col' => '#0000ff',
        'fortune_panel_sticks' => 'on',
        'fortune_more_link_text' => 'More Info',
        'fortune_auto_hide' => 'off',
        'fortune_auto_hide_time' => '5000',
        'fortune_border' => 'off',
        'fortune_border_color' => '#ff0000',
        'fortune_border_width' => '3px',
        'fortune_buttons' => 'on',
        'fortune_popup_animation' => 'fortune_fade_anim',
        'fortune_max_width' => '',
        'fade_background' => 'on',
        'fortune_only_eu' => 'off',
        'fortune_block_cookies' => 'off',
        'fortune_blocked_content' => 'on',
        'fortune_deny_button_text' => 'Deny',
        'fortune_deny_button' => 'off',
        'fortune_block_all_cookies' => 'off',
        'fortune_disable_loggedin' => 'off',
        'fortune_custom_css' => '',
        'fortune_rounded_corners' => 'on',
        'fortune_distance_right' => '0px',
        'fortune_distance_left' => '0px',
        'fortune_distance_bottom' => 'auto',
        'fortune_distance_top' => '0px',
        'fortune_padding' => '10px',
        'fortune_new_line' => 'off',
        'fortune_auto_accept' => 'off',
        'fortune_outside_close_accept' => 'on',
        'fortune_outside_close' => 'on',
        'fortune_center_popup' => 'on',
        'fortune_advanced_settings' => 'off',
        'fortune_new_line_all' => 'off',
        'fortune_popup_background_style' => 'fortune_color',
        'fortune_popup_background_image' => '',
        'fortune_max_height' => '',
        'fortune_font_size' => '14px',
        'fortune_font_type' => 'Helvetica, Arial, sans-serif',
        'fortune_button_background' => '#aaaaaa',
        'fortune_cookie_exp' => '1440',
        'fortune_button_border' => '#0000ff',
        'fortune_fonts_bold' => 'off',
        'fortune_fonts_italic' => 'off',
        'fortune_fonts_underline' => 'off',
        'fortune_cookie_accept_delete_text' => 'Are you sure you want to change your mind about cookie consent policy?',
        'fortune_cookie_delete_text' => 'Show cookiebar again',
        'fortune_dnt_check' => 'on'
    );
    if (!get_option('legalize_fortune_Main_Settings')) {
        add_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
    } else {
        if($default)
        {
            delete_option('legalize_fortune_Main_Settings');
            add_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
        }
    }
}

function terms_my_action_callback()
{
    terms_my_plugin_install();
    echo "0";
    die();
}
add_shortcode("legalize_privacy", "legalize_shortcode_privacy");

function legalize_shortcode_privacy()
{
    return "<a href='" . get_page_link(get_option("privacy_policy_id")) . "' target='_blank'>Privacy Policy</a>";
}

add_shortcode("legalize_terms", "legalize_shortcode_terms");

function legalize_shortcode_terms()
{
    return "<a href='" . get_page_link(get_option("terms_policy_id")) . "' target='_blank'>Terms of Service</a>";
}
function legalize_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'legalize_activation_callback');
function legalize_activation_callback($default = FALSE)
{
    $privacy_Main_Settings = array(
        'privacy_collect_data' => 'pri_YES',
        'privacy_enabled' => 'on',
        'privacy_share_data_partners' => 'pri_NO',
        'privacy_share_data_ads' => 'pri_NO',
        'privacy_share_data_unlimited' => 'pri_NO',
        'privacy_share_data_agr' => 'pri_NO',
        'privacy_share_data' => 'pri_NO',
        'privacy_california' => 'pri_NO',
        'privacy_ssl' => 'pri_NO',
        'privacy_ads' => 'pri_NO',
        'privacy_adsense' => 'pri_NO',
        'privacy_cookies' => 'pri_YES',
        'privacy_pass' => 'pri_YES',
        'privacy_arb' => 'pri_NO',
        'privacy_child' => 'pri_NO',
        'privacy_owner_loc' => '',
        'privacy_owner_email' => '',
        'privacy_email' => '',
        'privacy_mail' => '',
        'privacy_added_text' => '',
        'language' => 'English'
    );
    if (!get_option('privacy_Main_Settings')) {
        add_option('privacy_Main_Settings', $privacy_Main_Settings);
    } else {
        if($default)
        {
            delete_option('privacy_Main_Settings');
            add_option('privacy_Main_Settings', $privacy_Main_Settings);
        }
    }
    $privacy_Terms_Settings = array(
        'terms_enabled' => 'on',
        'privacy_owner_name' => '',
        'privacy_owner_type' => 'Individual',
        'privacy_dmca' => 'pri_NO',
        'privacy_dmca_address' => '',
        'privacy_dmca_phone' => '',
        'privacy_dmca_email' => '',
        'terms_owner_email_address' => '',
        'terms_owner_locality' => '',
        'terms_ads' => 'pri_NO',
        'terms_major' => 'pri_YES',
        'terms_arbitration' => 'pri_NO',
        'terms_added_text' => '',
        'language' => 'English',
        'login_checkbox' => '',
        'register_checkbox' => '',
        'login_checkbox_error_text' => 'You must agree to our Terms of Service before you continue',
        'login_checkbox_text' => 'I agree to this website\'s Terms of Service',
        'login_checkbox_newline' => '',
        'login_checkbox_link' => '',
        'register_checkbox_error_text' => 'You must agree to our Terms of Service before you continue',
        'register_checkbox_text' => 'I agree to this website\'s Terms of Service',
        'register_checkbox_newline' => '',
        'register_checkbox_link' => ''
    );
    if (!get_option('privacy_Terms_Settings')) {
        add_option('privacy_Terms_Settings', $privacy_Terms_Settings);
    } else {
        if($default)
        {
            delete_option('privacy_Terms_Settings');
            add_option('privacy_Terms_Settings', $privacy_Terms_Settings);
        }
    }
}

function terms_my_plugin_install()
{
    global $wpdb;
    $the_page_title         = 'Terms of Service';
    $the_page               = get_page_by_title($the_page_title);
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    if (isset($privacy_Terms_Settings['terms_enabled'])) {
        $terms_enabled = $privacy_Terms_Settings['terms_enabled'];
    } else {
        $terms_enabled = '';
    }
    if (isset($privacy_Terms_Settings['terms_added_text'])) {
        $terms_added_text = $privacy_Terms_Settings['terms_added_text'];
    } else {
        $terms_added_text = '';
    }
    if (isset($privacy_Terms_Settings['privacy_owner_type'])) {
        $privacy_owner_type = $privacy_Terms_Settings['privacy_owner_type'];
    } else {
        $privacy_owner_type = 'Individual';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca'])) {
        $privacy_dmca = $privacy_Terms_Settings['privacy_dmca'];
    } else {
        $privacy_dmca = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_address'])) {
        $privacy_dmca_address = $privacy_Terms_Settings['privacy_dmca_address'];
    } else {
        $privacy_dmca_address = '';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_phone'])) {
        $privacy_dmca_phone = $privacy_Terms_Settings['privacy_dmca_phone'];
    } else {
        $privacy_dmca_phone = '';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_email'])) {
        $privacy_dmca_email = $privacy_Terms_Settings['privacy_dmca_email'];
    } else {
        $privacy_dmca_email = '';
    }
    if (isset($privacy_Terms_Settings['privacy_owner_name'])) {
        $privacy_owner_name = $privacy_Terms_Settings['privacy_owner_name'];
    } else {
        $privacy_owner_name = '';
    }
    if (isset($privacy_Terms_Settings['terms_owner_email_address'])) {
        $terms_owner_email_address = $privacy_Terms_Settings['terms_owner_email_address'];
    } else {
        $terms_owner_email_address = '';
    }
    if (isset($privacy_Terms_Settings['terms_owner_locality'])) {
        $terms_owner_locality = $privacy_Terms_Settings['terms_owner_locality'];
    } else {
        $terms_owner_locality = '';
    }
    if (isset($privacy_Terms_Settings['terms_ads'])) {
        $terms_ads = $privacy_Terms_Settings['terms_ads'];
    } else {
        $terms_ads = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_major'])) {
        $terms_major = $privacy_Terms_Settings['terms_major'];
    } else {
        $terms_major = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_arbitration'])) {
        $terms_arbitration = $privacy_Terms_Settings['terms_arbitration'];
    } else {
        $terms_arbitration = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['language'])) {
        $language = $privacy_Terms_Settings['language'];
    } else {
        $language = '';
    }
    if ($terms_enabled == 'on') {
        $var = '';
        if($language == 'English') //English
        {
            $var .= 'Terms of Service for ' . get_home_url();
            
            $var .= '<br/><br/><b>Introduction</b><br/><br/>
            
            Site Terms of Service, an Enforceable Legal Agreement.
            As of *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*

    These Terms of Service and our privacy policy (together the "Terms") govern all use of ' . get_home_url() . ' and that site’s services (together the "Site" or "Services").';
            if ($privacy_owner_name != "") {
                $var .= 'The Site is owned by ' . $privacy_owner_name . ', a(n) ' . $privacy_owner_type . '.';
            }
            
            $var .= 'The owners and contributors to the Site will be referred to as "we," "us," or "our" in these Terms.  By using the Site or its Services, and/or by clicking anywhere on this Site to agree to these Terms, you are deemed to be a "user" for purposes of the Terms.  You and every other user ("you" or "User" as applicable) are bound by these Terms.  You and each user also agree to the Terms by using the Services.  If any User does not agree to the Terms or the Privacy Policy, such User may not access the Site or use the Services.  In these Terms, the word "Site" includes the site referenced above, its owner(s), contributors, suppliers, licensors, and other related parties.

    <br/><br/><b>Responsibility of Website Visitors</b><br/><br/>
    We have not reviewed, and cannot review, all of the material, including computer software, posted to the Website, and cannot therefore be responsible for that material s content, use or effects. By operating the Website, we do not represent or imply that it endorses the material there posted, or that it believes such material to be accurate, useful or non-harmful. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. The Website may contain content that is offensive, indecent, or otherwise objectionable, as well as content containing technical inaccuracies, typographical mistakes, and other errors. The Website may also contain material that violates the privacy or publicity rights, or infringes the intellectual property and other proprietary rights, of third parties, or the downloading, copying or use of which is subject to additional terms and conditions, stated or unstated. 
    We disclaim any responsibility for any harm resulting from the use by visitors of the Website, or from any downloading by those visitors of content there posted.';
            if ($terms_major == "pri_NO") {
                $var .= '<br/><br/><b>Use of this Website</b>
                
        Warning! You may only use this site if you are at least 18 years of age and can enter into binding contracts (the Site is not available for use by minors). By using this Site, you agree that you are at least 18 years of age. ';
            }
            
            $var .= '<br/><br/><b>User Prohibited From Illegal Uses</b>

    User shall not use, and shall not allow any person to use, the Site or Services in any way that violates a federal, state, or local law, regulation, or ordinance, or for any disruptive, tortious, or illegal purpose, including but not limited to harassment, slander, defamation, data theft or inappropriate dissemination, or improper surveillance of any person.

    User represents and warrants that:

    -	User will use the Services only as provided in these Terms;
    -	User is at least 18 years old and has all right, authority, and capacity to agree to these Terms;
    -	User will provide accurate, complete, and current information to the Site and its owner(s);
    -	User will notify the Site and its owner(s) regarding any material change to information User provides, either by updating and correcting the information, or by alerting the Site and its owner(s) via the functions of the Site or the email address provided below.

    Disclaimer of Warranties

    TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SITE PROVIDES THE SERVICES "AS IS," WITH ALL FAULTS.  THE SITE DOES NOT WARRANT UNINTERRUPTED USE OR OPERATION OF THE SERVICES, OR THAT ANY DATA WILL BE TRANSMITTED IN A MANNER THAT IS TIMELY, UNCORRUPTED, FREE OF INTERFERENCE, OR SECURE.  THE SITE DISCLAIMS REPRESENTATIONS, WARRANTIES, AND CONDITIONS OF ANY KIND, WHETHER EXPRESS, IMPLIED, WRITTEN, ORAL, CONTRACTUAL, COMMON LAW, OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES, DUTIES, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, NON-INFRINGEMENT, OR THAT MAY ARISE FROM A COURSE OF DEALING OR USAGE OF TRADE.

    <br/><br/><b>Liability Is Limited</b>

    THE SITE SHALL NOT BE LIABLE FOR INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES OF ANY KIND, INCLUDING BUT NOT LIMITED TO LOST PROFITS (REGARDLESS OF WHETHER WE HAVE BEEN NOTIFIED THAT SUCH LOSS MAY OCCUR) OR EXPOSURE TO ANY THIRD PARTY CLAIMS BY REASON OF ANY ACT OR OMISSION.  THE SITE SHALL NOT BE LIABLE FOR ANY ACT OR OMISSION OF ANY THIRD PARTY INVOLVED WITH THE SERVICES, SITE OFFERS, OR ANY ACT BY SITE USERS.  THE SITE SHALL NOT BE LIABLE FOR ANY DAMAGES THAT RESULT FROM ANY SERVICE PROVIDED BY, OR PRODUCT OR DEVICE MANUFACTURED BY, THIRD PARTIES.

    NOTWITHSTANDING ANY DAMAGES THAT USER MAY SUFFER FOR ANY REASON, THE ENTIRE LIABILITY OF THE SITE IN CONNECTION WITH THE SITE OR SERVICES, AND ANY PARTY’S EXCLUSIVE REMEDY, SHALL BE LIMITED TO THE AMOUNT, IF ANY, ACTUALLY PAID BY USER TO THE SITE OWNER DURING THE 12 MONTHS PRIOR TO THE EVENT THAT USER CLAIMS CAUSED THE DAMAGES.

    The Site shall not be liable for any damages incurred as a result of any loss, disclosure, or third party use of information, regardless of whether such disclosure or use is with or without User’s knowledge or consent.  The Site shall have no liability for any damages related to:  User’s actions or failures to act, the acts or omissions of any third party, including but not limited to any telecommunications service provider, or events or causes beyond the Site’s reasonable control.  The Site has no obligations whatever, and shall have no liability to, any third party who is not a User bound by these Terms.  Limitations, exclusions, and disclaimers in these Terms shall apply to the maximum extent permitted by applicable law, even if any remedy fails its essential purpose.

    <br/><br/><b>Content Posted on Other Websites</b><br/><br/>

    We have not reviewed, and cannot review, all of the material, including computer software, made available through the websites and webpages to which our website links, and that link to us. We do not have any control over those external websites and webpages, and we are not responsible for their contents or their use. By linking to an external website or webpage, we do not represent or imply that it endorses such website or webpage. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. We disclaim any responsibility for any harm resulting from your use of external websites and webpages.
    <br/><br/><b>Third party products, links, and actions</b>

    The Site may include or offer third party products or services.  The Site may also have other users or members who interact with each other, through the Site, elsewhere online, or in person.  These third party products and any linked sites have separate and independent terms of service and privacy policies.  We have no control or responsibility for the content and activities of these linked sites, sellers, and third parties in general, regardless of whether you first were introduced or interacted with such businesses, services, products, and people through the Site, and therefore you agree that we are not liable for any of them. We do, however, welcome any feedback about these sites, sellers, other users or members, and third parties.

    <br/><br/><b>Changes to the Site and the Services</b>

    The owners and contributors to the Site will work to improve the Site for our users, and to further our business interests in the Site. We reserve the right to add, change, and remove features, content, and data, including the right to add or change any pricing terms.  You agree that we will not be liable for any such changes.  Neither your use of the Site nor these terms give you any right, title, or protectable legal interest in the Site or its content.
    We reserve the right, at its sole discretion, to modify or replace any part of this Agreement. It is your responsibility to check this Agreement periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Agreement constitutes acceptance of those changes.

    <br/><br/><b>Termination</b><br/><br/>

    We may terminate your access to all or any part of the Website at any time, with or without cause, with or without notice, effective immediately. If you wish to terminate this Agreement or your account (if you have one), you may simply discontinue using the Website. Notwithstanding the foregoing, if you have a paid services account, such account can only be terminated by us if you materially breach this Agreement and fail to cure such breach within thirty (30) days from our notice to you thereof; provided that, we can terminate the Website immediately as part of a general shut down of our service. All provisions of this Agreement which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability. 

    <br/><br/><b>Indemnity</b>

    If your activity or any activity on your behalf creates potential or actual liability for us, or for any of our users, partners, or contributors, you agree to indemnify and hold us and any such user, partner, contributor, or any agent harmless from and against all claims, costs of defense and judgment, liabilities, legal fees, damages, losses, and other expenses in relation to any claims or actions arising out of or relating to your use of the Site, or any breach by you of these Terms of Service.

    <br/><br/><b>Intellectual Property</b>

    This site and some delivery modes of our product are built on the WordPress platform.  For information about intellectual property rights, including General Public License ("GPL") terms under which the WordPress software is licensed, see here  http://wordpress.org/about/gpl/

    The Site grants User a revocable, non-transferable, and non-exclusive license to use the Site solely in connection with the Site and the Services, under these Terms.

    Copyright in all content and works of authorship included in the Site are the property of the Site or its licensors.  Apart from links which lead to the Site, accurately attributed social media references, and de minimus text excerpts with links returning to the Site, no text, images, video or audio recording, or any other content from the Site shall be copied without explicit and detailed, written permission from the Site s owner.  User shall not sublicense or otherwise transfer any rights or access to the Site or related Services to any other person.

    The names and logos used by the Site, and all other trademarks, service marks, and trade names used in connection with the Services are owned by the Site or its licensors and may not be used by User without written consent of the rights owners.  Use of the Site does not in itself give any user any license, consent, or permission, unless and then only to the extent granted explicitly in these Terms.

    All rights not expressly granted in these Terms are reserved by the Site.';
            if ($privacy_dmca == 'pri_YES') {
                $var .= '<br/><br/><b>Copyright Notice and Takedown (DMCA) Policy</b>

    Please respect the rights of others, including rights under the U.S. copyright laws. You should only post content and files on the Site for which you have ownership, a license, or if your use constitutes fair use as that is defined under US. law.

    Under the Digital Millennium Copyright Act of 1998 (DMCA), we will respond to claims of copyright infringement committed on the Site, if reported to our copyright agent according to these terms.

    If you are a copyright owner, or an authorized representative, please report alleged copyright infringements by completing the following DMCA Notice and delivering it to our copyright agent. We will take action as we deem appropriate under the circumstances, in our sole discretion.  We may remove the challenged material from the Site.

    To give an effective DMCA Notice of Alleged Infringement ("Notice") regarding content on our Site, you must:

      1. Identify the copyrighted work(s) that you claim to be infringed, and the location on our Site where you have observed the allegedly infringing material, including the specific page or post URL that will enable us to locate the material.  (We cannot take down what we cannot find.)
      2. Provide a mailing address, telephone number, and email address where you can be reached.
      3. Include both of the following statements:
    "I state that I have a good faith belief that the use of the copyrighted material or reference or link to such material is not authorized by the copyright owner, its agent, or the law (including fair use)."
    "All information in this Notice is accurate.  Under penalty of perjury, I further state that I am the owner, or that I am authorized to act on behalf of the owner, of the copyright or of an exclusive right (such as an exclusive license) under the copyright that is allegedly infringed."
      4. Provide your full legal name, as well as your electronic or physical signature.

    Deliver this Notice, with items 1-4 completed, to our Designated Copyright Agent:

    Copyright Agent, ' . get_home_url();
                if ($privacy_dmca_address != '') {
                    $var .= '<br/>' . $privacy_dmca_address;
                }
                if ($privacy_dmca_phone != '') {
                    $var .= '<br/>' . $privacy_dmca_phone;
                }
                if ($privacy_dmca_email != '') {
                    $var .= '<br/>Email: ' . $privacy_dmca_email;
                }
                
                $var .= '<br/>Please Note:  In our discretion, we will disable and/or terminate the accounts of users who repeatedly infringe or are repeatedly charged with infringing the copyrights or other intellectual property rights of others.';
            }
            
            $var .= '<br/><br/><b>Privacy</b>

    Any information that you provide to the Site is subject to the Site’s Privacy Policy, which governs our collection and use of User information. User understands that through his or her use of the Site and its Services, User consents to the collection and use (as set forth in the Privacy Policy) of the information, including the transfer of this information to the United States and/or other countries for storage, processing and use by the Site. The Site may make certain communications to some or all Users, such as service announcements and administrative messages. These communications are considered part of the Services and a User’s account with the Site, and Users are not able to opt out of all of them.

    <br/><br/><b>Usernames, Passwords, and Profiles</b>

    If prompted, Users must provide a valid email address to the Site, at which email address the User can receive messages. User must also update the Site if that email address changes. The Site reserves the right to terminate any User account and/or User access to the Site if a valid email is requested but is not provided by the User.

    If the Site prompts or allows a User to create a username or profile, Users agree not to pick a username or provide any profile information that would impersonate someone else or that is likely to cause confusion with any other person or entity.  The Site reserves the right to cancel a User account or to change a username or profile data at any time.  Similarly, if the Site allows comments or user input, or prompts or allows a User to create an avatar or upload a picture, User agrees not to use any image that impersonates some other person or entity, or that is otherwise likely to cause confusion.

    You are responsible for protecting your username and password for the Site, and you agree not to disclose it to any third party. We recommend that you use a password that is more than eight characters long.  You are responsible for all activity on your account, whether or not you authorized it.';
            if ($terms_owner_email_address != '') {
                $var .= 'You agree to inform us of unauthorized use of your account, by email to ' . $terms_owner_email_address . '.';
            }
            $var .= 'You acknowledge that if you wish to protect your interactions with the Site, it is your responsibility to use a secure encrypted connection, virtual private network, or other appropriate measures.  The Site’s own security measures are reasonable in terms of their level of protection, but are not helpful if the interactions of you or any other User with Site are not secure or private.';
            
            if ($terms_owner_locality != '') {
                $var .= '<br/><br/><b>Disputes</b>

    We are based in ' . $terms_owner_locality . ' and you are contracting to use our Site.  These Terms and all matters arising from your use of the Site are governed by and will be construed according to the laws of ' . $terms_owner_locality . ', without regard to any choice of laws rules of any jurisdiction.  The federal courts and state courts that have geographical jurisdiction over disputes arising at our office location in the ' . $terms_owner_locality . ' will be the only permissible venues for any and all disputes arising out of or in connection with these Terms or the Site and Service.';
            }
            if ($terms_arbitration) {
                $var .= '<br/><br/><b>ARBITRATION</b>

    Notwithstanding anything that may be contrary within the "Disputes" provisions above, all matters, and all arbitrable claims within a multi-claim matter, including all claims for monetary damages, shall be decided by a single arbitrator to be selected by us, which arbitrator shall hold hearings';
                if ($terms_owner_locality != '') {
                    $var .= ' in or near ' . $terms_owner_locality;
                }
                $var .= ', under the rules of the American Arbitration Association.';
            }
            
            if ($terms_ads != '') {
                
                $var .= '<br/><br/><b>Advertising</b>

    The Site may include advertisements, which may be targeted for relevance to the Site, queries made, or other information to improve relevance to the Site’s users.  The types and extent of advertising on the Site will change over time.  In consideration for User access to and use of the Site, User agrees that the Site and third party providers and partners may place advertising anywhere on the Site.  For the remaining terms that will apply to our advertising practices, including use of your information, see our Privacy Policy.';
            }
            $var .= '<br/><br/><b>General</b>

    These Terms, including the incorporated Privacy Policy, supersede all oral or written communications and understandings between User and the Site.

    Any cause of action User may have relating to the Site or the Services must be commenced within one (1) year after the claim or cause of action arises. 

    Both parties waive the right to a jury trial in any dispute relating to the Terms, the Site, or the Services.

    If for any reason a court of competent jurisdiction finds any aspect of the Terms to be unenforceable, the Terms shall be enforced to the maximum extent permissible, to give effect to the intent of the Terms, and the remainder of the Terms shall continue in full force and effect.

    User may not assign his or her rights or delegate his or her responsibilities under these Terms or otherwise relating to the Site or its Services.

    There shall be no third party beneficiaries under these Terms, except for the Site’s affiliates, suppliers, and licensors, or as required by law. 

    Use of the Site and its Services is unauthorized in any jurisdiction that does not give effect to all provisions of these Terms, including without limitation this paragraph.

    The failure of the Site to exercise or enforce any right or provision of these Terms shall not constitute a waiver of that right or provision.
    This Agreement constitutes the entire agreement between this website and you concerning the subject matter hereof, and they may only be modified by a written amendment signed by an authorized executive of this website, or by the posting by this website of a revised version. 
    Except to the extent applicable law, if any, provides otherwise, this Agreement, any access to or use of the Website will be governed by our laws, excluding its conflict of law provisions, and the proper venue for any disputes arising out of or relating to any of the same will be the state and federal courts. 
    Except for claims for injunctive or equitable relief or claims regarding intellectual property rights (which may be brought in any competent court without the posting of a bond), any dispute arising under this Agreement shall be finally settled in accordance with the Comprehensive Arbitration Rules of the Judicial Arbitration and Mediation Service, Inc. ("JAMS") by three arbitrators appointed in accordance with such Rules. 
    The arbitration shall take place in the English language and the arbitral decision may be enforced in any court. The prevailing party in any action or proceeding to enforce this Agreement shall be entitled to costs and attorneys fees. If any part of this Agreement is held invalid or unenforceable, that part will be construed to reflect the parties original intent, and the remaining portions will remain in full force and effect. 
    A waiver by either party of any term or condition of this Agreement or any breach thereof, in any one instance, will not waive such term or condition or any subsequent breach thereof. You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; we may assign its rights under this Agreement without condition. 
    This Agreement will be binding upon and will inure to the benefit of the parties, their successors and permitted assigns.';
            
            if ($terms_owner_email_address != '') {
                
                $var .= '<br/><br/><b>Terms Contact</b>

    If you have any questions about these Terms, please address them to ' . $terms_owner_email_address . '.';
            }
            if ($terms_added_text != '') {
                $var .= '<br/><br/><b>Notes</b><br/><br/>'.$terms_added_text;
            }
            $var .= '<br/><br/><b>Last Updated</b>

    These terms were last updated on *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';
        }
        elseif($language == 'German') // German
        {
            $var .= 'Nutzungsbedingungen für ' . get_home_url();
            
            $var .= '<br/><br/><b>Einführung</b><br/><br/>
            
            Nutzungsbedingungen der Website Service, eine Vereinbarung vollstreckbar.
            *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*

    Diese Geschäftsbedingungen und unsere Datenschutzrichtlinien (zusammen die "Bedingungen") gelten für die Nutzung der ' . get_home_url() . ' und dass die Dienstleistungen (zusammen die "Website" oder die "Services").';
            if ($privacy_owner_name != "") {
                $var .= 'Die Website ist im Besitz von ' . $privacy_owner_name . ', ein ';
                if($privacy_owner_type == 'Individual')
                {
                    $var .= 'Einzelnen';
                }
                elseif($privacy_owner_type == 'Partnership')
                {
                    $var .= 'Partnerschaft';
                }
                elseif($privacy_owner_type == 'Corporation')
                {
                    $var .= 'Corporation';
                }
                elseif($privacy_owner_type == 'Limited Liability Company (LLC)')
                {
                    $var .= 'Gesellschaft mit beschränkter Haftung';
                }
                elseif($privacy_owner_type == 'Sole Proprietor')
                {
                    $var .= 'Alleiniger Eigentümer';
                }
                $var .= '.';
            }
            
            $var .= 'Die Eigentümer und die Mitarbeiter vor Ort werden nachstehend als "wir", "uns" oder "unser" in diesen Bedingungen. Durch die Nutzung der Website oder ihrer Dienste, und/oder indem Sie auf eine beliebige Stelle auf dieser Site stimmen Sie diesen Bedingungen zu, sie gelten als "user" für die Zwecke der Bestimmungen. Sie und alle anderen Benutzer ("Sie", "Ihnen" oder "Benutzer") sind an diese Bedingungen gebunden. Sie und jeder Nutzer erklären sich einverstanden, die durch die Nutzung der Dienste. Wenn ein Benutzer nicht mit den Bedingungen einverstanden sind oder der Datenschutzrichtlinien, wie Benutzer keinen Zugriff auf die Website oder die Nutzung der Dienste. In dieser Hinsicht, das Wort "Website" die Website enthält oben verwiesen, dessen Eigentümer(s), Mitarbeiter, Lieferanten, Lizenzgeber und anderen verbundenen Unternehmen.

    <br/><br/><b>Verantwortung für die Besucher der Website</b><br/><br/>
    Wir haben nicht überprüft, und nicht alle, des Materials, einschließlich Computer, Software auf der Website veröffentlicht, und kann daher nicht verantwortlich für die Inhalte, Materialien oder Effekte. Durch den Betrieb der Website, die wir nicht zu vertreten oder implizieren, dass es unterstützt die Material gibt, oder dass es glaubt, dass solches Material, um genau zu sein, nützlich oder nicht-schädlich. Sie sind verantwortlich für die Einhaltung der Sicherheitsmaßnahmen wie nötig, um sich selbst zu schützen und Ihren Computer vor Viren, Würmer, Trojanische Pferde und andere schädliche oder zerstörerische Inhalte. Die Website enthält möglicherweise Inhalte, die beleidigend, anstößig oder in sonstiger Weise zu beanstanden sind, sowie Inhalte, die technische Ungenauigkeiten und typografische Fehler und andere Fehler. Die Website kann enthalten auch Material, das gegen die Privatsphäre oder Persönlichkeitsrechte oder verstößt gegen das Urheberrecht und andere Schutzrechte Dritter, oder das Herunterladen, Kopieren oder Verwendung unterliegt zusätzlichen Geschäftsbedingungen, erklärte oder unausgesprochene. 
    Wir lehnen jede Verantwortung für Schäden, die aus der Nutzung durch Besucher der Website, oder von einem Download durch die Besucher der Inhalt gibt.';
            if ($terms_major == "pri_NO") {
                $var .= '<br/><br/><b>Nutzung dieser Website</b>
                
        Warnung! Sie können nur verwenden, wenn Sie mindestens 18 Jahre alt sind und in verbindliche Verträge (die Website ist nicht verfügbar für die Nutzung durch Minderjährige). Durch die Nutzung dieser Website erklären Sie sich damit einverstanden, dass Sie mindestens 18 Jahre alt sind. ';
            }
            
            $var .= '<br/><br/><b>Benutzer untersagt, illegale verwendet</b>

    Benutzer ist nicht verwenden, und wird nicht zulassen, dass jede Person, die Website oder Dienste in irgendeiner Art und Weise gegen eine Bundes-, Landes-, oder lokale Gesetze, Vorschriften oder Verordnungen, oder für jegliche störende, unerlaubter oder illegale Zwecke, einschließlich, aber nicht beschränkt auf Mobbing, üble Nachrede, Verleumdung, Datendiebstahl oder unangemessene Verbreitung, oder unsachgemäßen Überwachung einer Person.

Der Benutzer sichert zu und gewährleistet, dass:

- Der Benutzer wird nur die Verwendung der Dienste, wie sie in diesen Allgemeinen Geschäftsbedingungen;
- Der Benutzer muss mindestens 18 Jahre alt und hat alle Rechte, Autorität und die Fähigkeit, stimmen Sie diesen Bedingungen;
- genaue, vollständige und aktuelle Informationen auf der Website und der Eigentümer(s);
- Der Benutzer wird der Standort und seine Eigentümer(s) über eine wesentliche Änderung zu den Informationen, die der Benutzer übermittelt, und zwar entweder durch eine Aktualisierung und Korrektur der Information, oder durch die Website und deren Eigentümer(s) über die Funktionen der Website oder die E-Mail Adresse unten.

Gewährleistungsausschluss

    Soweit gesetzlich zulässig, die Website stellt die Dienstleistungen, "wie es ist, mit allen Fehlern. Die Website übernimmt keine Gewähr für die ununterbrochene Nutzung oder den Betrieb des Services, oder dass keine Daten gesendet werden, in einer Art und Weise, ist Rechtzeitig, unbeschädigt und frei von Störungen oder Secure Site lehnt die Zusicherungen, Gewährleistungen und Bedingungen jeglicher Art, ob ausdrücklich, konkludent, schriftlich, mündlich, vertraglichen, common law, oder gesetzlich, einschließlich, aber nicht beschränkt auf Garantien, Pflichten oder Bedingungen der Marktgängigkeit, der Eignung für einen bestimmten Zweck, Titel, Nichtverletzung der Rechte Dritter oder der, die sich aus einem.

    <br/><br/><b>Die Haftung ist begrenzt</b>

    Die Website ist nicht haftbar für indirekte, spezielle, zufällige Schäden, Folgeschäden, exemplarische oder Strafschadensersatz jeglicher Art vor, einschließlich, jedoch nicht beschränkt auf entgangene Gewinne (unabhängig davon, ob wir uns mitgeteilt wurde, dass ein solcher Verlust kann auftreten) oder die Exposition gegenüber allen Ansprüchen Dritter wegen einer Handlung oder Unterlassung. Die Website ist nicht haftbar für jegliche Handlung oder Unterlassung einer dritten Partei, die mit den Dienstleistungen, die Website bietet, oder jede Handlung, durch die Benutzer der Website. der Website haftet nicht für Schäden, die aus jedem Service oder Produkt oder Gerät hergestellt, durch Dritte.

Ungeachtet aller Schäden, die Benutzer aus irgendeinem Grund leiden, ist die gesamte Haftung von der Website in Verbindung mit der Website oder Dienste, und jede Partei Abhilfe schaffen, werden auf den Betrag begrenzt, der gegebenenfalls durch den Benutzer tatsächlich gezahlten zu Der Eigentümer der Website während der letzten 12 Monate vor der Veranstaltung, dass die Ansprüche, die die Schäden.
Die Website ist nicht haftbar für jegliche Schäden, die als Folge von Verlust, Offenlegung oder Verwendung von Informationen Dritter, unabhängig davon, ob eine solche Offenlegung oder Nutzung ist mit oder ohne Wissen oder Zustimmung des Benutzers. Die Site übernimmt keine Haftung für Schäden, die im Zusammenhang mit: Benutzer Handlungen oder Unterlassungen, die Handlungen oder Unterlassungen Dritter, einschließlich, aber nicht beschränkt auf, Telekommunikation, Service Provider oder Ereignissen oder Ursachen außerhalb der angemessenen Kontrolle. Die Website hat keine Verpflichtungen und übernimmt keine Haftung für Dritte, die nicht vom Benutzer an diese Bedingungen gebunden. Einschränkungen, Ausschlüsse und Haftungsausschlüsse in diesen Allgemeinen Geschäftsbedingungen gelten, soweit dies durch das anwendbare Recht gestatteten Umfang, auch wenn ein Anspruch seinen wesentlichen Zweck verfehlt.
    <br/><br/><b>Inhalte auf anderen Websites</b><br/><br/>

    Wir haben nicht überprüft, und nicht alle, des Materials, einschließlich Computer, Software, zur Verfügung gestellt durch die Websites und Webseiten, zu denen Links auf unserer Website, und das link zu uns. Wir haben keine Kontrolle über diese Websites und Webseiten, und wir sind nicht verantwortlich für deren Inhalte oder deren Nutzung. Durch die Verknüpfung zu einer externen Website oder Webseite, die wir nicht zu vertreten oder implizieren, dass es stimmt, Website oder Webseite. Sie sind verantwortlich für die Einhaltung der Sicherheitsmaßnahmen wie nötig, um sich selbst zu schützen und Ihren Computer vor Viren, Würmer, Trojanische Pferde und andere schädliche oder zerstörerische Inhalte. Wir lehnen jede Verantwortung für Schäden, die aus der Verwendung von externen Websites und Webseiten.
    <br/><br/><b>Produkte Dritter, Links und Aktionen</b>

    Die Website kann gehören oder bieten Produkte oder Dienstleistungen Dritter. Die Website kann auch andere Benutzer oder Mitglieder, die miteinander interagieren, durch den Ort, an anderer Stelle, online oder persönlich. Diese Produkte von Drittanbietern und verlinkten Seiten haben separate und unabhängige Nutzungsbedingungen und Datenschutzrichtlinien. Wir haben keine Kontrolle oder Verantwortung für den Inhalt und die Aktivitäten auf diesen verlinkten Sites, Verkäufer, und Dritte im Allgemeinen, unabhängig davon, ob Sie zuerst eingeführt wurden oder mit solchen Unternehmen, die Dienstleistungen, die Produkte und die Menschen, die über die Website, und daher erklären Sie sich damit einverstanden, dass wir sind nicht haftbar für jegliche von Ihnen. Wir wissen jedoch, begrüßen jegliches Feedback zu diesen Seiten, Verkäufer, andere Benutzer oder Mitglieder und Dritte.

    <br/><br/><b>Änderungen an der Website und der Dienstleistungen</b>

   Die Eigentümer und die Mitarbeiter auf die Website wird zur Verbesserung der Website für unsere Nutzer weiter zu unserem geschäftlichen Interessen in der Website. Wir behalten uns das Recht vor, Hinzufügen, Ändern und Entfernen von Funktionen, Inhalte und Daten, einschließlich des Rechts auf Hinzufügen oder Ändern Sie die Preisgestaltung. Sie erklären sich damit einverstanden, dass wir haften nicht für etwaige Änderungen. Weder die Nutzung der Website und diese Bedingungen keinerlei Rechte, Titel oder Schützbaren rechtliches Interesse an der Website oder ihren Inhalt.
Wir behalten uns das Recht vor, nach eigenem Ermessen zu ändern oder zu ersetzen einen Teil dieser Vereinbarung. Es liegt in Ihrer Verantwortung, diese Vereinbarung regelmäßig auf Änderungen. Ihre fortgesetzte Nutzung der Website oder den Zugriff auf die Website nach der Veröffentlichung von Änderungen an dieser Vereinbarung erklären Sie Ihr Einverständnis mit diesen Änderungen.
    <br/><br/><b>Kündigung</b><br/><br/>

    Wir können Ihren Zugang auf alle oder einen Teil der Website jederzeit, mit oder ohne Ursache, mit oder ohne vorherige Ankündigung sofort wirksam. Wenn Sie möchten, dieses Abkommen zu kündigen oder ihr Konto (wenn Sie eine haben), können Sie einfach über die Website einzustellen. Ungeachtet der vorstehenden Ausführungen, wenn Sie eine bezahlte Dienstleistungen, wie Konto kann nur durch uns, wenn Sie gegen diese Vereinbarung verstoßen und diesen Verstoß nicht innerhalb von dreißig (30) Tagen ab der Benachrichtigung an Sie, vorausgesetzt, dass wir die Website sofort beenden kann als Teil einer allgemeinen Abschaltung von unserem Service. Alle Bestimmungen dieser Vereinbarung, welche ihrer Natur nach Beendigung Beendigung, einschließlich, ohne Einschränkung, Eigentum, Garantieausschlüsse, Haftungsbeschränkungen und Haftungsfreistellung.
    <br/><br/><b>Entschädigung</b>

    Wenn ihre Aktivität oder jede Tätigkeit auf ihren Namen erzeugt potentielle oder tatsächliche Haftung für uns oder für unsere Nutzer, Partner, oder Mitwirkenden erklären Sie sich damit einverstanden, uns schad- und klaglos zu halten und alle Benutzer, Partner, Mitarbeiter oder Agenten schadlos gegen alle Ansprüche, Kosten für die Verteidigung und das Urteil, Verbindlichkeiten, Kosten, Schäden, Verluste, Kosten und andere in Bezug auf jegliche Forderungen oder Ansprüche aus oder im Zusammenhang mit Ihrer Nutzung der Website oder eine Verletzung dieser Nutzungsbedingungen.
    <br/><br/><b>Geistiges Eigentum</b>

    Diese Website und einige Modi Lieferung unserer Produkte basieren auf der Plattform WordPress. Weitere Informationen über Rechte an geistigem Eigentum, einschließlich General Public License ("GPL") Bedingungen, unter denen die WordPress Software lizenziert ist, siehe hier, http://wordpress.org/about/gpl/

Die Site gewährt eine widerrufliche, nicht übertragbare und nicht-exklusive Lizenz zur Nutzung der Website ausschließlich in Verbindung mit der Site und der Dienste, die unter diesen Bedingungen.

Copyright Alle Inhalte und Werke auf dieser Website sind Eigentum der Site oder seinen Lizenzgebern. Abgesehen von Links, die auf der Website, genau auf Social Media Referenzen und de minimus Textauszüge mit Links auf der Seite, kein Text, Bildern, Video oder Audio Aufnahme, oder andere Inhalte von der Website kopiert werden ohne ausdrückliche und schriftliche Genehmigung, von der Website Besitzer. Benutzer werden nicht im Rahmen einer Unterlizenz zur Verfügung stellen oder anderweitig übertragen keine Rechte oder der Zugriff auf die Website oder die Dienstleistungen, die an eine andere Person.

Die Namen und Logos von der Website, und alle anderen Marken, Dienstleistungsmarken und Handelsnamen, die in Verbindung mit den Services, die von der Site oder seinen Lizenzgebern und dürfen nicht verwendet werden, um Benutzer ohne schriftliche Zustimmung der Rechteinhaber. Die Nutzung der Website nicht an und für sich keine Benutzer eine Lizenz, Erlaubnis oder Genehmigung, es sei denn, und wenn, dann nur in dem Umfang gewährt werden ausdrücklich in diesen Geschäftsbedingungen.

Alle Rechte, die nicht ausdrücklich in diesen Nutzungsbedingungen gewährt werden, sind vorbehalten.';
            if ($privacy_dmca == 'pri_YES') {
                $var .= '<br/><br/><b>Copyright und Entfernung (DMCA) Policy</b>

    Bitte respektieren Sie die Rechte anderer, einschließlich der Rechte im Rahmen des US-Amerikanischen Urheberrechts. Sie sollten nur Dateien und Inhalte auf der Website, für die Sie eine Lizenz haben, oder wenn ihre Nutzung stellt die Messe als definiert ist, unter uns..

Im Rahmen der Digital Millennium Copyright Act (DMCA) von 1998, wir reagieren auf Ansprüche wegen Urheberrechtsverletzungen auf der Website, wenn berichtet, unser Copyright Agent nach diesen Bedingungen.

Wenn Sie ein Inhaber des Urheberrechts oder einem autorisierten Vertreter, bitte melden sie angebliche Verletzungen des Urheberrechts durch Ausfüllen des folgenden DMCA Notiz und Auslieferung an unsere Copyright Agent. Wir werden Maßnahmen ergreifen, wie wir unter den gegebenen Umständen für angemessen erachten, in unserem alleinigen Ermessen. Wir können das Material von der Website in Frage gestellt.

Eine effektive DMCA Notiz der angeblichen Verletzung ("Kündigung") hinsichtlich der Inhalte auf unserer Website, müssen Sie:

1. Identifizieren der urheberrechtlich geschützten Arbeit(en), die Sie behaupten, verletzt, und die Lage auf unserer Website, wo Sie beobachtet haben, der angeblich verletzende Material, einschließlich der spezifischen Seite oder URL, die es uns ermöglichen, das Material finden. (Wir können das, was wir nicht finden können.)
2. Eine Postanschrift, Telefonnummer und E-Mail-Adresse, unter der Sie erreichbar sind.
3. Gehören beide der folgenden Aussagen:
"Ich erkläre, dass ich einen guten Glauben, dass die Verwendung von urheberrechtlich geschütztem Material oder den Verweis oder Link auf solches Material nicht durch den Inhaber der Urheberrechte, durch dessen Bevollmächtigte oder durch Rechtsvorschriften (einschließlich fair use)."
"Alle Informationen, die in dieser Bekanntmachung akkurat sind. Unter Strafe des Meineids, ich weiter, ich bin der Besitzer, oder, dass ich berechtigt bin, im Namen des Eigentümers, des Urheberrechts oder eines exklusiven Rechts (z. B. eine ausschließliche Lizenz im Rahmen der Urheberrechte), das angeblich verletzt wurde."
4. Geben Sie Ihren vollständigen Namen, sowie Ihre elektronische oder physische Unterschrift.

Diese Ankündigung, mit Reihen 1-4 abgeschlossen, auf unsere ausgewiesenen Copyright Agent:

Copyright Agent, ' . get_home_url();
                if ($privacy_dmca_address != '') {
                    $var .= '<br/>' . $privacy_dmca_address;
                }
                if ($privacy_dmca_phone != '') {
                    $var .= '<br/>' . $privacy_dmca_phone;
                }
                if ($privacy_dmca_email != '') {
                    $var .= '<br/>Email: ' . $privacy_dmca_email;
                }
                
                $var .= '<br/>Bitte beachten Sie: In unserem Ermessen, wir deaktivieren und/oder zu beenden, die Konten der Benutzer wiederholt verletzt oder immer wieder mit der Verletzung der Urheberrechte oder andere Rechte am geistigen Eigentum von Anderen.';
            }
            
            $var .= '<br/><br/><b>Datenschutz</b>

    Alle Informationen, die Sie auf die Website unterliegt den Datenschutzbestimmungen, die für die Sammlung und Verwendung von Informationen der Benutzer. Der Benutzer ist sich bewusst, dass durch seine oder ihre Nutzung der Site und der Dienste, Nutzer willigt in die Erhebung und Nutzung (wie sie in der Privacy Policy) der Informationen, einschließlich der Übertragung dieser Informationen in den Vereinigten Staaten und/oder anderen Ländern für die Speicherung, Verarbeitung und Verwendung durch den Ort. Die Site kann bestimmte Mitteilungen zu einigen oder allen Benutzern, wie z. B. administrative Nachrichten und Ankündigungen. Diese Mitteilungen werden als Teil der Services und das Konto eines Benutzers mit der Website, und die Benutzer sind nicht in der Lage, alle von Ihnen.

    <br/><br/><b>Benutzernamen, Kennwörter und Profile</b>

    Wenn Sie dazu aufgefordert werden, muss der Benutzer eine gültige E-Mail-Adresse an den Ort, an dem die E-Mail-Adresse der Benutzer Nachrichten empfangen werden können. Der Benutzer muss die Aktualisierung auch vor Ort, wenn diese e-mail Adresse ändert. Die Site behält sich das Recht vor, jederzeit zu beenden bzw. Benutzer-Konto und/oder der Benutzer den Zugriff auf die Website, wenn Sie eine gültige E-Mail-Adresse ist beantragt, aber nicht durch den Benutzer.

Wenn die Website fordert oder erlaubt einem Benutzer, erstellen Sie einen Benutzernamen oder ein Profil, Benutzer erklären sich damit einverstanden, dass ein Benutzername oder eine beliebige Informationen, die jemand anderes ausgeben, oder dass damit zu rechnen ist, dass eine Verwechslung mit einer anderen Person oder einer juristischen Person. Die Site behält sich das Recht vor, ein Benutzerkonto zu löschen, oder ändern Sie einen Benutzernamen oder die Profildaten zu jeder Zeit. Ähnlich verhält es sich, wenn die Website können Kommentare oder Benutzereingaben, oder fordert oder erlaubt einem Benutzer, einen Avatar erstellen oder ein Bild hochladen, der Benutzer stimmt nicht mit jedem Bild, das die Identität einer anderen Person oder Körperschaft oder sonst Verwirrung zu stiften.

Sie sind verantwortlich für den Schutz Ihres Benutzernamens und Kennworts für die Website, und Sie erklären sich damit einverstanden, dass sie weitergeben an Dritte. Wir empfehlen, dass Sie ein Kennwort verwenden, das ist mehr als acht Zeichen lang sein. Sie sind verantwortlich für alle Aktivitäten auf Ihrem Konto, unabhängig davon, ob Sie berechtigt sind oder nicht.';
            if ($terms_owner_email_address != '') {
                $var .= 'Sie stimmen zu, uns zu informieren, um die unbefugte Benutzung Ihres Kontos per E-Mail zu ' . $terms_owner_email_address . '.';
            }
            $var .= 'Sie stimmen zu, uns zu informieren, um die unbefugte Benutzung Ihres Kontos per E-Mail.';
            
            if ($terms_owner_locality != '') {
                $var .= '<br/><br/><b>Streitigkeiten</b>

    Wir sind in ' . $terms_owner_locality . ' Und Sie zur Nutzung unserer Website. Diese Bedingungen und alle Angelegenheiten, die sich aus der Nutzung der Site unterliegen und werden ausgelegt nach den Gesetzen der ' . $terms_owner_locality . ', Ohne Rücksicht auf die Wahl der gesetzlichen Vorschriften einer Gerichtsbarkeit. Der eidgenössischen Gerichte und der staatlichen Gerichte, die geografische Zuständigkeit für Streitigkeiten in unserem Büro in der Lage ' . $terms_owner_locality . ' Die einzige zulässige Veranstaltungsorte für alle Streitigkeiten aus oder in Zusammenhang mit diesen Bedingungen oder auf der Website und den Service.';
            }
            if ($terms_arbitration) {
                $var .= '<br/><br/><b>Schiedsverfahren</b>

    Ungeachtet der möglicherweise im Widerspruch innerhalb der "Streitigkeiten" Bestimmungen über alle Fragen, und alle arbitrable Ansprüche innerhalb einer multi-Anspruch, einschließlich aller Ansprüche auf Schadenersatz, wird von einem einzigen Schiedsrichter ausgewählt werden von uns, dem Schiedsrichter Anhörungen';
                if ($terms_owner_locality != '') {
                    $var .= ' In oder in der Nähe von ' . $terms_owner_locality;
                }
                $var .= ', Nach den Regeln der American Arbitration Association.';
            }
            
            if ($terms_ads != '') {
                
                $var .= '<br/><br/><b>Werbung</b>

    Die Website kann auch anzeigen, die möglicherweise für die Relevanz für die Website, Anfragen oder weitere Informationen zur Verbesserung der Relevanz für die Benutzer der Website. Die Art und das Ausmaß der Werbung auf der Website wird im Laufe der Zeit ändern. Im Hinblick auf die Benutzer den Zugriff auf und die Nutzung der Website, der Benutzer stimmt zu, dass die Website und die dritte Anbieter und Partner Werbung platzieren können überall auf der Website. Für die übrigen Bestimmungen, die für unsere Werbung Praktiken, einschließlich der Verwendung Ihrer Informationen finden Sie in unserer Datenschutzerklärung.';
            }
            $var .= '<br/><br/><b>Allgemein</b>

    Diese Nutzungsbedingungen, einschließlich der Datenschutzbestimmungen, ersetzen alle mündlichen oder schriftlichen Mitteilungen und Vereinbarungen zwischen dem Benutzer und der Website.

Die Ursache für die Aktion Benutzer möglicherweise in Bezug auf die Website oder die Dienste müssen innerhalb eines (1) Jahres, nachdem der Anspruch oder die Ursache der Tätigkeit entsteht.

Beide Parteien verzichten auf das Recht auf ein Gerichtsverfahren in jeder Streitigkeit in Bezug auf die Begriffe, die Website oder die Dienstleistungen.

Wenn aus irgendeinem Grund ein zuständiges Gericht irgendeine Aspekt der Bedingungen durchsetzbar ist, die Bedingungen in dem maximal zulässigen Umfang wirksam werden zu lassen, um die Absicht der Begriffe, und der Rest der AGB bleiben in voller Kraft und Wirkung.

Der Benutzer ist nicht berechtigt, seine Rechte und seine Pflichten aus diesen Bedingungen oder sonst im Zusammenhang mit der Website oder deren Dienste.

Es gibt keine Drittbegünstigten unter diesen Bedingungen, außer für die Website der Partner, Lieferanten und Lizenzgebern, oder wie gesetzlich vorgeschrieben.

Die Nutzung der Website und ihrer Dienste unter einer anderen Rechtsprechung ist nicht gestattet und hat keine Auswirkungen auf die Bestimmungen dieser Bedingungen, dies schließt auch die Anwendung dieses Absatzes.

Der Ausfall der Website für die Nichtausübung oder Nichtdurchsetzung eines Rechts oder einer Bestimmung dieser Nutzungsbedingungen stellt keinen Verzicht auf dieses Recht bzw. die betreffende Bestimmung dar.
Diese Vereinbarung stellt die gesamte Vereinbarung zwischen dieser Website und Sie in Bezug auf den Vertragsgegenstand dar, und sie kann nur geändert werden, indem eine schriftliche Änderung unterschrieben von einem autorisierten Executive dieser Website, oder durch die Entsendung von dieser Website einer überarbeiteten Version.
Außer in dem Umfang, wenn überhaupt, dieses Abkommen nichts anderes vorsieht, kann jeder den Zugang zu oder die Nutzung der Website unterliegt den Gesetzen, mit Ausnahme seiner kollisionsrechtlichen Bestimmungen, und die richtige Gerichtsstand für alle Streitigkeiten aus oder im Zusammenhang mit der gleichen werden die staatlichen und bundesstaatlichen Gerichte.
Außer für Ansprüche auf Unterlassung oder Billigkeitsrecht oder Ansprüche in Bezug auf Rechte an geistigem Eigentum (Die kann in jedem zuständigen Gericht, ohne die Entsendung einer Anleihe), etwaige Streitigkeiten, die sich aus diesem Abkommen ergeben, werden im Einklang mit dem umfassenden Schiedsordnung der gerichtlichen Schlichtung und Mediation Service, Inc. ("Stau") durch drei Schiedsrichter in Übereinstimmung mit diesen Regeln.
Das Schiedsverfahren findet in der englischen Sprache und das Schiedsgericht kann in jedem Gericht durchgesetzt. Die obsiegende Partei in jeder Handlung oder Verfahren zur Durchsetzung dieser Vereinbarung berechtigt, Kosten und Anwaltsgebühren. Wenn irgendein Teil dieser Vereinbarung für ungültig oder nicht durchsetzbar erklärt werden, ist dieser Teil kann so ausgelegt werden, dass die ursprüngliche Absicht, die Parteien und die verbleibenden Abschnitte bleiben in voller Kraft und Wirkung.
Der Verzicht einer Partei auf eine Bestimmung oder Bedingung dieser Vereinbarung oder eine Verletzung davon, in einer Instanz stellt keinen Verzicht auf eine solche Bedingung oder einer späteren Verletzung davon. Sie können Ihre Rechte unter dieser Vereinbarung auf eine Partei, die dem zustimmt, und erklärt sich damit einverstanden, an diese gebunden zu sein, die Bedingungen und Konditionen; wir können Ihre Rechte im Rahmen dieser Vereinbarung ohne Bedingung.
Diese Vereinbarung wird verbindlich und wird tritt in Kraft zum Vorteil der Parteien, ihrer Rechtsnachfolger und zulässige Abtretungsempfänger.';
            
            if ($terms_owner_email_address != '') {
                
                $var .= '<br/><br/><b>Agb Kontakt</b>

    Wenn Sie Fragen zu diesen Nutzungsbedingungen haben, wenden Sie sich bitte an ' . $terms_owner_email_address . '.';
            }
            if ($terms_added_text != '') {
                $var .= '<br/><br/><b>Hinweise</b><br/><br/>'.$terms_added_text;
            }
            $var .= '<br/><br/><b>Letzte Aktualisierung</b>

    Diese Nutzungsbedingungen wurden zuletzt aktualisiert am *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';
        }
        
        if (!$the_page) {
            
            // Create post object
            $_p               = array();
            $_p['post_title'] = $the_page_title;
            
            $_p['post_content']   = $var;
            $_p['post_status']    = 'publish';
            $_p['post_type']      = 'page';
            $_p['comment_status'] = 'closed';
            $_p['ping_status']    = 'closed';
            $_p['post_category']  = array(
                1
            ); // the default 'Uncatrgorised'
            
            // Insert the post into the database
            $the_page_id = wp_insert_post($_p);
            
        } else {
            
            //make sure the page is not trashed...
            $the_page->post_content = $var;
            $the_page->post_status  = 'publish';
            $the_page_id            = wp_update_post($the_page);
            
        }
        
        delete_option('terms_policy_id');
        add_option('terms_policy_id', $the_page_id);
    } else {
        terms_my_plugin_remove();
    }
}
function terms_my_plugin_remove()
{
    global $wpdb;
    //  the id of our page...
    $the_page_id = get_option('terms_policy_id');
    if ($the_page_id) {
        
        wp_delete_post($the_page_id, true);
        
    }
    delete_option("terms_policy_id");
}
register_activation_hook(__FILE__, 'terms_my_plugin_install');

function privacy_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('wp_ajax_legalize_fortune_my_action', 'legalize_fortune_my_action_callback');
function legalize_fortune_my_action_callback()
{
    $past = time() - 3600;
    foreach ($_COOKIE as $key => $value) {
        setcookie($key, $value, $past, '/');
    }
    echo "0";
    die();
}

/* Runs when plugin is activated */
register_activation_hook(__FILE__, 'legalize_my_plugin_install');

/* Runs on plugin deactivation*/
register_deactivation_hook(__FILE__, 'legalize_my_plugin_remove');
register_deactivation_hook(__FILE__, 'terms_my_plugin_remove');

function legalize_my_plugin_install()
{
    
    global $wpdb;
    $the_page_title        = 'Privacy Policy';
    $the_page              = get_page_by_title($the_page_title);
    $privacy_Main_Settings = get_option('privacy_Main_Settings', false);
    if (isset($privacy_Main_Settings['privacy_collect_data'])) {
        $privacy_collect_data = $privacy_Main_Settings['privacy_collect_data'];
    } else {
        $privacy_collect_data = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data'])) {
        $privacy_share_data = $privacy_Main_Settings['privacy_share_data'];
    } else {
        $privacy_share_data = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_enabled'])) {
        $privacy_enabled = $privacy_Main_Settings['privacy_enabled'];
    } else {
        $privacy_enabled = '';
    }
    if (isset($privacy_Main_Settings['privacy_collect_data_partners'])) {
        $privacy_collect_data_partners = $privacy_Main_Settings['privacy_collect_data_partners'];
    } else {
        $privacy_collect_data_partners = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_ads'])) {
        $privacy_share_data_ads = $privacy_Main_Settings['privacy_share_data_ads'];
    } else {
        $privacy_share_data_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_unlimited'])) {
        $privacy_share_data_unlimited = $privacy_Main_Settings['privacy_share_data_unlimited'];
    } else {
        $privacy_share_data_unlimited = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_agr'])) {
        $privacy_share_data_agr = $privacy_Main_Settings['privacy_share_data_agr'];
    } else {
        $privacy_share_data_agr = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_california'])) {
        $privacy_california = $privacy_Main_Settings['privacy_california'];
    } else {
        $privacy_california = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ssl'])) {
        $privacy_ssl = $privacy_Main_Settings['privacy_ssl'];
    } else {
        $privacy_ssl = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ads'])) {
        $privacy_ads = $privacy_Main_Settings['privacy_ads'];
    } else {
        $privacy_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_adsense'])) {
        $privacy_adsense = $privacy_Main_Settings['privacy_adsense'];
    } else {
        $privacy_adsense = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_cookies'])) {
        $privacy_cookies = $privacy_Main_Settings['privacy_cookies'];
    } else {
        $privacy_cookies = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_pass'])) {
        $privacy_pass = $privacy_Main_Settings['privacy_pass'];
    } else {
        $privacy_pass = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_arb'])) {
        $privacy_arb = $privacy_Main_Settings['privacy_arb'];
    } else {
        $privacy_arb = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_child'])) {
        $privacy_child = $privacy_Main_Settings['privacy_child'];
    } else {
        $privacy_child = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_added_text'])) {
        $privacy_added_text = $privacy_Main_Settings['privacy_added_text'];
    } else {
        $privacy_added_text = '';
    }
    if (isset($privacy_Main_Settings['privacy_owner_loc'])) {
        $privacy_owner_loc = $privacy_Main_Settings['privacy_owner_loc'];
    } else {
        $privacy_owner_loc = '';
    }
    if (isset($privacy_Main_Settings['privacy_owner_email'])) {
        $privacy_owner_email = $privacy_Main_Settings['privacy_owner_email'];
    } else {
        $privacy_owner_email = '';
    }
    if (isset($privacy_Main_Settings['privacy_email'])) {
        $privacy_email = $privacy_Main_Settings['privacy_email'];
    } else {
        $privacy_email = '';
    }
    if (isset($privacy_Main_Settings['privacy_mail'])) {
        $privacy_mail = $privacy_Main_Settings['privacy_mail'];
    } else {
        $privacy_mail = '';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_partners'])) {
        $privacy_share_data_partners = $privacy_Main_Settings['privacy_share_data_partners'];
    } else {
        $privacy_share_data_partners = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['language'])) {
        $language = $privacy_Main_Settings['language'];
    } else {
        $language = '';
    }
    if ($privacy_enabled == 'on') {
        $var = '';
        if($language == 'English') //English
        {
            $var .= 'This privacy policy ("Policy") and this site’s Terms of Service (together the "Terms") govern all use of ' . get_home_url() . ' and that site’s services (together the "Site" or "Services").  The owners and contributors to the Site will be referred to as "we," "us," or "our" in this Policy.  By using the Site or its Services, and/or by clicking anywhere on this Site to agree to the Terms and this Policy, you are deemed to be a "user" for purposes of this Policy.  You and every other user ("you" or "User" as applicable) are subject to this Policy.  You and each user also agree to the Terms by using the Services.  In these Terms, the word "Site" includes the site referenced above, its owner(s), contributors, suppliers, licensors, and other related parties.

            We provide this privacy statement explaining our online information practices, so that you can decide whether and how to interact with the Site and the Services.

            We may release your information when we deem it appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety.

            This online privacy policy applies only to information collected through our website and not to information collected offline.

            Please also review our <b>Terms of Service</b> section that governs the use and the users of the Site.

            By using our site, you consent to our <b>Privacy Policy</b>.

            If we decide to change our privacy policy, we will post those changes on this page. If we have your email address, we may also send an email notifying you of any changes.';
            if ($privacy_collect_data == 'pri_YES') {
                $var .= '<br/><br/><b>Contact Data and Other Identifiable Information</b>

                This site collects certain user information, which may include a username and password, contact information, or any other data that you type in to the site.  It may also identify your IP address to help identify you on future visits to the site.  At our discretion, the Site may use this data to:

                * Personalize the user experience and/or customer service
                * Improve the site
                * To process transactions
                * Administer a contest, promotion, survey or other site feature or function
                * Send email to users';
            }
            $var .= '<br/><br/><b>Gathering of Personally-Identifying Information</b>
            
            Certain visitors of our websites choose to interact with our website in ways that require us to gather personally-identifying information. The amount and type of information that wef gathers depends on the nature of the interaction. For example, we ask visitors who sign up at our website to provide a username and email address. Those who engage in transactions with us are asked to provide additional information, including as necessary the personal and financial information required to process those transactions. 
            In each case, we collect such information only insofar as is necessary or appropriate to fulfill the purpose of the visitor s interaction with us. We do not disclose personally-identifying information other than as described below. And visitors can always refuse to supply personally-identifying information, with the caveat that it may prevent them from engaging in certain website-related activities.';
            $var .= '<br/><br/><b>Protection of Certain Personally-Identifying Information</b>
            
            We disclose potentially personally-identifying and personally-identifying information only to those of its employees, contractors and affiliated organizations that (i) need to know that information in order to process it on our behalf or to provide services available at our websites, and (ii) that have agreed not to disclose it to others. 
            Some of those employees, contractors and affiliated organizations may be located outside of your home country; by using our websites, you consent to the transfer of such information to them. We will not rent or sell potentially personally-identifying and personally-identifying information to anyone. Other than to its employees, contractors and affiliated organizations, as described above, we disclose potentially personally-identifying and personally-identifying information only in response to a subpoena, court order or other governmental request, or when we believe in good faith that disclosure is reasonably necessary to protect our property or rights, third parties or the public at large. If you are a registered user of our website and have supplied your email address, we may occasionally send you an e-mail to tell you about new features, solicit your feedback, or just keep you up to date with what s going on with our products. 
            If you send us a request (for example via email or via one of our feedback mechanisms), we reserve the right to publish it in order to help us clarify or respond to your request or to help us support other users. We take all measures reasonably necessary to protect against the unauthorized access, use, alteration or destruction of potentially personally-identifying and personally-identifying information.';
            if ($privacy_share_data == 'pri_YES') {
                $var .= '<br/><br/><b>Sharing User Data</b>

            Like most website operators, we collect non-personally-identifying information of the sort that web browsers and servers typically make available, such as the browser type, language preference, referring site, and the date and time of each visitor request. Our purpose in collecting non-personally identifying information is to better understand how our visitors use this website. From time to time, we may release non-personally-identifying information in the aggregate, e.g., by publishing a report on trends in the usage of its website.
            We also collect potentially personally-identifying information like Internet Protocol (IP) addresses for logged in users and for users leaving comments on our blogs/sites. We only discloses logged in user and commenter IP addresses under the same circumstances that it uses and discloses personally-identifying information as described below, except that commenter IP addresses and email addresses are visible and disclosed to the administrators of the blog/site where the comment was left.
            The site may share user data with third parties that ';
            }
            if ($privacy_share_data_partners == 'pri_YES') {
                $var .= ' help the site owner operate and manage the site,';
            }
            if ($privacy_share_data_ads == 'pri_YES') {
                $var .= ' are the site owner s advertisers and marketing partners,';
            }
            if ($privacy_share_data_unlimited == 'pri_YES') {
                $var .= ' buy or rent data for purposes not limited to operating this site.';
            }
            if ($privacy_share_data_agr == 'pri_YES') {
                $var .= 'The site will only share such user data with these third parties in the aggregate, using collected data reporting on user activity and data that the site collects, but not identifying individual users. Information limited to or identifying individual site users will not be shared.';
            }
            if ($privacy_california == 'pri_YES') {
                $var .= '<br/><br/><b>California Privacy Rights</b>

                California Civil Code Section 1798.83 permits Site users who are residents of California to request and receive once a year a list of any third parties to whom we disclosed any of that user s personal information for direct marketing purposes in the preceding calendar year, as well as the categories of personal information disclosed.';
                if (($privacy_email != '') || ($privacy_mail != '')) {
                    $var .= 'If you are a California resident and you wish to make such a request or have any questions about the Site s information sharing';
                }
                if ($privacy_email != '') {
                    $var .= ', you may send an email to ' . $privacy_email;
                }
                if ($privacy_mail != '') {
                    $var .= ', you may write to ' . $privacy_mail;
                }
                if (($privacy_email != '') || ($privacy_mail != '')) {
                    $var .= '.';
                }
                $var .= 'See more at: <a href="http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf" target="_blank">http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf</a>.';
            }
            $var .= '<br/><br/><b>How does our site handle Do Not Track signals?</b>
            
            We honor Do Not Track signals and Do Not Track, plant cookies, or use advertising when a Do Not Track (DNT) browser mechanism is in place.';
            $var .= '<br/><br/><b>Mobile Device Privacy</b>

            The following applies to our site, when viewed on a mobile device:
            When accessed with a mobile deivce, our site may collect information automatically, such as the type of mobile device you have, device identifiers, and information about your use of the site. Regardless of the device you use to access the site, it will also collect information you provide, as well as information about your interaction with the site and its content.
            If location services are activated on your mobile device, our site may collect information about the location of your device. Your mobile network service providers may collect device-specific information, such as a device identifier, when you use our website or one of our mobile applications. This information collected by your mobile network service will not be associated with your user account with us, or with your personally identifiable information.';
            if ($privacy_ssl == 'pri_YES') {
                $var .= '<br/><br/><b>Protection of user information</b>

            We work to protect the security of your information during transmission by using Secure Sockets Layer (SSL) software, which encrypts information you share with the site.
            The Site also protects your account data by using HTTPS transfer protocol.  This is a widely used and more secure communications protocol. ';
            }
            if ($privacy_ads == 'pri_YES') {
                $var .= '<br/><br/><b>Advertising Network</b>
                
            We use one or more third party vendors to serve ads on the Site. To serve ads and determine how our users use the Site, these services use cookies, or small pieces of code to serve ads to Site users based on users’ visits to the Site and others. Users may adjust their browser settings to disallow the use of cookies.  With cookies turned off, certain features of the Site may work less efficiently or not at all.';
            }
            if ($privacy_adsense == 'pri_YES') {
                $var .= 'We use Google as an advertising services provider for the Site. Users may opt out of Google’s use of the DART use-tracking cookie by visiting the Google advertising Policies & Principles page.  If you opt out of ad tailoring, you will still see ads, but they will not be based on your browsing history, and they may appear in other languages.';
                $var .= 'Users can set preferences for how Google advertises to you using the Google Ad Settings page. Alternatively, you can opt out by visiting the Network Advertising Initiative Opt Out page or by using the Google Analytics Opt Out Browser add on.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>Cookies</b>

            This site uses cookies.  Cookies are small pieces of code that the Site or a service provider will put on your computer if your Web browser allows it.  The Site uses cookies to recognize and keep certain information.  On the Site, that information may be used to recognize your computer and browser from current or past visits to the Site or related sites.  We may use this cookie-captured information to improve our service to you, to aggregate information about visitors to the Site and their behavior, to remember and process items in your shopping cart, to understand and save user preferences, or to keep track of advertising.  We may contract with third-party service providers to assist us in better understanding our site visitors.
            In most Internet browsers, you can change your settings so that you will be warned each time a cookie is being sent, or so that cookies will be turned off. With cookies blocked, some functions of the Site may not operate properly.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>Usernames, Passwords, and Profiles</b>

            If prompted, Users must provide a valid email address to the Site, at which the User can receive messages. User must also update the Site if that email address changes. The Site reserves the right to terminate any User account if a valid email is requested but is not provided by the User.
            If the Site prompts or allows a User to create a username or profile, Users agree not to pick a username or provide any profile information that would impersonate someone or that is likely to cause confusion with any other person or entity.  The Site reserves the right to cancel a User account or change a username or profile data at any time.  Similarly, if the Site prompts or allows a User to create an avatar or upload a picture, User agrees not to use any image that impersonates some other person or entity, or that is otherwise likely to cause confusion.
            You are responsible for protecting your username and password for the Site, and you agree not to disclose it to any third party.  We recommend that you use a passwork that is more than eight characters long.  You are responsible for all activity on your account, whether or not you authorized it.';
                if ($privacy_owner_email != '') {
                    $var .= 'You agree to inform us of unauthorized use of your account, by email to ' . $privacy_owner_email . '.';
                }
                $var .= ' You acknowledge that if you wish to protect your interactions the Site, it is your responsibility to use a secure encrypted connection, virtual private network, or other appropriate measures.';
            }
            if ($privacy_owner_loc != '') {
                $var .= '<br/><br/><b>Disputes</b>

            We are based in ' . $privacy_owner_loc . ' and you are contracting to use our Site.  This Policy and all matters arising from your use of the Site are governed by and will be construed according to the laws of ' . $privacy_owner_loc . ', without regard to any choice of laws rules of any jurisdiction.  The federal courts and state courts that have geographical jurisdiction over disputes arising at our office location in ' . $privacy_owner_loc . ' will be the only permissible venues for any and all disputes arising out of or in connection with this Policy or the Site and Service.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>ARBITRATION</b>

            Notwithstanding anything that may be contrary within the "Disputes" provisions above, all matters, and all claims within a multi-claim matter, that are arbitrable, including all claims for monetary damages, shall be decided by a single arbitrator to be selected by us';
                if ($privacy_owner_loc != '') {
                    $var .= ', who shall hold hearings in or near ' . $privacy_owner_loc;
                }
                $var .= ', under the rules that apply.';
            }
            if ($privacy_child != 'pri_YES') {
                $var .= '<br/><b>COPPA (Children Online Privacy Protection Act)</b>

            When it comes to the collection of personal information from children under the age of 13 years old, the Children s Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, United States consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect childrens privacy and safety online.
            We do not specifically market to children under the age of 13 years old.';
            }
            $var .= '<br/><br/><b>Fair Information Practices</b>
            
            The Fair Information Practices Principles form the backbone of privacy law in the United States and the concepts they include have played a significant role in the development of data protection laws around the globe. Understanding the Fair Information Practice Principles and how they should be implemented is critical to comply with the various privacy laws that protect personal information.';
            
            $var .= '<br/><br/><b>Changes to the Site and the Services</b>

            The owners and contributors to the Site will work to improve the Site for our users, and to further our business interests in the Site. We reserve the right to add, change, and remove features, content, and data, including the right to add or change any pricing terms.  You agree that we will not be liable for any such changes.  Neither your use of the Site nor these terms give you any right, title, or protectable legal interest in the Site or its content.
            We reserve the right, at its sole discretion, to modify or replace any part of this Privacy Policy. It is your responsibility to check this Privacy Policy periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Privacy Policy constitutes acceptance of those changes.';
            
            if ($privacy_owner_email != '') {
                $var .= '<br/><br/><b>Terms Contact</b>

            If you have any questions about these Terms, please address them to ' . $privacy_owner_email . '.
            ';
            }
            if ($privacy_added_text != '') {
                $var .= '<br/><br/><b>Notes</b><br/><br/>'.$privacy_added_text;
            }
            $var .= '<br/><br/><b>Last Updated</b>

            These terms were last updated on *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';
        }
        elseif($language == 'German') // German
        {
            $var .= 'Diese privacy policy ("Policy") und die Allgemeinen Geschäftsbedingungen (zusammen die "Bedingungen") gelten für die Nutzung der' . get_home_url() . ' Und dass die Dienstleistungen (zusammen die "Website" oder die "Services"). Die Eigentümer und die Mitarbeiter vor Ort werden nachstehend als "wir", "uns" oder "unser" in dieser Politik. Durch die Nutzung der Website oder ihrer Dienste, und/oder indem Sie auf eine beliebige Stelle auf dieser Website stimmen Sie den Bedingungen dieser Politik, und sie gelten als "user" für die Zwecke dieser Richtlinie. Sie und alle anderen Benutzer ("Sie", "Ihnen" oder "Benutzer") sind Gegenstand dieser Richtlinien. Sie und jeder Nutzer erklären sich einverstanden, die durch die Nutzung der Dienste. In dieser Hinsicht, das Wort "Website" die Website enthält oben verwiesen, dessen Eigentümer(s), Mitarbeiter, Lieferanten, Lizenzgeber und anderen verbundenen Unternehmen.

            Wir bieten diese Datenschutzerklärung erklären unsere Online-Verfahren, so dass Sie entscheiden können, ob und wie die Interaktion mit der Website und der Dienstleistungen.

Wir können Ihre Informationen, halten wir es für angebracht, im Einklang mit dem Gesetz, die Durchsetzung von Richtlinien, unsere Website oder unsere schützen oder andere Rechte, das Eigentum oder die Sicherheit.

Diese Online Privacy Policy gilt nur für die Informationen, die durch unsere Website und nicht auf Daten, die offline erfasst werden.

Bitte beachten Sie auch unsere <b>Nutzungsbedingungen</b> Abschnitt regelt, dass der Einsatz und die Nutzer der Website.

Durch die Nutzung unserer Website erklären Sie sich mit unseren <b>Datenschutz</b>.

Wenn wir uns entscheiden, unsere Datenschutzerklärung zu ändern, werden wir diese Änderungen auf dieser Seite veröffentlichen. Wenn wir Ihre e-mail Adresse, wir können uns auch eine e-Mail, in der Sie benachrichtigt Sie über Änderungen.';
            if ($privacy_collect_data == 'pri_YES') {
                $var .= '<br/><br/><b>Kontakt Daten und anderen Daten</b>

                Diese Website sammelt bestimmte Benutzerinformationen, die auch einen Benutzernamen und ein Kennwort, Kontaktinformationen und andere Daten, die Sie auf der Website. Sie können auch Ihre IP-Adresse zu ermitteln, die Sie für zukünftige Besuche auf der Website. Nach unserem Ermessen, die Website kann diese Daten verwenden, um:

* Anpassen der Benutzer- und/oder Kundendienst
* Verbesserung der Website
*, um Transaktionen zu verarbeiten
* Verwalten eines Wettbewerbs, Förderung, einer Umfrage oder einer anderen Funktion oder Funktion
* Senden Sie eine E-Mail an Benutzer';
            }
            $var .= '<br/><br/><b>Sammeln von Informationen Personally-Identifying</b>
            
            Einige der Besucher unserer Websites wählen Sie die Interaktion mit unserer Website in einer Weise, die uns persönlich identifizierbaren Informationen sammeln. Die Menge und die Art der Informationen, die WEF-sammelt, hängt von der Art der Interaktion. Zum Beispiel bitten wir Besucher, registrieren Sie sich auf unserer Webseite einen Benutzernamen und E-Mail-Adresse. Diejenigen, die in Transaktionen mit uns aufgefordert, zusätzliche Informationen zur Verfügung zu stellen, einschließlich, soweit notwendig die persönlichen und finanziellen Informationen, die für die Bearbeitung der Transaktionen.
In jedem Fall ist, sammeln wir solche Informationen nur soweit erforderlich oder angemessen ist, um den Zweck zu erfüllen, von der Interaktion mit uns. Wir geben keine persönlich identifizierbaren Informationen, wie unten beschrieben. Und die Besucher können immer weigern, die persönlich identifizierbaren Informationen, mit dem Vorbehalt, dass es kann verhindern, dass Sie sich in bestimmten Website-bezogene Aktivitäten.';
            $var .= '<br/><br/><b>Schutz von bestimmten Personally-Identifying Informationen</b>
            
            Wir legen möglicherweise persönlich identifizieren und persönlich identifizierbaren Informationen nur an diejenigen seiner Mitarbeiter, Auftragnehmer und verbundenen Unternehmen, die (i) diese Informationen kennen müssen, um es in unserem Namen oder zur Bereitstellung von Dienstleistungen auf unseren Webseiten, und (ii), die zugestimmt haben, nicht weitergeben an Andere.
Einige dieser Mitarbeiter, Auftragnehmer und verbundenen Organisationen können sich außerhalb Ihres Heimatlandes; durch die Nutzung unserer Websites erklären Sie Ihr Einverständnis mit der Übertragung dieser Informationen an Sie. Wir verkaufen oder vermieten keine potenziell persönlich identifizieren und persönlich identifizierbaren Informationen. Anders als seine Mitarbeiter, Auftragnehmer und verbundenen Organisationen, wie oben beschrieben, Wir legen möglicherweise persönlich identifizieren und persönlich identifizierbaren Informationen nur als Reaktion auf eine Vorladung, eine gerichtliche Anordnung oder andere behördliche Anfrage, oder wenn wir in gutem Glauben der Ansicht sind, dass die Offenlegung erforderlich ist unser Eigentum zu schützen oder die Rechte von Dritten oder der Öffentlichkeit. Wenn Sie ein registrierter Nutzer unserer Website und Ihre e-mail Adresse geliefert haben, können wir gelegentlich senden Sie eine e-Mail zu informieren Sie über neue Funktionen, um Ihr Feedback, oder einfach nur um sie auf dem Laufenden mit dem, was passiert mit unseren Produkten.
Wenn Sie eine Anfrage an uns senden (z. B. per E-Mail oder über eines unserer Feedback-mechanismen), behalten wir uns das Recht, ihn zu veröffentlichen, um uns zu helfen, erklären oder auf Ihre Anfrage zu reagieren oder um uns zu helfen, die Unterstützung anderer Benutzer. Wir ergreifen alle notwendigen Maßnahmen zum Schutz gegen den unbefugten Zugriff, Verwendung, Änderung oder Zerstörung von möglicherweise persönlich identifizieren und persönlich identifizierbaren Informationen.';
            if ($privacy_share_data == 'pri_YES') {
                $var .= '<br/><br/><b>Die gemeinsame Nutzung von Daten</b>

            Wie die meisten Webseitenbetreiber, sammeln wir nicht persönlich identifizierbaren Informationen von der Art, Web Browser und Server werden in der Regel zur Verfügung stellen, wie z. B. die Art des Browsers, Sprache, Ort, Datum und Uhrzeit der Anfrage jedes Besuchers. Unser Ziel bei der Erfassung von nicht-personenbezogenen Informationen, um besser zu verstehen, wie unsere Besucher diese Website. Von Zeit zu Zeit können wir nicht persönlich identifizierbaren Informationen, z. B. durch die Veröffentlichung eines Berichts über die Trends bei der Nutzung der Website.
Darüber hinaus erfassen wir möglicherweise persönlich identifizierende Informationen wie IP-Adressen (Internet Protocol) für den angemeldeten Benutzer und für Benutzer Kommentare auf unseren Blogs/Websites. Wir offenbart nur angemeldete Benutzer und commenter IP-Adressen unter den gleichen Umständen, die es verwendet und persönlich identifizierbaren Informationen, wie unten beschrieben, mit der Ausnahme, dass commenter IP-Adressen und E-Mail-Adressen werden sichtbar und die Administratoren der Website/Blog, wo der Kommentar war.
Die Website kann der Benutzer Daten gemeinsam mit Dritten,';
            }
            if ($privacy_share_data_partners == 'pri_YES') {
                $var .= ' die Eigentümer der Website Betreiben und Verwalten der Site,';
            }
            if ($privacy_share_data_ads == 'pri_YES') {
                $var .= ' sind die Eigentümer der Website s Inserenten und Partner Marketing,';
            }
            if ($privacy_share_data_unlimited == 'pri_YES') {
                $var .= ' kaufen oder mieten Sie Daten für Zwecke, die nicht beschränkt auf den Betrieb dieser Website.';
            }
            if ($privacy_share_data_agr == 'pri_YES') {
                $var .= 'Die Website wird nur solche Daten mit diesen Dritten in das Aggregat, mit gesammelten Daten über Benutzer und Daten, die die Website sammelt, aber nicht die Identifizierung einzelner Benutzer. Informationen beschränkt, oder die Identifizierung einzelner Benutzer der Website werden nicht weitergegeben.';
            }
            if ($privacy_california == 'pri_YES') {
                $var .= '<br/><br/><b>California Privacy Rights</b>

                California Civil Code 1798.83 erlaubt Benutzern, die Einwohner von Kalifornien nach Anfrage und Sie erhalten einmal im Jahr eine Liste mit allen Dritten, denen wir bekannt gegeben, dass der Benutzer persönliche Informationen für Zwecke der Direktwerbung im vorangegangenen Kalenderjahr, sowie die Kategorien von persönlichen Informationen.';
                if (($privacy_email != '') || ($privacy_mail != '')) {
                    $var .= 'Wenn Sie in Kalifornien ansässig und Sie möchten eine solche Anfrage oder Fragen über die Website s die gemeinsame Nutzung von Informationen';
                }
                if ($privacy_email != '') {
                    $var .= ', Sie können eine E-Mail an senden. ' . $privacy_email;
                }
                if ($privacy_mail != '') {
                    $var .= ', Sie können schreiben Sie an ' . $privacy_mail;
                }
                if (($privacy_email != '') || ($privacy_mail != '')) {
                    $var .= '.';
                }
                $var .= 'Erfahren Sie mehr unter: <a href="http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf" target="_blank">http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf</a>.';
            }
            $var .= '<br/><br/><b>Wie funktioniert unsere Seite nicht verarbeiten die Signale der Spuren?</b>
            
            Wir verfolgen nicht, Signale und Nicht, Cookies, oder verwenden Sie die Werbung, wenn ein Nicht-Spur (DNT) browser Mechanismus vorhanden ist.';
            $var .= '<br/><br/><b>Datenschutz für mobile Geräte</b>

            Das gilt für unsere Website, wenn Sie auf einem mobilen Gerät:
Beim Zugriff mit einem mobilen deivce, unsere Website können Informationen automatisch, wie z. B. die Art der mobilen Gerät, das Sie haben, Gerätekennungen und Informationen über Ihre Nutzung der Website. Unabhängig von dem Gerät, das Sie verwenden, um auf die Website zuzugreifen, wird es auch das Sammeln von Informationen, die Sie zur Verfügung stellen, sowie Informationen über ihre Interaktion mit der Website und ihrer Inhalte.
Wenn die Ortungsdienste aktiviert sind auf Ihrem mobilen Gerät, unsere Website können Informationen über den Standort des Geräts. Ihre mobile Network Service Provider erfassen möglicherweise gerätespezifische Informationen, z. B. eine Geräte-ID, wenn Sie unsere Website benutzen oder einem unserer mobilen Anwendungen. Diese Informationen werden von Ihrem mobilen Netzwerk Service wird nicht im Zusammenhang mit Ihrem Konto bei uns, oder mit Ihren persönlich identifizierbaren Informationen.';
            if ($privacy_ssl == 'pri_YES') {
                $var .= '<br/><br/><b>Schutz von Benutzerdaten</b>

            Wir arbeiten, um die Sicherheit Ihrer Informationen während der Übertragung durch die Verwendung von Secure Sockets Layer (SSL) Software, die Informationen verschlüsselt, die Sie mit der Site.
Die Website schützt Ihre Daten durch die Verwendung von HTTPS-Protokoll übertragen. Dies ist eine weit verbreitete und sicherer Kommunikation. ';
            }
            if ($privacy_ads == 'pri_YES') {
                $var .= '<br/><br/><b>Werbung Netzwerk</b>
                
            Wir verwenden eine oder mehrere Drittanbieter, um Anzeigen auf der Website. Ads zu dienen und zu bestimmen, wie unsere Nutzer die Website verwenden, werden diese Dienstleistungen Cookies verwenden, oder kleine Stücke von Code, um Anzeigen zu schalten, um Benutzern der Website auf der Grundlage der Besuche auf der Website und anderen. Benutzer können die Einstellungen Ihres Browsers ändern, um die Verwendung von Cookies nicht zulassen. Mit Cookies deaktiviert, können bestimmte Funktionen der Website funktionieren möglicherweise weniger effizient ist oder nicht.';
            }
            if ($privacy_adsense == 'pri_YES') {
                $var .= 'Wir verwenden Google als Dienstleister für den Standort. Benutzer können sich aus der Verwendung des DART-Cookies deaktivieren, indem Sie die Verfolgung von Google Werbung Richtlinien und Grundsätze. Wenn Sie die Opt-out-Anzeige anpassen, werden Sie immer noch sehen, aber Sie werden nicht auf der Grundlage der Browserverlauf gelöscht, und Sie können in andere Sprachen.';
                $var .= 'Benutzer können Einstellungen für Google wirbt, wie Sie mithilfe der Google Ad-Einstellungen. Alternativ können Sie durch den Besuch der Network Advertising Initiative Opt-out-Seite oder durch die Verwendung der Google Analytics Opt-out-Browser Add-on.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>Cookies</b>

            Diese Website verwendet Cookies. Cookies sind kleine Teile des Codes, die Website oder ein Service Provider wird auf Ihrem Computer, wenn Ihr Browser dies zulässt. Die Site verwendet Cookies, um bestimmte Informationen zu erkennen und zu halten. Auf der Website, die Informationen können verwendet werden, um Ihren Computer zu erkennen und Browser von aktuellen oder früheren Besuche auf der Website oder Websites. Wir verwenden dieses Cookie erfassten Informationen, um unseren Service für Sie zu verbessern, um Informationen über die Besucher der Website und deren Verhalten, um sich zu erinnern und Prozess Artikel im Warenkorb, zu verstehen und zu speichern, oder zu behalten. Wir können mit Drittanbietern zu unterstützen und uns bei der Besucher unserer Website besser zu verstehen.
In den meisten Internet-Browsern, können Sie Ihre Einstellungen so ändern, dass Sie gewarnt werden, wenn ein Cookie gesendet wird, oder so, dass die Cookies ausgeschaltet werden. Mit Cookies blockiert werden, einige Funktionen der Website möglicherweise nicht ordnungsgemäß funktionieren.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>Benutzernamen, Kennwörter und Profile</b>

            Wenn Sie dazu aufgefordert werden, muss der Benutzer eine gültige E-Mail-Adresse an den Ort, an dem sich der Benutzer Nachrichten empfangen werden können. Der Benutzer muss die Aktualisierung auch vor Ort, wenn diese e-mail Adresse ändert. Die Site behält sich das Recht vor, jederzeit zu beenden, wenn ein Benutzerkonto ist eine gültige E-Mail-Adresse angefordert, aber nicht durch den Benutzer.
Wenn die Website fordert oder erlaubt einem Benutzer, erstellen Sie einen Benutzernamen oder ein Profil, Benutzer erklären sich damit einverstanden, dass ein Benutzername oder eine beliebige Informationen, die die Identität einer Person oder, dass damit zu rechnen ist, dass eine Verwechslung mit einer anderen Person oder einer juristischen Person. Die Site behält sich das Recht vor, ein Benutzerkonto zu löschen oder Ändern eines Benutzernamens oder Profildaten zu jeder Zeit. Ebenso, wenn die Website fordert oder erlaubt einem Benutzer, einen Avatar erstellen oder ein Bild hochladen, der Benutzer stimmt nicht mit jedem Bild, das die Identität einer anderen Person oder Körperschaft oder sonst Verwirrung zu stiften.
Sie sind verantwortlich für den Schutz Ihres Benutzernamens und Kennworts für die Website, und Sie erklären sich damit einverstanden, dass sie weitergeben an Dritte. Wir empfehlen, dass Sie eine passwork, die mehr als acht Zeichen lang sein. Sie sind verantwortlich für alle Aktivitäten auf Ihrem Konto, unabhängig davon, ob Sie berechtigt sind oder nicht.';
                if ($privacy_owner_email != '') {
                    $var .= 'Sie stimmen zu, uns zu informieren, um die unbefugte Benutzung Ihres Kontos per E-Mail. ' . $privacy_owner_email . '.';
                }
                $var .= ' Sie bestätigen, dass Sie, wenn Sie wünschen, ihre Interaktionen zu schützen, liegt es in Ihrer Verantwortung, eine sichere, verschlüsselte Verbindung verwenden, Virtual Private Network, virtuelles privates Netzwerk, oder andere geeignete Maßnahmen ergreifen.';
            }
            if ($privacy_owner_loc != '') {
                $var .= '<br/><br/><b>Streitigkeiten</b>

            Wir sind in ' . $privacy_owner_loc . ' Und Sie zur Nutzung unserer Website. Diese Richtlinie und alle Angelegenheiten, die sich aus der Nutzung der Site unterliegen und werden ausgelegt nach den Gesetzen der ' . $privacy_owner_loc . ', Ohne Rücksicht auf die Wahl der gesetzlichen Vorschriften einer Gerichtsbarkeit. Der eidgenössischen Gerichte und der staatlichen Gerichte, die geografische Zuständigkeit für Streitigkeiten in unserem Büro in der Lage ' . $privacy_owner_loc . ' Die einzige zulässige Veranstaltungsorte für alle Streitigkeiten aus oder im Zusammenhang mit dieser Richtlinie oder die Website und Service.';
            }
            if ($privacy_cookies == 'pri_YES') {
                $var .= '<br/><br/><b>Schiedsverfahren</b>

            Ungeachtet der möglicherweise im Widerspruch innerhalb der "Streitigkeiten" Bestimmungen über alle Fragen, und alle Ansprüche innerhalb einer multi-behaupten, dass die arbitrable, einschließlich aller Ansprüche auf Schadenersatz, wird von einem einzigen Schiedsrichter zu von uns ausgewählt werden.';
                if ($privacy_owner_loc != '') {
                    $var .= ', die Anhörungen in oder in der Nähe von ' . $privacy_owner_loc;
                }
                $var .= ', unter die Regeln, die gelten.';
            }
            if ($privacy_child != 'pri_YES') {
                $var .= '<br/><b>COPPA (Children Online Privacy Protection Act)</b>

            Wenn es um die Sammlung personenbezogener Informationen von Kindern unter dem Alter von 13 Jahren, die Kinder s Online Privacy Protection Act (COPPA) setzt Eltern in der Steuerung. Die Federal Trade Commission der Vereinigten Staaten, Verbraucherschutz, erzwingt die COPPA Rule, die Zaubersprüche heraus, was die Betreiber von Websites und Online Dienste müssen zum Schutz der Privatsphäre und die Sicherheit der Kinder online.
Wir nicht speziell für Kinder unter dem Alter von 13 Jahren.';
            }
            $var .= '<br/><br/><b>Fair Information Practices</b>
            
            Die Fair Information Practices Prinzipien bilden das Rückgrat der Datenschutz in den Vereinigten Staaten und der Konzepte, die Sie gespielt haben, gehören eine bedeutende Rolle in der Entwicklung des Datenschutzes rund um den Globus. Die Fair Information Practice Principles und wie sie umgesetzt werden soll, ist von entscheidender Bedeutung für die Einhaltung der verschiedenen Datenschutzbestimmungen zum Schutz persönlicher Informationen.';
            $var .= '<br/><br/><b>Änderungen an der Website und der Dienstleistungen</b>

            Die Eigentümer und die Mitarbeiter auf die Website wird zur Verbesserung der Website für unsere Nutzer weiter zu unserem geschäftlichen Interessen in der Website. Wir behalten uns das Recht vor, Hinzufügen, Ändern und Entfernen von Funktionen, Inhalte und Daten, einschließlich des Rechts auf Hinzufügen oder Ändern Sie die Preisgestaltung. Sie erklären sich damit einverstanden, dass wir haften nicht für etwaige Änderungen. Weder die Nutzung der Website und diese Bedingungen keinerlei Rechte, Titel oder Schützbaren rechtliches Interesse an der Website oder ihren Inhalt.
Wir behalten uns das Recht vor, nach eigenem Ermessen zu ändern oder ersetzen Sie alle Teil dieser Datenschutzrichtlinie. Es liegt in Ihrer Verantwortung, diese Datenschutzbestimmungen regelmäßig auf Änderungen. Ihre fortgesetzte Nutzung der Website oder den Zugriff auf die Website nach der Veröffentlichung von Änderungen an dieser Datenschutzrichtlinie stellt die Annahme dieser Änderungen.';
            
            if ($privacy_owner_email != '') {
                $var .= '<br/><br/><b>Agb Kontakt</b>

            Wenn Sie Fragen zu diesen Nutzungsbedingungen haben, wenden Sie sich bitte an ' . $privacy_owner_email . '.
            ';
            }
            if ($privacy_added_text != '') {
                $var .= '<br/><br/><b>Hinweise</b><br/><br/>'.$privacy_added_text;
            }
            $var .= '<br/><br/><b>Letzte Aktualisierung</b>

            Diese Nutzungsbedingungen wurden zuletzt aktualisiert am *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';

        }
        
        if (!$the_page) {
            
            // Create post object
            $_p               = array();
            $_p['post_title'] = $the_page_title;
            
            $_p['post_content']   = $var;
            $_p['post_status']    = 'publish';
            $_p['post_type']      = 'page';
            $_p['comment_status'] = 'closed';
            $_p['ping_status']    = 'closed';
            $_p['post_category']  = array(
                1
            ); // the default 'Uncatrgorised'
            
            // Insert the post into the database
            $the_page_id = wp_insert_post($_p);
            
        } else {
            
            //make sure the page is not trashed...
            $the_page->post_content = $var;
            $the_page->post_status  = 'publish';
            $the_page_id            = wp_update_post($the_page);
            
        }
        
        delete_option('privacy_policy_id');
        add_option('privacy_policy_id', $the_page_id);
    } else {
        legalize_my_plugin_remove();
    }
}

function legalize_my_plugin_remove()
{
    
    global $wpdb;
    //  the id of our page...
    $the_page_id = get_option('privacy_policy_id');
    if ($the_page_id) {
        
        wp_delete_post($the_page_id, true);
        
    }
    delete_option("privacy_policy_id");
    
}
function legalize_fortune_ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array(
        "name",
        "\n",
        "\t",
        " ",
        "-",
        "_"
    ), NULL, strtolower(trim($purpose)));
    $support    = array(
        "country",
        "countrycode",
        "state",
        "region",
        "city",
        "location",
        "address"
    );
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array(
                        $ipdat->geoplugin_countryName
                    );
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

function legalize_fortune_is_in_EU()
{
    $europe = array(
        'AD',
        'AL',
        'AT',
        'AX',
        'BA',
        'BE',
        'BG',
        'BY',
        'CH',
        'CZ',
        'DE',
        'DK',
        'EE',
        'ES',
        'FI',
        'FO',
        'FR',
        'GB',
        'GG',
        'GI',
        'GR',
        'HR',
        'HU',
        'IE',
        'IM',
        'IS',
        'IT',
        'JE',
        'LI',
        'LT',
        'LU',
        'LV',
        'MC',
        'MD',
        'ME',
        'MK',
        'MT',
        'NL',
        'NO',
        'PL',
        'PT',
        'RO',
        'RS',
        'RU',
        'SE',
        'SI',
        'SJ',
        'SK',
        'SM',
        'UA',
        'UK',
        'VA'
    );
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $real_ip_adress = $_SERVER['REMOTE_ADDR'];
        }
    }
    
    $cip          = $real_ip_adress;
    $country_code = legalize_fortune_ip_info($real_ip_adress, "Country Code");
    if ($country_code === NULL) {
        return true;
    }
    if (in_array($country_code, $europe)) {
        return true;
    } else {
        return false;
    }
}
add_action('admin_enqueue_scripts', 'privacy_load_admin_things');
add_filter("plugin_action_links_$plugin", 'privacy_add_settings_link');
add_action('admin_init', 'privacy_register_mysettings');
function privacy_register_mysettings()
{
    register_setting('privacy_option_group', 'privacy_Main_Settings');
    register_setting('privacy_option_group2', 'privacy_Terms_Settings');
    register_setting('fortune_option_group2', 'legalize_fortune_Main_Settings');
    if(is_multisite())
    {
        if (!get_option('privacy_Main_Settings'))
        {
            legalize_activation_callback(TRUE);
            legalize_fortune_activation_callback(TRUE);
        }
    }
}

add_action('wp_footer', 'privacy_popup_footer_content');
function privacy_popup_footer_content()
{
    $privacy_Main_Settings = get_option('privacy_Main_Settings', false);
?><script type="text/javascript">
        var $privacy_Main_Settings = JSON.parse('<?php
    echo json_encode($privacy_Main_Settings);
?>');
        </script><?php
}
add_action('admin_enqueue_scripts', 'privacy_admin_load_files');
function privacy_admin_load_files()
{
    wp_register_style('privacy-popup-style', plugins_url('styles/legalize-privacy.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('privacy-popup-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('privacy-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('privacy-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('privacy-settings-app', plugins_url('res/privacy-angular.js', __FILE__), array(), '1.0.0', true);
}

function legalize_fortune_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function legalize_fortune_get_file_url($url)
{
    return legalize_fortune_get_plugin_url() . '/' . $url;
}

function legalize_validate_register_form($errors, $sanitized_user_login, $user_email) {
    if ( isset( $_REQUEST['legalize_register_accept'] ) && $_REQUEST['legalize_register_accept'] == 'on' ) {
        return $errors;
    } else {
        $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
        if (isset($privacy_Terms_Settings['register_checkbox_error_text'])) 
        {
            $message = $privacy_Terms_Settings['register_checkbox_error_text'];
        }
        else
        {
            $message = 'You must accept the terms of service first!';
        }
        $errors->add( 'did_not_accept', $message);
    }
    return $errors;
}
function legalize_register_form(){
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    $text = '';
    if (isset($privacy_Terms_Settings['register_checkbox_text'])) 
    {
        $message = $privacy_Terms_Settings['register_checkbox_text'];
    }
    else
    {
        $message = 'I agree to the Terms of Service';
    }
    if (isset($privacy_Terms_Settings['register_checkbox_link']) && $privacy_Terms_Settings['register_checkbox_link'] == 'on') 
    {
        $text .= '<label><input type="checkbox" name="legalize_register_accept" id="legalize_register_accept"/>&nbsp;<a href="' . get_page_link(get_option('terms_policy_id')) . '" target="_blank">' . $message . '</a></label>';
    }
    else
    {
        $text .= '<label><input type="checkbox" name="legalize_register_accept" id="legalize_register_accept"/> ' . $message . '</label>';
    }
    if (isset($privacy_Terms_Settings['register_checkbox_newline']) && $privacy_Terms_Settings['register_checkbox_newline'] == 'on') 
    {
        $text .= '<br/><br/>';
    }
    echo $text;
}
function legalize_wp_authenticate_user($user, $password) {
    if ( isset( $_REQUEST['legalize_login_accept'] ) && $_REQUEST['legalize_login_accept'] == 'on' ) {
        return $user;
    } else {
        $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
        if (isset($privacy_Terms_Settings['login_checkbox_error_text'])) 
        {
            $message = $privacy_Terms_Settings['login_checkbox_error_text'];
        }
        else
        {
            $message = 'You must accept the terms of service first!';
        }
        $error = new WP_Error();
        $error->add('did_not_accept', $message );
        return $error;
    }
}

function legalize_login_form(){
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    $text = '';
    if (isset($privacy_Terms_Settings['login_checkbox_text'])) 
    {
        $message = $privacy_Terms_Settings['login_checkbox_text'];
    }
    else
    {
        $message = 'I agree to the Terms of Service';
    }
    if (isset($privacy_Terms_Settings['login_checkbox_link']) && $privacy_Terms_Settings['login_checkbox_link'] == 'on') 
    {
        $text .= '<label><input type="checkbox" name="legalize_login_accept" id="legalize_login_accept"/>&nbsp;<a href="' . get_page_link(get_option('terms_policy_id')) . '" target="_blank">' . $message . '</a></label>';
    }
    else
    {
        $text .= '<label><input type="checkbox" name="legalize_login_accept" id="legalize_login_accept"/> ' . $message . '</label>';
    }
    if (isset($privacy_Terms_Settings['login_checkbox_newline']) && $privacy_Terms_Settings['login_checkbox_newline'] == 'on') 
    {
        $text .= '<br/><br/>';
    }
    echo $text;
}

function legalize_add_login_register_checkbox()
{
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    if (isset($privacy_Terms_Settings['terms_enabled']) && $privacy_Terms_Settings['terms_enabled'] == 'on') 
    {
        if (isset($privacy_Terms_Settings['login_checkbox']) && $privacy_Terms_Settings['login_checkbox'] == 'on') 
        {
            add_filter('wp_authenticate_user', 'legalize_wp_authenticate_user', 99999, 2);
            add_filter('login_form', 'legalize_login_form' );
        }
        if (isset($privacy_Terms_Settings['register_checkbox']) && $privacy_Terms_Settings['register_checkbox'] == 'on') 
        {
            add_filter('registration_errors', 'legalize_validate_register_form', 10, 3);
            add_filter('register_form', 'legalize_register_form' );
        }
    }
}
add_action('init', 'legalize_add_login_register_checkbox');

add_action('template_redirect', 'legalize_fortune_add_browser_popup_panel');
function legalize_fortune_add_browser_popup_panel()
{
    $fortune_Main_Settings = get_option('legalize_fortune_Main_Settings', false);
    if(isset($fortune_Main_Settings['fortune_font_type']))
    {
        $fortune_Main_Settings['fortune_font_type'] = str_replace('"', "", $fortune_Main_Settings['fortune_font_type']);
        update_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
    }
    if(isset($_COOKIE['fortune_show']))
    {
        $cookie_val = $_COOKIE['fortune_show'];
    }
    else
    {
        $cookie_val = '0';
    }
    if ($cookie_val == '1') {
        $GLOBALS['COOKIE_SET'] = 'true';
    }
    if (isset($fortune_Main_Settings['fortune_dnt_check'])) {
        $fortune_dnt_check = $fortune_Main_Settings['fortune_dnt_check'];
    } else {
        $fortune_dnt_check = '';
    }
    if($fortune_dnt_check === 'on')
    {
        if(isset($_SERVER['HTTP_DNT']) && $_SERVER['HTTP_DNT'] == 1)
        {
            $GLOBALS['dntEnabled'] = true;
        }
    }
    if (isset($fortune_Main_Settings['fortune_popup_once'])) {
        $fortune_popup_once = $fortune_Main_Settings['fortune_popup_once'];
    } else {
        $fortune_popup_once = '';
    }
    if (isset($fortune_Main_Settings['fortune_message'])) {
        $fortune_message = $fortune_Main_Settings['fortune_message'];
    } else {
        $fortune_message = '';
    }
    if (isset($fortune_Main_Settings['fortune_close_message'])) {
        $fortune_close_message = $fortune_Main_Settings['fortune_close_message'];
    } else {
        $fortune_close_message = '';
    }
    if (isset($fortune_Main_Settings['fortune_more_info'])) {
        $fortune_more_info = $fortune_Main_Settings['fortune_more_info'];
    } else {
        $fortune_more_info = '';
    }
    if (isset($fortune_Main_Settings['fortune_more_link'])) {
        $fortune_more_link = $fortune_Main_Settings['fortune_more_link'];
    } else {
        $fortune_more_link = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background'])) {
        $fortune_popup_background = $fortune_Main_Settings['fortune_popup_background'];
    } else {
        $fortune_popup_background = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_text_col'])) {
        $fortune_popup_text_col = $fortune_Main_Settings['fortune_popup_text_col'];
    } else {
        $fortune_popup_text_col = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_links_col'])) {
        $fortune_popup_links_col = $fortune_Main_Settings['fortune_popup_links_col'];
    } else {
        $fortune_popup_links_col = '';
    }
    if (isset($fortune_Main_Settings['fortune_panel_sticks'])) {
        $fortune_panel_sticks = $fortune_Main_Settings['fortune_panel_sticks'];
    } else {
        $fortune_panel_sticks = '';
    }
    if (isset($fortune_Main_Settings['fortune_more_link_text'])) {
        $fortune_more_link_text = $fortune_Main_Settings['fortune_more_link_text'];
    } else {
        $fortune_more_link_text = '';
    }
    if (isset($fortune_Main_Settings['fortune_auto_hide_time'])) {
        $fortune_auto_hide_time = $fortune_Main_Settings['fortune_auto_hide_time'];
    } else {
        $fortune_auto_hide_time = '';
    }
    if (isset($fortune_Main_Settings['fortune_auto_hide'])) {
        $fortune_auto_hide = $fortune_Main_Settings['fortune_auto_hide'];
    } else {
        $fortune_auto_hide = '';
    }
    if (isset($fortune_Main_Settings['fortune_border'])) {
        $fortune_border = $fortune_Main_Settings['fortune_border'];
    } else {
        $fortune_border = '';
    }
    if (isset($fortune_Main_Settings['fortune_border_color'])) {
        $fortune_border_color = $fortune_Main_Settings['fortune_border_color'];
    } else {
        $fortune_border_color = '';
    }
    if (isset($fortune_Main_Settings['fortune_border_width'])) {
        $fortune_border_width = $fortune_Main_Settings['fortune_border_width'];
    } else {
        $fortune_border_width = '';
    }
    if (isset($fortune_Main_Settings['fortune_buttons'])) {
        $fortune_buttons = $fortune_Main_Settings['fortune_buttons'];
    } else {
        $fortune_buttons = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_animation'])) {
        $fortune_popup_animation = $fortune_Main_Settings['fortune_popup_animation'];
    } else {
        $fortune_popup_animation = '';
    }
    if (isset($fortune_Main_Settings['fortune_max_width'])) {
        $fortune_max_width = $fortune_Main_Settings['fortune_max_width'];
    } else {
        $fortune_max_width = '';
    }
    if (isset($fortune_Main_Settings['fortune_fade_background'])) {
        $fortune_fade_background = $fortune_Main_Settings['fortune_fade_background'];
    } else {
        $fortune_fade_background = '';
    }
    if (isset($fortune_Main_Settings['fortune_only_eu'])) {
        $fortune_only_eu = $fortune_Main_Settings['fortune_only_eu'];
    } else {
        $fortune_only_eu = '';
    }
    if (isset($fortune_Main_Settings['fortune_block_cookies'])) {
        $fortune_block_cookies = $fortune_Main_Settings['fortune_block_cookies'];
    } else {
        $fortune_block_cookies = '';
    }
    if (isset($fortune_Main_Settings['fortune_blocked_content'])) {
        $fortune_blocked_content = $fortune_Main_Settings['fortune_blocked_content'];
    } else {
        $fortune_blocked_content = '';
    }
    if (isset($fortune_Main_Settings['fortune_deny_button'])) {
        $fortune_deny_button = $fortune_Main_Settings['fortune_deny_button'];
    } else {
        $fortune_deny_button = '';
    }
    if (isset($fortune_Main_Settings['fortune_deny_button_text'])) {
        $fortune_deny_button_text = $fortune_Main_Settings['fortune_deny_button_text'];
    } else {
        $fortune_deny_button_text = '';
    }
    if (isset($fortune_Main_Settings['fortune_block_all_cookies'])) {
        $fortune_block_all_cookies = $fortune_Main_Settings['fortune_block_all_cookies'];
    } else {
        $fortune_block_all_cookies = '';
    }
    if (isset($fortune_Main_Settings['fortune_disable_loggedin'])) {
        $fortune_disable_loggedin = $fortune_Main_Settings['fortune_disable_loggedin'];
    } else {
        $fortune_disable_loggedin = '';
    }
    if (isset($fortune_Main_Settings['fortune_custom_css'])) {
        $fortune_custom_css = $fortune_Main_Settings['fortune_custom_css'];
    } else {
        $fortune_custom_css = '';
    }
    if (isset($fortune_Main_Settings['fortune_rounded_corners'])) {
        $fortune_rounded_corners = $fortune_Main_Settings['fortune_rounded_corners'];
    } else {
        $fortune_rounded_corners = '';
    }
    if (isset($fortune_Main_Settings['fortune_distance_top'])) {
        $fortune_distance_top = $fortune_Main_Settings['fortune_distance_top'];
    } else {
        $fortune_distance_top = '';
    }
    if (isset($fortune_Main_Settings['fortune_distance_bottom'])) {
        $fortune_distance_bottom = $fortune_Main_Settings['fortune_distance_bottom'];
    } else {
        $fortune_distance_bottom = '';
    }
    if (isset($fortune_Main_Settings['fortune_distance_left'])) {
        $fortune_distance_left = $fortune_Main_Settings['fortune_distance_left'];
    } else {
        $fortune_distance_left = '';
    }
    if (isset($fortune_Main_Settings['fortune_distance_right'])) {
        $fortune_distance_right = $fortune_Main_Settings['fortune_distance_right'];
    } else {
        $fortune_distance_right = '';
    }
    if (isset($fortune_Main_Settings['fortune_padding'])) {
        $fortune_padding = $fortune_Main_Settings['fortune_padding'];
    } else {
        $fortune_padding = '';
    }
    if (isset($fortune_Main_Settings['fortune_new_line'])) {
        $fortune_new_line = $fortune_Main_Settings['fortune_new_line'];
    } else {
        $fortune_new_line = '';
    }
    if (isset($fortune_Main_Settings['fortune_auto_accept'])) {
        $fortune_auto_accept = $fortune_Main_Settings['fortune_auto_accept'];
    } else {
        $fortune_auto_accept = '';
    }
    if (isset($fortune_Main_Settings['fortune_outside_close_accept'])) {
        $fortune_outside_close_accept = $fortune_Main_Settings['fortune_outside_close_accept'];
    } else {
        $fortune_outside_close_accept = '';
    }
    if (isset($fortune_Main_Settings['fortune_outside_close'])) {
        $fortune_outside_close = $fortune_Main_Settings['fortune_outside_close'];
    } else {
        $fortune_outside_close = '';
    }
    if (isset($fortune_Main_Settings['fortune_center_popup'])) {
        $fortune_center_popup = $fortune_Main_Settings['fortune_center_popup'];
    } else {
        $fortune_center_popup = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_style'])) {
        $fortune_popup_style = $fortune_Main_Settings['fortune_popup_style'];
    } else {
        $fortune_popup_style = '';
    }
    if (isset($fortune_Main_Settings['fortune_new_line_all'])) {
        $fortune_new_line_all = $fortune_Main_Settings['fortune_new_line_all'];
    } else {
        $fortune_new_line_all = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background_style'])) {
        $fortune_popup_background_style = $fortune_Main_Settings['fortune_popup_background_style'];
    } else {
        $fortune_popup_background_style = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background_image'])) {
        $fortune_popup_background_image = $fortune_Main_Settings['fortune_popup_background_image'];
    } else {
        $fortune_popup_background_image = '';
    }
    if (isset($fortune_Main_Settings['fortune_max_height'])) {
        $fortune_max_height = $fortune_Main_Settings['fortune_max_height'];
    } else {
        $fortune_max_height = '';
    }
    if (isset($fortune_Main_Settings['fortune_font_size'])) {
        $fortune_font_size = $fortune_Main_Settings['fortune_font_size'];
    } else {
        $fortune_font_size = '';
    }
    if (isset($fortune_Main_Settings['fortune_font_type'])) {
        $fortune_font_type = $fortune_Main_Settings['fortune_font_type'];
    } else {
        $fortune_font_type = '';
    }
    if (isset($fortune_Main_Settings['fortune_button_background'])) {
        $fortune_button_background = $fortune_Main_Settings['fortune_button_background'];
    } else {
        $fortune_button_background = '';
    }
    if (isset($fortune_Main_Settings['fortune_cookie_exp'])) {
        $fortune_cookie_exp = $fortune_Main_Settings['fortune_cookie_exp'];
    } else {
        $fortune_cookie_exp = '';
    }
    if (isset($fortune_Main_Settings['fortune_button_border'])) {
        $fortune_button_border = $fortune_Main_Settings['fortune_button_border'];
    } else {
        $fortune_button_border = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_bold'])) {
        $fortune_fonts_bold = $fortune_Main_Settings['fortune_fonts_bold'];
    } else {
        $fortune_fonts_bold = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_italic'])) {
        $fortune_fonts_italic = $fortune_Main_Settings['fortune_fonts_italic'];
    } else {
        $fortune_fonts_italic = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_underline'])) {
        $fortune_fonts_underline = $fortune_Main_Settings['fortune_fonts_underline'];
    } else {
        $fortune_fonts_underline = '';
    }
    if ($fortune_blocked_content === 'on' && $GLOBALS['COOKIE_SET'] !== 'true') {
        add_shortcode("legalize_fortune_blocked_no_cookies", "legalize_fortune_blocked_no_cookies");
    } else {
        add_shortcode("legalize_fortune_blocked_cookies", "legalize_fortune_blocked_cookies");
    }
    if (isset($fortune_Main_Settings['fortune_enabled']) && $fortune_Main_Settings['fortune_enabled'] == 'on') 
    {
        if ($fortune_disable_loggedin === 'on' && is_user_logged_in()) {
            return;
        }
        if ($fortune_only_eu === 'on' && legalize_fortune_is_in_EU() === false) {
            return;
        }
        if (($fortune_block_all_cookies === 'on' || ($fortune_block_cookies === 'on' && $GLOBALS['COOKIE_SET'] !== 'true')) && headers_sent() === FALSE) {
            $dirty = false;
            foreach (headers_list() as $header) {
                if ($dirty)
                    continue;
                if (preg_match('/Set-Cookie/', $header))
                    $dirty = true;
            }
            if ($dirty) {
                $phpversion = explode('.', phpversion());
                if ($phpversion[0] > 5 || ($phpversion[0] === 5 && $phpversion[1] >= 3)) {
                    header_remove('Set-Cookie');
                } else {
                    header('Set-Cookie:');
                }
            }
            wp_register_script('legalize_fortune_enque_no_kuki_script', legalize_fortune_get_file_url('res/no_cookies.js'), array(
                'jquery'
            ));
            wp_enqueue_script('legalize_fortune_enque_no_kuki_script');
        }
        wp_register_style('legalize_fortune_enque_style', legalize_fortune_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
        wp_enqueue_style('legalize_fortune_enque_style');
        wp_register_script('legalize_fortune_enque_script', legalize_fortune_get_file_url('res/notification.js'), array(
            'jquery'
        ));
        wp_enqueue_script('legalize_fortune_enque_script');
        $settings = array(
            'use_cookies' => $fortune_popup_once,
            'stick' => $fortune_panel_sticks,
            'message' => $fortune_message,
            'close_message' => $fortune_close_message,
            'more_info' => $fortune_more_info,
            'more_link' => $fortune_more_link,
            'background' => $fortune_popup_background,
            'text_col' => $fortune_popup_text_col,
            'links_col' => $fortune_popup_links_col,
            'more_info_text' => $fortune_more_link_text,
            'auto_hide' => $fortune_auto_hide,
            'auto_hide_time' => $fortune_auto_hide_time,
            'border' => $fortune_border,
            'border_color' => $fortune_border_color,
            'border_width' => $fortune_border_width,
            'buttons' => $fortune_buttons,
            'animation' => $fortune_popup_animation,
            'max_width' => $fortune_max_width,
            'fade_background' => $fortune_fade_background,
            'deny_button' => $fortune_deny_button,
            'deny_text' => $fortune_deny_button_text,
            'custom_css' => $fortune_custom_css,
            'rounded_corners' => $fortune_rounded_corners,
            'dist_top' => $fortune_distance_top,
            'dist_bot' => $fortune_distance_bottom,
            'dist_right' => $fortune_distance_right,
            'dist_left' => $fortune_distance_left,
            'dist_padding' => $fortune_padding,
            'new_line' => $fortune_new_line,
            'auto_accept' => $fortune_auto_accept,
            'outside_close' => $fortune_outside_close,
            'outside_accept' => $fortune_outside_close_accept,
            'block_all_cookies' => $fortune_block_all_cookies,
            'center_popup' => $fortune_center_popup,
            'popup_style' => $fortune_popup_style,
            'new_line_all' => $fortune_new_line_all,
            'background_style' => $fortune_popup_background_style,
            'background_image' => $fortune_popup_background_image,
            'max_height' => $fortune_max_height,
            'font_size' => $fortune_font_size,
            'font_type' => $fortune_font_type,
            'button_background' => $fortune_button_background,
            'cookie_exp' => $fortune_cookie_exp,
            'block_cookies' => $fortune_block_cookies,
            'button_border' => $fortune_button_border,
            'font_bold' => $fortune_fonts_bold,
            'font_italic' => $fortune_fonts_italic,
            'font_underline' => $fortune_fonts_underline
        );
        wp_localize_script('legalize_fortune_enque_script', 'settings', $settings);
    }
}
require(dirname(__FILE__) . "/res/fortune-main.php");
require(dirname(__FILE__) . "/res/privacy-main.php");
require(dirname(__FILE__) . "/res/terms-main.php");
require(dirname(__FILE__) . "/res/privacy-publish.php");
?>