<?php
/** 
Plugin Name: Legalize! Privacy Policy and Terms of Service Generator
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin automatically generate a Privacy Policy and a Terms of Service page, compliant with both US and UK cookie law (EU cookie directive) + eu cookie consent popup
Author: kisded
Version: 1.1
Author URI: https://codecanyon.net/user/kisded
*/
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/privacy/master/info.json", __FILE__, "legalize-privacy-policy-and-terms-of-service");
add_action('admin_menu', 'privacy_register_my_custom_menu_page');
function privacy_register_my_custom_menu_page()
{
    add_menu_page('Legalize! Privacy Policy and Terms of Service Generator', 'Legalize! Privacy Policy and Terms of Service Generator', 'manage_options', 'privacy_admin_settings', 'privacy_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('privacy_admin_settings', 'Privacy Policy Settings', 'Privacy Policy Settings', 'manage_options', 'privacy_admin_settings');
    add_submenu_page("privacy_admin_settings", "Terms of Service Settings", "Terms of Service Settings", 'manage_options', "privacy_terms_settings", "privacy_terms_settings");
    add_submenu_page("privacy_admin_settings", "Cookie Consent Policy", "Cookie Consent Policy", 'manage_options', "privacy_fortune_cookie", "privacy_fortune_cookie");
    add_submenu_page("privacy_admin_settings", "Publish Changes", "Publish Changes", 'manage_options', "privacy_publish", "privacy_publish");
}

add_shortcode("legalize_get_cookies_opt_out_button", "legalize_get_cookies_opt_out_button");
function legalize_get_cookies_opt_out_button()
{
    $fortune_Main_Settings        = get_option('legalize_fortune_Main_Settings', false);
    $fortune_cookie_accept_delete_text = $fortune_Main_Settings['fortune_cookie_accept_delete_text'];
    $fortune_cookie_delete_text = $fortune_Main_Settings['fortune_cookie_delete_text'];
    $cookieCode ='<script>function fortune_delete_all_cookies(){if (confirm("' . $fortune_cookie_accept_delete_text . '") == true) {var data = {action: "fortune_my_action"};jQuery.post(ajaxurl, data, function(response) {location.reload();});}}</script><input type="button" id="fortune_clear_all_cookies" value="' . $fortune_cookie_delete_text . '" name="fortune_clear_all_cookies" onclick="fortune_delete_all_cookies()">';
    return $cookieCode;
}

function legalize_fortune_ajaxurl() {

    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
add_action('wp_head', 'legalize_fortune_ajaxurl');

$COOKIE_SET = 'false';
$dntEnabled = false;

register_activation_hook(__FILE__, 'legalize_fortune_check_version');
function legalize_fortune_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.3';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

function legalize_fortune_blocked_no_cookies()
{
    $fortune_Main_Settings        = get_option('legalize_fortune_Main_Settings', false);
    $fortune_blocked_content_text = $fortune_Main_Settings['fortune_blocked_content_text'];
    return $fortune_blocked_content_text;
}

function legalize_fortune_blocked_cookies($atts, $content = null)
{
    return $content;
}

function privacy_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=privacy_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
$plugin = plugin_basename(__FILE__);

add_action('wp_ajax_privacy_my_action', 'privacy_my_action_callback');
add_action('wp_ajax_terms_my_action', 'terms_my_action_callback');
function privacy_my_action_callback()
{
    legalize_my_plugin_install();
    echo "0";
    die();
}

register_activation_hook(__FILE__, 'legalize_fortune_activation_callback');
function legalize_fortune_activation_callback()
{
    $fortune_Main_Settings = array(
        'fortune_enabled' => 'off',
        'fortune_popup_once' => 'on',
        'fortune_popup_style' => 'fortune_panel_top',
        'fortune_close_message' => 'Accept',
        'fortune_message' => 'This site uses cookies to deliver its services. By using this site, you agree to its use of cookies.',
        'fortune_more_info' => 'on',
        'fortune_more_link' => 'https://www.google.com/policies/technologies/cookies/',
        'fortune_popup_background' => '#aaaaaa',
        'fortune_popup_text_col' => '#3f4c52',
        'fortune_popup_links_col' => '#0000ff',
        'fortune_panel_sticks' => 'on',
        'fortune_more_link_text' => 'More Info',
        'fortune_auto_hide' => 'off',
        'fortune_auto_hide_time' => '5000',
        'fortune_border' => 'off',
        'fortune_border_color' => '#ff0000',
        'fortune_border_width' => '3px',
        'fortune_buttons' => 'on',
        'fortune_popup_animation' => 'fortune_fade_anim',
        'fortune_max_width' => '',
        'fade_background' => 'on',
        'fortune_only_eu' => 'off',
        'fortune_block_cookies' => 'off',
        'fortune_blocked_content' => 'on',
        'fortune_deny_button_text' => 'Deny',
        'fortune_deny_button' => 'off',
        'fortune_block_all_cookies' => 'off',
        'fortune_disable_loggedin' => 'off',
        'fortune_custom_css' => '',
        'fortune_rounded_corners' => 'on',
        'fortune_distance_right' => '0px',
        'fortune_distance_left' => '0px',
        'fortune_distance_bottom' => 'auto',
        'fortune_distance_top' => '0px',
        'fortune_padding' => '10px',
        'fortune_new_line' => 'off',
        'fortune_auto_accept' => 'off',
        'fortune_outside_close_accept' => 'on',
        'fortune_outside_close' => 'on',
        'fortune_center_popup' => 'on',
        'fortune_advanced_settings' => 'off',
        'fortune_new_line_all' => 'off',
        'fortune_popup_background_style' => 'fortune_color',
        'fortune_popup_background_image' => '',
        'fortune_max_height' => '',
        'fortune_font_size' => '14px',
        'fortune_font_type' => 'Helvetica, Arial, sans-serif',
        'fortune_button_background' => '#aaaaaa',
        'fortune_cookie_exp' => '1440',
        'fortune_button_border' => '#0000ff',
        'fortune_fonts_bold' => 'off',
        'fortune_fonts_italic' => 'off',
        'fortune_fonts_underline' => 'off',
        'fortune_cookie_accept_delete_text' => 'Are you sure you want to change your mind about cookie consent policy?',
        'fortune_cookie_delete_text' => 'Show cookiebar again',
        'fortune_dnt_check' => 'on'
    );
    if (!get_option('legalize_fortune_Main_Settings')) {
        add_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
    } else {
        delete_option('legalize_fortune_Main_Settings');
        add_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
    }
}

function terms_my_action_callback()
{
    terms_my_plugin_install();
    echo "0";
    die();
}
add_shortcode("legalize_privacy", "legalize_shortcode_privacy");

function legalize_shortcode_privacy()
{
    return "<a href='" . get_page_link(get_option("privacy_policy_id")) . "' target='_blank'>Privacy Policy</a>";
}

add_shortcode("legalize_terms", "legalize_shortcode_terms");

function legalize_shortcode_terms()
{
    return "<a href='" . get_page_link(get_option("terms_policy_id")) . "' target='_blank'>Terms of Service</a>";
}
function legalize_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'legalize_activation_callback');
function legalize_activation_callback()
{
    $privacy_Main_Settings = array(
        'privacy_collect_data' => 'pri_YES',
        'privacy_enabled' => 'on',
        'privacy_share_data_partners' => 'pri_NO',
        'privacy_share_data_ads' => 'pri_NO',
        'privacy_share_data_unlimited' => 'pri_NO',
        'privacy_share_data_agr' => 'pri_NO',
        'privacy_share_data' => 'pri_NO',
        'privacy_california' => 'pri_NO',
        'privacy_ssl' => 'pri_NO',
        'privacy_ads' => 'pri_NO',
        'privacy_adsense' => 'pri_NO',
        'privacy_cookies' => 'pri_YES',
        'privacy_pass' => 'pri_YES',
        'privacy_arb' => 'pri_NO',
        'privacy_child' => 'pri_NO',
        'privacy_owner_loc' => '',
        'privacy_owner_email' => '',
        'privacy_email' => '',
        'privacy_mail' => ''
    );
    if (!get_option('privacy_Main_Settings')) {
        add_option('privacy_Main_Settings', $privacy_Main_Settings);
    } else {
        delete_option('privacy_Main_Settings');
        add_option('privacy_Main_Settings', $privacy_Main_Settings);
    }
    $privacy_Terms_Settings = array(
        'terms_enabled' => 'on',
        'privacy_owner_name' => '',
        'privacy_owner_type' => 'Individual',
        'privacy_dmca' => 'pri_NO',
        'privacy_dmca_address' => '',
        'privacy_dmca_phone' => '',
        'privacy_dmca_email' => '',
        'terms_owner_email_address' => '',
        'terms_owner_locality' => '',
        'terms_ads' => 'pri_NO',
        'terms_major' => 'pri_YES',
        'terms_arbitration' => 'pri_NO'
    );
    if (!get_option('privacy_Terms_Settings')) {
        add_option('privacy_Terms_Settings', $privacy_Terms_Settings);
    } else {
        delete_option('privacy_Terms_Settings');
        add_option('privacy_Terms_Settings', $privacy_Terms_Settings);
    }
}

function terms_my_plugin_install()
{
    global $wpdb;
    $the_page_title         = 'Terms of Service';
    $the_page               = get_page_by_title($the_page_title);
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    $terms_enabled          = $privacy_Terms_Settings['terms_enabled'];
    if (isset($privacy_Terms_Settings['privacy_owner_type'])) {
        $privacy_owner_type = $privacy_Terms_Settings['privacy_owner_type'];
    } else {
        $privacy_owner_type = 'Individual';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca'])) {
        $privacy_dmca = $privacy_Terms_Settings['privacy_dmca'];
    } else {
        $privacy_dmca = 'pri_YES';
    }
    $privacy_dmca_address      = $privacy_Terms_Settings['privacy_dmca_address'];
    $privacy_dmca_phone        = $privacy_Terms_Settings['privacy_dmca_phone'];
    $privacy_dmca_email        = $privacy_Terms_Settings['privacy_dmca_email'];
    $privacy_owner_name        = $privacy_Terms_Settings['privacy_owner_name'];
    $terms_owner_email_address = $privacy_Terms_Settings['terms_owner_email_address'];
    $terms_owner_locality      = $privacy_Terms_Settings['terms_owner_locality'];
    if (isset($privacy_Terms_Settings['terms_ads'])) {
        $terms_ads = $privacy_Terms_Settings['terms_ads'];
    } else {
        $terms_ads = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_major'])) {
        $terms_major = $privacy_Terms_Settings['terms_major'];
    } else {
        $terms_major = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_arbitration'])) {
        $terms_arbitration = $privacy_Terms_Settings['terms_arbitration'];
    } else {
        $terms_arbitration = 'pri_YES';
    }
    if ($terms_enabled == 'on') {
        $var = 'Terms of Service for ' . get_home_url();
        
        $var .= '<br/><br/><b>Introduction</b><br/><br/>
        
        Site Terms of Service, an Enforceable Legal Agreement.
        As of *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*

These Terms of Service and our privacy policy (together the “Terms”) govern all use of ' . get_home_url() . ' and that site’s services (together the “Site” or “Services”).';
        if ($privacy_owner_name != "") {
            $var .= 'The Site is owned by ' . $privacy_owner_name . ', a(n) ' . $privacy_owner_type . '.';
        }
        
        $var .= 'The owners and contributors to the Site will be referred to as “we,” “us,” or “our” in these Terms.  By using the Site or its Services, and/or by clicking anywhere on this Site to agree to these Terms, you are deemed to be a “user” for purposes of the Terms.  You and every other user (“you” or “User” as applicable) are bound by these Terms.  You and each user also agree to the Terms by using the Services.  If any User does not agree to the Terms or the Privacy Policy, such User may not access the Site or use the Services.  In these Terms, the word “Site” includes the site referenced above, its owner(s), contributors, suppliers, licensors, and other related parties.

<br/><br/><b>Responsibility of Website Visitors</b><br/><br/>
We have not reviewed, and cannot review, all of the material, including computer software, posted to the Website, and cannot therefore be responsible for that material s content, use or effects. By operating the Website, we do not represent or imply that it endorses the material there posted, or that it believes such material to be accurate, useful or non-harmful. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. The Website may contain content that is offensive, indecent, or otherwise objectionable, as well as content containing technical inaccuracies, typographical mistakes, and other errors. The Website may also contain material that violates the privacy or publicity rights, or infringes the intellectual property and other proprietary rights, of third parties, or the downloading, copying or use of which is subject to additional terms and conditions, stated or unstated. 
We disclaim any responsibility for any harm resulting from the use by visitors of the Website, or from any downloading by those visitors of content there posted.';
        if ($terms_major == "pri_NO") {
            $var .= '<br/><br/><b>Use of this Website</b>
            
    Warning! You may only use this site if you are at least 18 years of age and can enter into binding contracts (the Site is not available for use by minors). By using this Site, you agree that you are at least 18 years of age. ';
        }
        
        $var .= '<br/><br/><b>User Prohibited From Illegal Uses</b>

User shall not use, and shall not allow any person to use, the Site or Services in any way that violates a federal, state, or local law, regulation, or ordinance, or for any disruptive, tortious, or illegal purpose, including but not limited to harassment, slander, defamation, data theft or inappropriate dissemination, or improper surveillance of any person.

User represents and warrants that:

-	User will use the Services only as provided in these Terms;
-	User is at least 18 years old and has all right, authority, and capacity to agree to these Terms;
-	User will provide accurate, complete, and current information to the Site and its owner(s);
-	User will notify the Site and its owner(s) regarding any material change to information User provides, either by updating and correcting the information, or by alerting the Site and its owner(s) via the functions of the Site or the email address provided below.

Disclaimer of Warranties

TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SITE PROVIDES THE SERVICES “AS IS,” WITH ALL FAULTS.  THE SITE DOES NOT WARRANT UNINTERRUPTED USE OR OPERATION OF THE SERVICES, OR THAT ANY DATA WILL BE TRANSMITTED IN A MANNER THAT IS TIMELY, UNCORRUPTED, FREE OF INTERFERENCE, OR SECURE.  THE SITE DISCLAIMS REPRESENTATIONS, WARRANTIES, AND CONDITIONS OF ANY KIND, WHETHER EXPRESS, IMPLIED, WRITTEN, ORAL, CONTRACTUAL, COMMON LAW, OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES, DUTIES, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, NON-INFRINGEMENT, OR THAT MAY ARISE FROM A COURSE OF DEALING OR USAGE OF TRADE.

<br/><br/><b>Liability Is Limited</b>

THE SITE SHALL NOT BE LIABLE FOR INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES OF ANY KIND, INCLUDING BUT NOT LIMITED TO LOST PROFITS (REGARDLESS OF WHETHER WE HAVE BEEN NOTIFIED THAT SUCH LOSS MAY OCCUR) OR EXPOSURE TO ANY THIRD PARTY CLAIMS BY REASON OF ANY ACT OR OMISSION.  THE SITE SHALL NOT BE LIABLE FOR ANY ACT OR OMISSION OF ANY THIRD PARTY INVOLVED WITH THE SERVICES, SITE OFFERS, OR ANY ACT BY SITE USERS.  THE SITE SHALL NOT BE LIABLE FOR ANY DAMAGES THAT RESULT FROM ANY SERVICE PROVIDED BY, OR PRODUCT OR DEVICE MANUFACTURED BY, THIRD PARTIES.

NOTWITHSTANDING ANY DAMAGES THAT USER MAY SUFFER FOR ANY REASON, THE ENTIRE LIABILITY OF THE SITE IN CONNECTION WITH THE SITE OR SERVICES, AND ANY PARTY’S EXCLUSIVE REMEDY, SHALL BE LIMITED TO THE AMOUNT, IF ANY, ACTUALLY PAID BY USER TO THE SITE OWNER DURING THE 12 MONTHS PRIOR TO THE EVENT THAT USER CLAIMS CAUSED THE DAMAGES.

The Site shall not be liable for any damages incurred as a result of any loss, disclosure, or third party use of information, regardless of whether such disclosure or use is with or without User’s knowledge or consent.  The Site shall have no liability for any damages related to:  User’s actions or failures to act, the acts or omissions of any third party, including but not limited to any telecommunications service provider, or events or causes beyond the Site’s reasonable control.  The Site has no obligations whatever, and shall have no liability to, any third party who is not a User bound by these Terms.  Limitations, exclusions, and disclaimers in these Terms shall apply to the maximum extent permitted by applicable law, even if any remedy fails its essential purpose.

<br/><br/><b>Content Posted on Other Websites</b><br/><br/>

We have not reviewed, and cannot review, all of the material, including computer software, made available through the websites and webpages to which our website links, and that link to us. We do not have any control over those external websites and webpages, and we are not responsible for their contents or their use. By linking to an external website or webpage, we do not represent or imply that it endorses such website or webpage. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. We disclaim any responsibility for any harm resulting from your use of external websites and webpages.
<br/><br/><b>Third party products, links, and actions</b>

The Site may include or offer third party products or services.  The Site may also have other users or members who interact with each other, through the Site, elsewhere online, or in person.  These third party products and any linked sites have separate and independent terms of service and privacy policies.  We have no control or responsibility for the content and activities of these linked sites, sellers, and third parties in general, regardless of whether you first were introduced or interacted with such businesses, services, products, and people through the Site, and therefore you agree that we are not liable for any of them. We do, however, welcome any feedback about these sites, sellers, other users or members, and third parties.

<br/><br/><b>Changes to the Site and the Services</b>

The owners and contributors to the Site will work to improve the Site for our users, and to further our business interests in the Site. We reserve the right to add, change, and remove features, content, and data, including the right to add or change any pricing terms.  You agree that we will not be liable for any such changes.  Neither your use of the Site nor these terms give you any right, title, or protectable legal interest in the Site or its content.
We reserve the right, at its sole discretion, to modify or replace any part of this Agreement. It is your responsibility to check this Agreement periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Agreement constitutes acceptance of those changes.

<br/><br/><b>Termination</b><br/><br/>

We may terminate your access to all or any part of the Website at any time, with or without cause, with or without notice, effective immediately. If you wish to terminate this Agreement or your account (if you have one), you may simply discontinue using the Website. Notwithstanding the foregoing, if you have a paid services account, such account can only be terminated by us if you materially breach this Agreement and fail to cure such breach within thirty (30) days from our notice to you thereof; provided that, we can terminate the Website immediately as part of a general shut down of our service. All provisions of this Agreement which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability. 

<br/><br/><b>Indemnity</b>

If your activity or any activity on your behalf creates potential or actual liability for us, or for any of our users, partners, or contributors, you agree to indemnify and hold us and any such user, partner, contributor, or any agent harmless from and against all claims, costs of defense and judgment, liabilities, legal fees, damages, losses, and other expenses in relation to any claims or actions arising out of or relating to your use of the Site, or any breach by you of these Terms of Service.

<br/><br/><b>Intellectual Property</b>

This site and some delivery modes of our product are built on the WordPress platform.  For information about intellectual property rights, including General Public License (“GPL”) terms under which the WordPress software is licensed, see here  http://wordpress.org/about/gpl/

The Site grants User a revocable, non-transferable, and non-exclusive license to use the Site solely in connection with the Site and the Services, under these Terms.

Copyright in all content and works of authorship included in the Site are the property of the Site or its licensors.  Apart from links which lead to the Site, accurately attributed social media references, and de minimus text excerpts with links returning to the Site, no text, images, video or audio recording, or any other content from the Site shall be copied without explicit and detailed, written permission from the Site s owner.  User shall not sublicense or otherwise transfer any rights or access to the Site or related Services to any other person.

The names and logos used by the Site, and all other trademarks, service marks, and trade names used in connection with the Services are owned by the Site or its licensors and may not be used by User without written consent of the rights owners.  Use of the Site does not in itself give any user any license, consent, or permission, unless and then only to the extent granted explicitly in these Terms.

All rights not expressly granted in these Terms are reserved by the Site.';
        if ($privacy_dmca == 'pri_YES') {
            $var .= '<br/><br/><b>Copyright Notice and Takedown (DMCA) Policy</b>

Please respect the rights of others, including rights under the U.S. copyright laws. You should only post content and files on the Site for which you have ownership, a license, or if your use constitutes fair use as that is defined under US. law.

Under the Digital Millennium Copyright Act of 1998 (DMCA), we will respond to claims of copyright infringement committed on the Site, if reported to our copyright agent according to these terms.

If you are a copyright owner, or an authorized representative, please report alleged copyright infringements by completing the following DMCA Notice and delivering it to our copyright agent. We will take action as we deem appropriate under the circumstances, in our sole discretion.  We may remove the challenged material from the Site.

To give an effective DMCA Notice of Alleged Infringement ("Notice”) regarding content on our Site, you must:

  1. Identify the copyrighted work(s) that you claim to be infringed, and the location on our Site where you have observed the allegedly infringing material, including the specific page or post URL that will enable us to locate the material.  (We cannot take down what we cannot find.)
  2. Provide a mailing address, telephone number, and email address where you can be reached.
  3. Include both of the following statements:
"I state that I have a good faith belief that the use of the copyrighted material or reference or link to such material is not authorized by the copyright owner, its agent, or the law (including fair use).”
"All information in this Notice is accurate.  Under penalty of perjury, I further state that I am the owner, or that I am authorized to act on behalf of the owner, of the copyright or of an exclusive right (such as an exclusive license) under the copyright that is allegedly infringed."
  4. Provide your full legal name, as well as your electronic or physical signature.

Deliver this Notice, with items 1-4 completed, to our Designated Copyright Agent:

Copyright Agent, ' . get_home_url();
            if ($privacy_dmca_address != '') {
                $var .= '<br/>' . $privacy_dmca_address;
            }
            if ($privacy_dmca_phone != '') {
                $var .= '<br/>' . $privacy_dmca_phone;
            }
            if ($privacy_dmca_email != '') {
                $var .= '<br/>Email: ' . $privacy_dmca_email;
            }
            
            $var .= 'Please Note:  In our discretion, we will disable and/or terminate the accounts of users who repeatedly infringe or are repeatedly charged with infringing the copyrights or other intellectual property rights of others.';
        }
        
        $var .= '<br/><br/><b>Privacy</b>

Any information that you provide to the Site is subject to the Site’s Privacy Policy, which governs our collection and use of User information. User understands that through his or her use of the Site and its Services, User consents to the collection and use (as set forth in the Privacy Policy) of the information, including the transfer of this information to the United States and/or other countries for storage, processing and use by the Site. The Site may make certain communications to some or all Users, such as service announcements and administrative messages. These communications are considered part of the Services and a User’s account with the Site, and Users are not able to opt out of all of them.

<br/><br/><b>Usernames, Passwords, and Profiles</b>

If prompted, Users must provide a valid email address to the Site, at which email address the User can receive messages. User must also update the Site if that email address changes. The Site reserves the right to terminate any User account and/or User access to the Site if a valid email is requested but is not provided by the User.

If the Site prompts or allows a User to create a username or profile, Users agree not to pick a username or provide any profile information that would impersonate someone else or that is likely to cause confusion with any other person or entity.  The Site reserves the right to cancel a User account or to change a username or profile data at any time.  Similarly, if the Site allows comments or user input, or prompts or allows a User to create an avatar or upload a picture, User agrees not to use any image that impersonates some other person or entity, or that is otherwise likely to cause confusion.

You are responsible for protecting your username and password for the Site, and you agree not to disclose it to any third party. We recommend that you use a password that is more than eight characters long.  You are responsible for all activity on your account, whether or not you authorized it.';
        if ($terms_owner_email_address != '') {
            $var .= 'You agree to inform us of unauthorized use of your account, by email to ' . $terms_owner_email_address . '.';
        }
        $var .= 'You acknowledge that if you wish to protect your interactions with the Site, it is your responsibility to use a secure encrypted connection, virtual private network, or other appropriate measures.  The Site’s own security measures are reasonable in terms of their level of protection, but are not helpful if the interactions of you or any other User with Site are not secure or private.';
        
        if ($terms_owner_locality != '') {
            $var .= '<br/><br/><b>Disputes</b>

We are based in ' . $terms_owner_locality . ' and you are contracting to use our Site.  These Terms and all matters arising from your use of the Site are governed by and will be construed according to the laws of ' . $terms_owner_locality . ', without regard to any choice of laws rules of any jurisdiction.  The federal courts and state courts that have geographical jurisdiction over disputes arising at our office location in the ' . $terms_owner_locality . ' will be the only permissible venues for any and all disputes arising out of or in connection with these Terms or the Site and Service.';
        }
        if ($terms_arbitration) {
            $var .= '<br/><br/><b>ARBITRATION</b>

Notwithstanding anything that may be contrary within the “Disputes” provisions above, all matters, and all arbitrable claims within a multi-claim matter, including all claims for monetary damages, shall be decided by a single arbitrator to be selected by us, which arbitrator shall hold hearings';
            if ($terms_owner_locality != '') {
                $var .= ' in or near ' . $terms_owner_locality;
            }
            $var .= ', under the rules of the American Arbitration Association.';
        }
        
        if ($terms_ads != '') {
            
            $var .= '<br/><br/><b>Advertising</b>

The Site may include advertisements, which may be targeted for relevance to the Site, queries made, or other information to improve relevance to the Site’s users.  The types and extent of advertising on the Site will change over time.  In consideration for User access to and use of the Site, User agrees that the Site and third party providers and partners may place advertising anywhere on the Site.  For the remaining terms that will apply to our advertising practices, including use of your information, see our Privacy Policy.';
        }
        $var .= '<br/><br/><b>General</b>

These Terms, including the incorporated Privacy Policy, supersede all oral or written communications and understandings between User and the Site.

Any cause of action User may have relating to the Site or the Services must be commenced within one (1) year after the claim or cause of action arises. 

Both parties waive the right to a jury trial in any dispute relating to the Terms, the Site, or the Services.

If for any reason a court of competent jurisdiction finds any aspect of the Terms to be unenforceable, the Terms shall be enforced to the maximum extent permissible, to give effect to the intent of the Terms, and the remainder of the Terms shall continue in full force and effect.

User may not assign his or her rights or delegate his or her responsibilities under these Terms or otherwise relating to the Site or its Services.

There shall be no third party beneficiaries under these Terms, except for the Site’s affiliates, suppliers, and licensors, or as required by law. 

Use of the Site and its Services is unauthorized in any jurisdiction that does not give effect to all provisions of these Terms, including without limitation this paragraph.

The failure of the Site to exercise or enforce any right or provision of these Terms shall not constitute a waiver of that right or provision.
This Agreement constitutes the entire agreement between this website and you concerning the subject matter hereof, and they may only be modified by a written amendment signed by an authorized executive of this website, or by the posting by this website of a revised version. 
Except to the extent applicable law, if any, provides otherwise, this Agreement, any access to or use of the Website will be governed by our laws, excluding its conflict of law provisions, and the proper venue for any disputes arising out of or relating to any of the same will be the state and federal courts. 
Except for claims for injunctive or equitable relief or claims regarding intellectual property rights (which may be brought in any competent court without the posting of a bond), any dispute arising under this Agreement shall be finally settled in accordance with the Comprehensive Arbitration Rules of the Judicial Arbitration and Mediation Service, Inc. ("JAMS") by three arbitrators appointed in accordance with such Rules. 
The arbitration shall take place in the English language and the arbitral decision may be enforced in any court. The prevailing party in any action or proceeding to enforce this Agreement shall be entitled to costs and attorneys fees. If any part of this Agreement is held invalid or unenforceable, that part will be construed to reflect the parties original intent, and the remaining portions will remain in full force and effect. 
A waiver by either party of any term or condition of this Agreement or any breach thereof, in any one instance, will not waive such term or condition or any subsequent breach thereof. You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; we may assign its rights under this Agreement without condition. 
This Agreement will be binding upon and will inure to the benefit of the parties, their successors and permitted assigns.';
        
        if ($terms_owner_email_address != '') {
            
            $var .= '<br/><br/><b>Terms Contact</b>

If you have any questions about these Terms, please address them to ' . $terms_owner_email_address . '.';
        }
        
        $var .= '<br/><br/><b>Last Updated</b>

These terms were last updated on *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';
        
        if (!$the_page) {
            
            // Create post object
            $_p               = array();
            $_p['post_title'] = $the_page_title;
            
            $_p['post_content']   = $var;
            $_p['post_status']    = 'publish';
            $_p['post_type']      = 'page';
            $_p['comment_status'] = 'closed';
            $_p['ping_status']    = 'closed';
            $_p['post_category']  = array(
                1
            ); // the default 'Uncatrgorised'
            
            // Insert the post into the database
            $the_page_id = wp_insert_post($_p);
            
        } else {
            
            //make sure the page is not trashed...
            $the_page->post_content = $var;
            $the_page->post_status  = 'publish';
            $the_page_id            = wp_update_post($the_page);
            
        }
        
        delete_option('terms_policy_id');
        add_option('terms_policy_id', $the_page_id);
    } else {
        terms_my_plugin_remove();
    }
}
function terms_my_plugin_remove()
{
    global $wpdb;
    //  the id of our page...
    $the_page_id = get_option('terms_policy_id');
    if ($the_page_id) {
        
        wp_delete_post($the_page_id, true);
        
    }
    delete_option("terms_policy_id");
}
register_activation_hook(__FILE__, 'terms_my_plugin_install');

function privacy_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('wp_ajax_legalize_fortune_my_action', 'legalize_fortune_my_action_callback');
function legalize_fortune_my_action_callback()
{
    $past = time() - 3600;
    foreach ($_COOKIE as $key => $value) {
        setcookie($key, $value, $past, '/');
    }
    echo "0";
    die();
}

/* Runs when plugin is activated */
register_activation_hook(__FILE__, 'legalize_my_plugin_install');

/* Runs on plugin deactivation*/
register_deactivation_hook(__FILE__, 'legalize_my_plugin_remove');
register_deactivation_hook(__FILE__, 'terms_my_plugin_remove');

function legalize_my_plugin_install()
{
    
    global $wpdb;
    $the_page_title        = 'Privacy Policy';
    $the_page              = get_page_by_title($the_page_title);
    $privacy_Main_Settings = get_option('privacy_Main_Settings', false);
    if (isset($privacy_Main_Settings['privacy_collect_data'])) {
        $privacy_collect_data = $privacy_Main_Settings['privacy_collect_data'];
    } else {
        $privacy_collect_data = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data'])) {
        $privacy_share_data = $privacy_Main_Settings['privacy_share_data'];
    } else {
        $privacy_share_data = 'pri_YES';
    }
    $privacy_enabled = $privacy_Main_Settings['privacy_enabled'];
    if (isset($privacy_Main_Settings['privacy_collect_data_partners'])) {
        $privacy_collect_data_partners = $privacy_Main_Settings['privacy_collect_data_partners'];
    } else {
        $privacy_collect_data_partners = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_ads'])) {
        $privacy_share_data_ads = $privacy_Main_Settings['privacy_share_data_ads'];
    } else {
        $privacy_share_data_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_unlimited'])) {
        $privacy_share_data_unlimited = $privacy_Main_Settings['privacy_share_data_unlimited'];
    } else {
        $privacy_share_data_unlimited = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_agr'])) {
        $privacy_share_data_agr = $privacy_Main_Settings['privacy_share_data_agr'];
    } else {
        $privacy_share_data_agr = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_california'])) {
        $privacy_california = $privacy_Main_Settings['privacy_california'];
    } else {
        $privacy_california = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ssl'])) {
        $privacy_ssl = $privacy_Main_Settings['privacy_ssl'];
    } else {
        $privacy_ssl = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ads'])) {
        $privacy_ads = $privacy_Main_Settings['privacy_ads'];
    } else {
        $privacy_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_adsense'])) {
        $privacy_adsense = $privacy_Main_Settings['privacy_adsense'];
    } else {
        $privacy_adsense = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_cookies'])) {
        $privacy_cookies = $privacy_Main_Settings['privacy_cookies'];
    } else {
        $privacy_cookies = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_pass'])) {
        $privacy_pass = $privacy_Main_Settings['privacy_pass'];
    } else {
        $privacy_pass = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_arb'])) {
        $privacy_arb = $privacy_Main_Settings['privacy_arb'];
    } else {
        $privacy_arb = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_child'])) {
        $privacy_child = $privacy_Main_Settings['privacy_child'];
    } else {
        $privacy_child = 'pri_YES';
    }
    $privacy_owner_loc   = $privacy_Main_Settings['privacy_owner_loc'];
    $privacy_owner_email = $privacy_Main_Settings['privacy_owner_email'];
    $privacy_email       = $privacy_Main_Settings['privacy_email'];
    $privacy_mail        = $privacy_Main_Settings['privacy_mail'];
    if ($privacy_enabled == 'on') {
        $var = 'This privacy policy (“Policy”) and this site’s Terms of Service (together the “Terms”) govern all use of ' . get_home_url() . ' and that site’s services (together the “Site” or “Services”).  The owners and contributors to the Site will be referred to as “we,” “us,” or “our” in this Policy.  By using the Site or its Services, and/or by clicking anywhere on this Site to agree to the Terms and this Policy, you are deemed to be a “user” for purposes of this Policy.  You and every other user (“you” or “User” as applicable) are subject to this Policy.  You and each user also agree to the Terms by using the Services.  In these Terms, the word “Site” includes the site referenced above, its owner(s), contributors, suppliers, licensors, and other related parties.

        We provide this privacy statement explaining our online information practices, so that you can decide whether and how to interact with the Site and the Services.

        We may release your information when we deem it appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety.

        This online privacy policy applies only to information collected through our website and not to information collected offline.

        Please also review our <b>Terms of Service</b> section that governs the use and the users of the Site.

        By using our site, you consent to our <b>Privacy Policy</b>.

        If we decide to change our privacy policy, we will post those changes on this page. If we have your email address, we may also send an email notifying you of any changes.';
        if ($privacy_collect_data == 'pri_YES') {
            $var .= '<br/><br/><b>Contact Data and Other Identifiable Information</b>

            This site collects certain user information, which may include a username and password, contact information, or any other data that you type in to the site.  It may also identify your IP address to help identify you on future visits to the site.  At our discretion, the Site may use this data to:

            * Personalize the user experience and/or customer service
            * Improve the site
            * To process transactions
            * Administer a contest, promotion, survey or other site feature or function
            * Send email to users';
        }
        $var .= '<br/><br/><b>Gathering of Personally-Identifying Information</b>
        
        Certain visitors of our websites choose to interact with our website in ways that require us to gather personally-identifying information. The amount and type of information that wef gathers depends on the nature of the interaction. For example, we ask visitors who sign up at our website to provide a username and email address. Those who engage in transactions with us are asked to provide additional information, including as necessary the personal and financial information required to process those transactions. 
        In each case, we collect such information only insofar as is necessary or appropriate to fulfill the purpose of the visitor s interaction with us. We do not disclose personally-identifying information other than as described below. And visitors can always refuse to supply personally-identifying information, with the caveat that it may prevent them from engaging in certain website-related activities.';
        $var .= '<br/><br/><b>Protection of Certain Personally-Identifying Information</b>
        
        We disclose potentially personally-identifying and personally-identifying information only to those of its employees, contractors and affiliated organizations that (i) need to know that information in order to process it on our behalf or to provide services available at our websites, and (ii) that have agreed not to disclose it to others. 
        Some of those employees, contractors and affiliated organizations may be located outside of your home country; by using our websites, you consent to the transfer of such information to them. We will not rent or sell potentially personally-identifying and personally-identifying information to anyone. Other than to its employees, contractors and affiliated organizations, as described above, we disclose potentially personally-identifying and personally-identifying information only in response to a subpoena, court order or other governmental request, or when we believe in good faith that disclosure is reasonably necessary to protect our property or rights, third parties or the public at large. If you are a registered user of our website and have supplied your email address, we may occasionally send you an e-mail to tell you about new features, solicit your feedback, or just keep you up to date with what s going on with our products. 
        If you send us a request (for example via email or via one of our feedback mechanisms), we reserve the right to publish it in order to help us clarify or respond to your request or to help us support other users. We take all measures reasonably necessary to protect against the unauthorized access, use, alteration or destruction of potentially personally-identifying and personally-identifying information.';
        if ($privacy_share_data == 'pri_YES') {
            $var .= '<br/><br/><b>Sharing User Data</b>

        Like most website operators, we collect non-personally-identifying information of the sort that web browsers and servers typically make available, such as the browser type, language preference, referring site, and the date and time of each visitor request. Our purpose in collecting non-personally identifying information is to better understand how our visitors use this website. From time to time, we may release non-personally-identifying information in the aggregate, e.g., by publishing a report on trends in the usage of its website.
        We also collect potentially personally-identifying information like Internet Protocol (IP) addresses for logged in users and for users leaving comments on our blogs/sites. We only discloses logged in user and commenter IP addresses under the same circumstances that it uses and discloses personally-identifying information as described below, except that commenter IP addresses and email addresses are visible and disclosed to the administrators of the blog/site where the comment was left.
        The site may share user data with third parties that ';
        }
        if ($privacy_share_data_partners == 'pri_YES') {
            $var .= ' help the site owner operate and manage the site,';
        }
        if ($privacy_share_data_ads == 'pri_YES') {
            $var .= ' are the site owner s advertisers and marketing partners,';
        }
        if ($privacy_share_data_unlimited == 'pri_YES') {
            $var .= ' buy or rent data for purposes not limited to operating this site.';
        }
        if ($privacy_share_data_agr == 'pri_YES') {
            $var .= 'The site will only share such user data with these third parties in the aggregate, using collected data reporting on user activity and data that the site collects, but not identifying individual users. Information limited to or identifying individual site users will not be shared.';
        }
        if ($privacy_california == 'pri_YES') {
            $var .= '<br/><br/><b>California Privacy Rights</b>

            California Civil Code Section 1798.83 permits Site users who are residents of California to request and receive once a year a list of any third parties to whom we disclosed any of that user s personal information for direct marketing purposes in the preceding calendar year, as well as the categories of personal information disclosed.';
            if (($privacy_email != '') || ($privacy_mail != '')) {
                $var .= 'If you are a California resident and you wish to make such a request or have any questions about the Site s information sharing';
            }
            if ($privacy_email != '') {
                $var .= ', you may send an email to ' . $privacy_email;
            }
            if ($privacy_mail != '') {
                $var .= ', you may write to ' . $privacy_mail;
            }
            if (($privacy_email != '') || ($privacy_mail != '')) {
                $var .= '.';
            }
            $var .= 'See more at: <a href="http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf" target="_blank">http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf</a>.';
        }
        $var .= '<br/><br/><b>How does our site handle Do Not Track signals?</b>
        
        We honor Do Not Track signals and Do Not Track, plant cookies, or use advertising when a Do Not Track (DNT) browser mechanism is in place.';
        $var .= '<br/><br/><b>Mobile Device Privacy</b>

        The following applies to our site, when viewed on a mobile device:
        When accessed with a mobile deivce, our site may collect information automatically, such as the type of mobile device you have, device identifiers, and information about your use of the site. Regardless of the device you use to access the site, it will also collect information you provide, as well as information about your interaction with the site and its content.
        If location services are activated on your mobile device, our site may collect information about the location of your device. Your mobile network service providers may collect device-specific information, such as a device identifier, when you use our website or one of our mobile applications. This information collected by your mobile network service will not be associated with your user account with us, or with your personally identifiable information.';
        if ($privacy_ssl == 'pri_YES') {
            $var .= '<br/><br/><b>Protection of user information</b>

        We work to protect the security of your information during transmission by using Secure Sockets Layer (SSL) software, which encrypts information you share with the site.
        The Site also protects your account data by using HTTPS transfer protocol.  This is a widely used and more secure communications protocol. ';
        }
        if ($privacy_ads == 'pri_YES') {
            $var .= '<br/><br/><b>Advertising Network</b>
            
        We use one or more third party vendors to serve ads on the Site. To serve ads and determine how our users use the Site, these services use cookies, or small pieces of code to serve ads to Site users based on users’ visits to the Site and others. Users may adjust their browser settings to disallow the use of cookies.  With cookies turned off, certain features of the Site may work less efficiently or not at all.';
        }
        if ($privacy_adsense == 'pri_YES') {
            $var .= 'We use Google as an advertising services provider for the Site. Users may opt out of Google’s use of the DART use-tracking cookie by visiting the Google advertising Policies & Principles page.  If you opt out of ad tailoring, you will still see ads, but they will not be based on your browsing history, and they may appear in other languages.';
            $var .= 'Users can set preferences for how Google advertises to you using the Google Ad Settings page. Alternatively, you can opt out by visiting the Network Advertising Initiative Opt Out page or by using the Google Analytics Opt Out Browser add on.';
        }
        if ($privacy_cookies == 'pri_YES') {
            $var .= '<br/><br/><b>Cookies</b>

        This site uses cookies.  Cookies are small pieces of code that the Site or a service provider will put on your computer if your Web browser allows it.  The Site uses cookies to recognize and keep certain information.  On the Site, that information may be used to recognize your computer and browser from current or past visits to the Site or related sites.  We may use this cookie-captured information to improve our service to you, to aggregate information about visitors to the Site and their behavior, to remember and process items in your shopping cart, to understand and save user preferences, or to keep track of advertising.  We may contract with third-party service providers to assist us in better understanding our site visitors.
        In most Internet browsers, you can change your settings so that you will be warned each time a cookie is being sent, or so that cookies will be turned off. With cookies blocked, some functions of the Site may not operate properly.';
        }
        if ($privacy_cookies == 'pri_YES') {
            $var .= '<br/><br/><b>Usernames, Passwords, and Profiles</b>

        If prompted, Users must provide a valid email address to the Site, at which the User can receive messages. User must also update the Site if that email address changes. The Site reserves the right to terminate any User account if a valid email is requested but is not provided by the User.
        If the Site prompts or allows a User to create a username or profile, Users agree not to pick a username or provide any profile information that would impersonate someone or that is likely to cause confusion with any other person or entity.  The Site reserves the right to cancel a User account or change a username or profile data at any time.  Similarly, if the Site prompts or allows a User to create an avatar or upload a picture, User agrees not to use any image that impersonates some other person or entity, or that is otherwise likely to cause confusion.
        You are responsible for protecting your username and password for the Site, and you agree not to disclose it to any third party.  We recommend that you use a passwork that is more than eight characters long.  You are responsible for all activity on your account, whether or not you authorized it.';
            if ($privacy_owner_email != '') {
                $var .= 'You agree to inform us of unauthorized use of your account, by email to ' . $privacy_owner_email . '.';
            }
            $var .= ' You acknowledge that if you wish to protect your interactions the Site, it is your responsibility to use a secure encrypted connection, virtual private network, or other appropriate measures.';
        }
        if ($privacy_owner_loc != '') {
            $var .= '<br/><br/><b>Disputes</b>

        We are based in ' . $privacy_owner_loc . ' and you are contracting to use our Site.  This Policy and all matters arising from your use of the Site are governed by and will be construed according to the laws of ' . $privacy_owner_loc . ', without regard to any choice of laws rules of any jurisdiction.  The federal courts and state courts that have geographical jurisdiction over disputes arising at our office location in ' . $privacy_owner_loc . ' will be the only permissible venues for any and all disputes arising out of or in connection with this Policy or the Site and Service.';
        }
        if ($privacy_cookies == 'pri_YES') {
            $var .= '<br/><br/><b>ARBITRATION</b>

        Notwithstanding anything that may be contrary within the “Disputes” provisions above, all matters, and all claims within a multi-claim matter, that are arbitrable, including all claims for monetary damages, shall be decided by a single arbitrator to be selected by us';
            if ($privacy_owner_loc != '') {
                $var .= ', who shall hold hearings in or near ' . $privacy_owner_loc;
            }
            $var .= ', under the rules that apply.';
        }
        if ($privacy_child != 'pri_YES') {
            $var .= '<br/><b>COPPA (Children Online Privacy Protection Act)</b>

        When it comes to the collection of personal information from children under the age of 13 years old, the Children s Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, United States consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect childrens privacy and safety online.
        We do not specifically market to children under the age of 13 years old.';
        }
        $var .= '<br/><br/><b>Fair Information Practicess</b>
        
        The Fair Information Practices Principles form the backbone of privacy law in the United States and the concepts they include have played a significant role in the development of data protection laws around the globe. Understanding the Fair Information Practice Principles and how they should be implemented is critical to comply with the various privacy laws that protect personal information.';
        
        $var .= '<br/><br/><b>Changes to the Site and the Services</b>

        The owners and contributors to the Site will work to improve the Site for our users, and to further our business interests in the Site. We reserve the right to add, change, and remove features, content, and data, including the right to add or change any pricing terms.  You agree that we will not be liable for any such changes.  Neither your use of the Site nor these terms give you any right, title, or protectable legal interest in the Site or its content.
        We reserve the right, at its sole discretion, to modify or replace any part of this Privacy Policy. It is your responsibility to check this Privacy Policy periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Privacy Policy constitutes acceptance of those changes.';
        
        if ($privacy_owner_email != '') {
            $var .= '<br/><br/><b>Terms Contact</b>

        If you have any questions about these Terms, please address them to ' . $privacy_owner_email . '.
        ';
        }
        $var .= '<br/><br/><b>Last Updated</b>

        These terms were last updated on *' . date('Y-m-d H:i:s', current_time('timestamp', 0)) . '*';
        
        if (!$the_page) {
            
            // Create post object
            $_p               = array();
            $_p['post_title'] = $the_page_title;
            
            $_p['post_content']   = $var;
            $_p['post_status']    = 'publish';
            $_p['post_type']      = 'page';
            $_p['comment_status'] = 'closed';
            $_p['ping_status']    = 'closed';
            $_p['post_category']  = array(
                1
            ); // the default 'Uncatrgorised'
            
            // Insert the post into the database
            $the_page_id = wp_insert_post($_p);
            
        } else {
            
            //make sure the page is not trashed...
            $the_page->post_content = $var;
            $the_page->post_status  = 'publish';
            $the_page_id            = wp_update_post($the_page);
            
        }
        
        delete_option('privacy_policy_id');
        add_option('privacy_policy_id', $the_page_id);
    } else {
        legalize_my_plugin_remove();
    }
}

function legalize_my_plugin_remove()
{
    
    global $wpdb;
    //  the id of our page...
    $the_page_id = get_option('privacy_policy_id');
    if ($the_page_id) {
        
        wp_delete_post($the_page_id, true);
        
    }
    delete_option("privacy_policy_id");
    
}
function legalize_fortune_ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array(
        "name",
        "\n",
        "\t",
        " ",
        "-",
        "_"
    ), NULL, strtolower(trim($purpose)));
    $support    = array(
        "country",
        "countrycode",
        "state",
        "region",
        "city",
        "location",
        "address"
    );
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array(
                        $ipdat->geoplugin_countryName
                    );
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

function legalize_fortune_is_in_EU()
{
    $europe = array(
        'AD',
        'AL',
        'AT',
        'AX',
        'BA',
        'BE',
        'BG',
        'BY',
        'CH',
        'CZ',
        'DE',
        'DK',
        'EE',
        'ES',
        'FI',
        'FO',
        'FR',
        'GB',
        'GG',
        'GI',
        'GR',
        'HR',
        'HU',
        'IE',
        'IM',
        'IS',
        'IT',
        'JE',
        'LI',
        'LT',
        'LU',
        'LV',
        'MC',
        'MD',
        'ME',
        'MK',
        'MT',
        'NL',
        'NO',
        'PL',
        'PT',
        'RO',
        'RS',
        'RU',
        'SE',
        'SI',
        'SJ',
        'SK',
        'SM',
        'UA',
        'UK',
        'VA'
    );
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $real_ip_adress = $_SERVER['REMOTE_ADDR'];
        }
    }
    
    $cip          = $real_ip_adress;
    $country_code = legalize_fortune_ip_info($real_ip_adress, "Country Code");
    if ($country_code === NULL) {
        return true;
    }
    if (in_array($country_code, $europe)) {
        return true;
    } else {
        return false;
    }
}
add_action('admin_enqueue_scripts', 'privacy_load_admin_things');
add_filter("plugin_action_links_$plugin", 'privacy_add_settings_link');
add_action('admin_init', 'privacy_register_mysettings');
function privacy_register_mysettings()
{
    register_setting('privacy_option_group', 'privacy_Main_Settings');
    register_setting('privacy_option_group2', 'privacy_Terms_Settings');
    register_setting('fortune_option_group2', 'legalize_fortune_Main_Settings');
}

add_action('wp_footer', 'privacy_popup_footer_content');
function privacy_popup_footer_content()
{
    $privacy_Main_Settings = get_option('privacy_Main_Settings', false);
?><script type="text/javascript">
        var $privacy_Main_Settings = JSON.parse('<?php
    echo json_encode($privacy_Main_Settings);
?>');
        </script><?php
}
add_action('admin_enqueue_scripts', 'privacy_admin_load_files');
function privacy_admin_load_files()
{
    wp_register_style('privacy-popup-style', plugins_url('styles/legalize-privacy.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('privacy-popup-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('privacy-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('privacy-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('privacy-settings-app', plugins_url('res/privacy-angular.js', __FILE__), array(), '1.0.0', true);
}
function legalize_fortune_get_plugin_url()
{
    return plugins_url('', __FILE__);
}
function legalize_fortune_get_file_url($url)
{
    return legalize_fortune_get_plugin_url() . '/' . $url;
}

add_action('template_redirect', 'legalize_fortune_add_browser_popup_panel');
function legalize_fortune_add_browser_popup_panel()
{
    $fortune_Main_Settings                      = get_option('legalize_fortune_Main_Settings', false);
    $fortune_Main_Settings['fortune_font_type'] = str_replace('"', "", $fortune_Main_Settings['fortune_font_type']);
    update_option('legalize_fortune_Main_Settings', $fortune_Main_Settings);
    $fortune_dnt_check = $fortune_Main_Settings['fortune_dnt_check'];
    $cookie_val = $_COOKIE['fortune_show'];
    if ($cookie_val === '1') {
        $GLOBALS['COOKIE_SET'] = 'true';
    }
    if($fortune_dnt_check === 'on')
    {
        if(isset($_SERVER['HTTP_DNT']) && $_SERVER['HTTP_DNT'] == 1)
        {
            $GLOBALS['dntEnabled'] = true;
        }
    }

    $fortune_popup_once             = $fortune_Main_Settings['fortune_popup_once'];
    $fortune_message                = $fortune_Main_Settings['fortune_message'];
    $fortune_close_message          = $fortune_Main_Settings['fortune_close_message'];
    $fortune_more_info              = $fortune_Main_Settings['fortune_more_info'];
    $fortune_more_link              = $fortune_Main_Settings['fortune_more_link'];
    $fortune_popup_background       = $fortune_Main_Settings['fortune_popup_background'];
    $fortune_popup_text_col         = $fortune_Main_Settings['fortune_popup_text_col'];
    $fortune_popup_links_col        = $fortune_Main_Settings['fortune_popup_links_col'];
    $fortune_panel_sticks           = $fortune_Main_Settings['fortune_panel_sticks'];
    $fortune_more_link_text         = $fortune_Main_Settings['fortune_more_link_text'];
    $fortune_auto_hide_time         = $fortune_Main_Settings['fortune_auto_hide_time'];
    $fortune_auto_hide              = $fortune_Main_Settings['fortune_auto_hide'];
    $fortune_border                 = $fortune_Main_Settings['fortune_border'];
    $fortune_border_color           = $fortune_Main_Settings['fortune_border_color'];
    $fortune_border_width           = $fortune_Main_Settings['fortune_border_width'];
    $fortune_buttons                = $fortune_Main_Settings['fortune_buttons'];
    $fortune_popup_animation        = $fortune_Main_Settings['fortune_popup_animation'];
    $fortune_max_width              = $fortune_Main_Settings['fortune_max_width'];
    $fortune_fade_background        = $fortune_Main_Settings['fortune_fade_background'];
    $fortune_only_eu                = $fortune_Main_Settings['fortune_only_eu'];
    $fortune_block_cookies          = $fortune_Main_Settings['fortune_block_cookies'];
    $fortune_blocked_content        = $fortune_Main_Settings['fortune_blocked_content'];
    $fortune_deny_button            = $fortune_Main_Settings['fortune_deny_button'];
    $fortune_deny_button_text       = $fortune_Main_Settings['fortune_deny_button_text'];
    $fortune_block_all_cookies      = $fortune_Main_Settings['fortune_block_all_cookies'];
    $fortune_disable_loggedin       = $fortune_Main_Settings['fortune_disable_loggedin'];
    $fortune_custom_css             = $fortune_Main_Settings['fortune_custom_css'];
    $fortune_rounded_corners        = $fortune_Main_Settings['fortune_rounded_corners'];
    $fortune_distance_top           = $fortune_Main_Settings['fortune_distance_top'];
    $fortune_distance_bottom        = $fortune_Main_Settings['fortune_distance_bottom'];
    $fortune_distance_left          = $fortune_Main_Settings['fortune_distance_left'];
    $fortune_distance_right         = $fortune_Main_Settings['fortune_distance_right'];
    $fortune_padding                = $fortune_Main_Settings['fortune_padding'];
    $fortune_new_line               = $fortune_Main_Settings['fortune_new_line'];
    $fortune_auto_accept            = $fortune_Main_Settings['fortune_auto_accept'];
    $fortune_outside_close_accept   = $fortune_Main_Settings['fortune_outside_close_accept'];
    $fortune_outside_close          = $fortune_Main_Settings['fortune_outside_close'];
    $fortune_center_popup           = $fortune_Main_Settings['fortune_center_popup'];
    $fortune_popup_style            = $fortune_Main_Settings['fortune_popup_style'];
    $fortune_new_line_all           = $fortune_Main_Settings['fortune_new_line_all'];
    $fortune_popup_background_style = $fortune_Main_Settings['fortune_popup_background_style'];
    $fortune_popup_background_image = $fortune_Main_Settings['fortune_popup_background_image'];
    $fortune_max_height             = $fortune_Main_Settings['fortune_max_height'];
    $fortune_font_size              = $fortune_Main_Settings['fortune_font_size'];
    $fortune_font_type              = $fortune_Main_Settings['fortune_font_type'];
    $fortune_button_background      = $fortune_Main_Settings['fortune_button_background'];
    $fortune_cookie_exp             = $fortune_Main_Settings['fortune_cookie_exp'];
    $fortune_button_border          = $fortune_Main_Settings['fortune_button_border'];
    $fortune_fonts_bold             = $fortune_Main_Settings['fortune_fonts_bold'];
    $fortune_fonts_italic           = $fortune_Main_Settings['fortune_fonts_italic'];
    $fortune_fonts_underline        = $fortune_Main_Settings['fortune_fonts_underline'];
    if ($fortune_blocked_content === 'on' && $GLOBALS['COOKIE_SET'] !== 'true') {
        add_shortcode("legalize_fortune_blocked_no_cookies", "legalize_fortune_blocked_no_cookies");
    } else {
        add_shortcode("legalize_fortune_blocked_cookies", "legalize_fortune_blocked_cookies");
    }
    if (isset($fortune_Main_Settings['fortune_enabled']) && $fortune_Main_Settings['fortune_enabled'] == 'on') {
        if ($fortune_disable_loggedin === 'on' && is_user_logged_in()) {
            return;
        }
        if ($fortune_only_eu === 'on' && legalize_fortune_is_in_EU() === false) {
            return;
        }
        if (($fortune_block_all_cookies === 'on' || ($fortune_block_cookies === 'on' && $GLOBALS['COOKIE_SET'] !== 'true')) && headers_sent() === FALSE) {
            $dirty = false;
            foreach (headers_list() as $header) {
                if ($dirty)
                    continue;
                if (preg_match('/Set-Cookie/', $header))
                    $dirty = true;
            }
            if ($dirty) {
                $phpversion = explode('.', phpversion());
                if ($phpversion[0] > 5 || ($phpversion[0] === 5 && $phpversion[1] >= 3)) {
                    header_remove('Set-Cookie');
                } else {
                    header('Set-Cookie:');
                }
            }
            wp_register_script('legalize_fortune_enque_no_kuki_script', legalize_fortune_get_file_url('res/no_cookies.js'), array(
                'jquery'
            ));
            wp_enqueue_script('legalize_fortune_enque_no_kuki_script');
        }
        wp_register_style('legalize_fortune_enque_style', legalize_fortune_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
        wp_enqueue_style('legalize_fortune_enque_style');
        wp_register_script('legalize_fortune_enque_script', legalize_fortune_get_file_url('res/notification.js'), array(
            'jquery'
        ));
        wp_enqueue_script('legalize_fortune_enque_script');
        $settings = array(
            'use_cookies' => $fortune_popup_once,
            'stick' => $fortune_panel_sticks,
            'message' => $fortune_message,
            'close_message' => $fortune_close_message,
            'more_info' => $fortune_more_info,
            'more_link' => $fortune_more_link,
            'background' => $fortune_popup_background,
            'text_col' => $fortune_popup_text_col,
            'links_col' => $fortune_popup_links_col,
            'more_info_text' => $fortune_more_link_text,
            'auto_hide' => $fortune_auto_hide,
            'auto_hide_time' => $fortune_auto_hide_time,
            'border' => $fortune_border,
            'border_color' => $fortune_border_color,
            'border_width' => $fortune_border_width,
            'buttons' => $fortune_buttons,
            'animation' => $fortune_popup_animation,
            'max_width' => $fortune_max_width,
            'fade_background' => $fortune_fade_background,
            'deny_button' => $fortune_deny_button,
            'deny_text' => $fortune_deny_button_text,
            'custom_css' => $fortune_custom_css,
            'rounded_corners' => $fortune_rounded_corners,
            'dist_top' => $fortune_distance_top,
            'dist_bot' => $fortune_distance_bottom,
            'dist_right' => $fortune_distance_right,
            'dist_left' => $fortune_distance_left,
            'dist_padding' => $fortune_padding,
            'new_line' => $fortune_new_line,
            'auto_accept' => $fortune_auto_accept,
            'outside_close' => $fortune_outside_close,
            'outside_accept' => $fortune_outside_close_accept,
            'block_all_cookies' => $fortune_block_all_cookies,
            'center_popup' => $fortune_center_popup,
            'popup_style' => $fortune_popup_style,
            'new_line_all' => $fortune_new_line_all,
            'background_style' => $fortune_popup_background_style,
            'background_image' => $fortune_popup_background_image,
            'max_height' => $fortune_max_height,
            'font_size' => $fortune_font_size,
            'font_type' => $fortune_font_type,
            'button_background' => $fortune_button_background,
            'cookie_exp' => $fortune_cookie_exp,
            'block_cookies' => $fortune_block_cookies,
            'button_border' => $fortune_button_border,
            'font_bold' => $fortune_fonts_bold,
            'font_italic' => $fortune_fonts_italic,
            'font_underline' => $fortune_fonts_underline
        );
        wp_localize_script('legalize_fortune_enque_script', 'settings', $settings);
    }
}
require(dirname(__FILE__) . "/res/fortune-main.php");
require(dirname(__FILE__) . "/res/privacy-main.php");
require(dirname(__FILE__) . "/res/terms-main.php");
require(dirname(__FILE__) . "/res/privacy-publish.php");
?>