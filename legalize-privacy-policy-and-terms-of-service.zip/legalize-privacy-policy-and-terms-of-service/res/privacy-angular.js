angular.module('prisettingsApp', ['ngSanitize'])
.controller('prisettingsController', function($scope) {
    $scope.settings = privacy_admin_json;
});