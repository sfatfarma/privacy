<?php

function privacy_terms_settings()
{
?>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('privacy_option_group2');
    do_settings_sections('privacy_option_group2');
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    if (isset($privacy_Terms_Settings['terms_enabled'])) {
        $terms_enabled = $privacy_Terms_Settings['terms_enabled'];
    } else {
        $terms_enabled = '';
    }
    if (isset($privacy_Terms_Settings['privacy_owner_name'])) {
        $privacy_owner_name = $privacy_Terms_Settings['privacy_owner_name'];
    } else {
        $privacy_owner_name = '';
    }
    if (isset($privacy_Terms_Settings['privacy_owner_type'])) {
        $privacy_owner_type = $privacy_Terms_Settings['privacy_owner_type'];
    } else {
        $privacy_owner_type = 'Individual';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca'])) {
        $privacy_dmca = $privacy_Terms_Settings['privacy_dmca'];
    } else {
        $privacy_dmca = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_address'])) {
        $privacy_dmca_address = $privacy_Terms_Settings['privacy_dmca_address'];
    } else {
        $privacy_dmca_address = '';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_phone'])) {
        $privacy_dmca_phone = $privacy_Terms_Settings['privacy_dmca_phone'];
    } else {
        $privacy_dmca_phone = '';
    }
    if (isset($privacy_Terms_Settings['privacy_dmca_email'])) {
        $privacy_dmca_email = $privacy_Terms_Settings['privacy_dmca_email'];
    } else {
        $privacy_dmca_email = '';
    }
    if (isset($privacy_Terms_Settings['terms_owner_email_address'])) {
        $terms_owner_email_address = $privacy_Terms_Settings['terms_owner_email_address'];
    } else {
        $terms_owner_email_address = '';
    }
    if (isset($privacy_Terms_Settings['terms_owner_locality'])) {
        $terms_owner_locality = $privacy_Terms_Settings['terms_owner_locality'];
    } else {
        $terms_owner_locality = '';
    }
    if (isset($privacy_Terms_Settings['terms_ads'])) {
        $terms_ads = $privacy_Terms_Settings['terms_ads'];
    } else {
        $terms_ads = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_major'])) {
        $terms_major = $privacy_Terms_Settings['terms_major'];
    } else {
        $terms_major = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_arbitration'])) {
        $terms_arbitration = $privacy_Terms_Settings['terms_arbitration'];
    } else {
        $terms_arbitration = 'pri_YES';
    }
    if (isset($privacy_Terms_Settings['terms_added_text'])) {
        $terms_added_text = $privacy_Terms_Settings['terms_added_text'];
    } else {
        $terms_added_text = '';
    }
    if (isset($privacy_Terms_Settings['language'])) {
        $language = $privacy_Terms_Settings['language'];
    } else {
        $language = '';
    }
?>
<script>
                var privacy_admin_json = {
                    privacy_owner_name: '<?php
    echo $privacy_owner_name;
?>', 
                    privacy_owner_type: '<?php
    echo $privacy_owner_type;
?>', 
                    privacy_dmca: '<?php
    echo $privacy_dmca;
?>', 
                    privacy_dmca_address: '<?php
    echo $privacy_dmca_address;
?>', 
                    privacy_dmca_phone: '<?php
    echo $privacy_dmca_phone;
?>', 
                    privacy_dmca_email: '<?php
    echo $privacy_dmca_email;
?>', 
                    terms_owner_email_address: '<?php
    echo $terms_owner_email_address;
?>', 
                    terms_owner_locality: '<?php
    echo $terms_owner_locality;
?>', 
                    terms_ads: '<?php
    echo $terms_ads;
?>', 
                    terms_major: '<?php
    echo $terms_major;
?>',
                    terms_arbitration: '<?php
    echo $terms_arbitration;
?>',
                    terms_added_text: '<?php
    echo str_replace(["\r\n", "\r", "\n"], "<br/>", $terms_added_text);
?>',
                    language: '<?php
    echo $language;
?>'
}
            </script>
            <script type="text/javascript">
    window.onload = mainChanged;
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".hideMain").show();
        else
            jQuery(".hideMain").hide();
        if(jQuery('.dmcaEnable').is(":checked"))   
            jQuery(".dmcaHideMe").show();
        else
            jQuery(".dmcaHideMe").hide();
    }
    
    </script>

<div ng-app="prisettingsApp" ng-controller="prisettingsController" ng-cloak ng-init="initialized()">
    <div>
    <?php
    $the_page_id = get_option('terms_policy_id');
?>
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Terms of Service Generator:</b>&nbsp;&nbsp;&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Terms of Service page generation.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="terms_enabled" name="privacy_Terms_Settings[terms_enabled]" onchange="mainChanged()" <?php
    if ($terms_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="terms_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Terms of Service Page Language:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the language of your Terms of Service Page. If you require further languages, e-mail me please at: kisded@yahoo.com.";
?>
                                        </div>
                                    </div>
                                </div>
                                </td><td>
                                <select name="privacy_Terms_Settings[language]" style="width:100px;max-width:180px;">
                                  <option value="English"<?php if($language == "English"){echo " selected";}?>>English</option>
                                  <option value="German"<?php if($language == "German"){echo " selected";}?>>German</option>
                                </select>
                            </div>
                        </div>
                        </td></tr><tr><td>
                    <span class="gs-sub-heading">Does This Website have Arbitration?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Terms_Settings[terms_arbitration]" value="pri_YES"
                            id="radio_seoi_yes12" ng-model="settings.terms_arbitration"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Terms_Settings[terms_arbitration]" value="pri_NO" 
                            id="radio_seoi_no23" ng-model="settings.terms_arbitration"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Do you want to require all of the site's users to arbitrate (rather than litigate) any claims against the site?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this Website contain advertising?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Terms_Settings[terms_ads]" value="pri_YES"
                            id="radio_seoi_yes13" ng-model="settings.terms_ads"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Terms_Settings[terms_ads]" value="pri_NO" 
                            id="radio_seoi_no22" ng-model="settings.terms_ads"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Does this website use any sort of advertising?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this Website allow Visitor under 18 years?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Terms_Settings[terms_major]" value="pri_YES"
                            id="radio_seoi_yes13" ng-model="settings.terms_major"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Terms_Settings[terms_major]" value="pri_NO" 
                            id="radio_seoi_no22" ng-model="settings.terms_major"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Does this website allow visitors under 18 years of age?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        
                        <span class="gs-sub-heading">Website has an DMCA Agent?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Terms_Settings[privacy_dmca]" value="pri_YES"
                            id="radio_seoi_yes1" class="dmcaEnable" ng-model="settings.privacy_dmca" onchange="mainChanged()"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Terms_Settings[privacy_dmca]" value="pri_NO" 
                            id="radio_seoi_no2" ng-model="settings.privacy_dmca" onchange="mainChanged()"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "In the U.S., safe harbor protection from copyright liability for site content added by your users can be had by designating and registering with the Copyright Office a Digital Millenium Copyright Act agent for notice and takedown procedures. Will this site have a designated DMCA agent?";
?>
                                </div>
                            </div>
                        </td></tr></table>
                        <div class="dmcaHideMe">
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    DMCA Agent's Address:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here you should enter the postal mailing address of your DMCA agent";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="text" name="privacy_Terms_Settings[privacy_dmca_address]" ng-model="settings.privacy_dmca_address" ng-trim="false" size="68" placeholder="Insert DMCA Agent Adress" >
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    DMCA Agent's Phone:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here you should enter the telephone number of your DMCA agent";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="text" name="privacy_Terms_Settings[privacy_dmca_phone]" ng-model="settings.privacy_dmca_phone" ng-trim="false" size="68" placeholder="Insert DMCA Agent Phone Number">
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    DMCA Agent's E-mail:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here you should enter the e-mail address of your DMCA agent";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="email" name="privacy_Terms_Settings[privacy_dmca_email]" ng-model="settings.privacy_dmca_email" ng-trim="false" size="68" placeholder="Insert DMCA Agent E-mail Adress">
                            </div>
                        </div>
                        </div>                
                    <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Physical Locality of the Website:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the legal physical locality for the site. (i.e. City, State/Provence)";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="text" name="privacy_Terms_Settings[terms_owner_locality]" ng-model="settings.terms_owner_locality" ng-trim="false" size="68" placeholder="Insert Wner's Locality">
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Website Owner E-mail Adress:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "What is the contact e-mail of the site owner or responsible legal party?";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="email" name="privacy_Terms_Settings[terms_owner_email_address]" ng-model="settings.terms_owner_email_address" ng-trim="false" size="68" placeholder="Insert Owner's e-mail address">
                            </div>
                        </div>    
                    <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Website Owner's name:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "What is the name of the website's owner or the website's responsible legal party?";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="text" name="privacy_Terms_Settings[privacy_owner_name]" ng-model="settings.privacy_owner_name" ng-trim="false" size="68" placeholder="Insert owner's name">
                            </div>
                        </div>
                        <div>
        Website Owner's Entity Type:
        <select name="privacy_Terms_Settings[privacy_owner_type]" ng-model="settings.privacy_owner_type" style="width:255px;">
          <option value="Individual">Individual</option>
          <option value="Corporation">Corporation</option>
          <option value="Limited Liability Company (LLC)">Limited Liability Company (LLC)</option>
          <option value="Partnership">Partnership</option>
          <option value="Sole Proprietor">Sole Proprietor</option>
        </select>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Is the owner an Individual Person, a Corporation, a Limited Liability Company, a Partnership or a Sole Proprietor?";
?>
                        </div>
                    </div>
        </div>
        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Terms of Service Custom Text:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input here your custom text that you wish to append at the end of the Terms of Service Page. Leave this field blank to disable this feature. HTML code is also accepted.";
?>
                                        </div>
                                    </div>
                                </div>
                                <textarea rows="4" cols="70" name="privacy_Terms_Settings[terms_added_text]" ng-model="settings.terms_added_text"></textarea>
                            </div>
                        </div>
        <hr/>
                    <a href="admin.php?page=privacy_publish">After you saved your changes, you must publish your Terms of Service page for your changes to go live! Click here after you saved your changes!</a>
                    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div></div><?php
}
?>