<?php

function privacy_admin_settings()
{
?>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('privacy_option_group');
    do_settings_sections('privacy_option_group');
    $privacy_Main_Settings = get_option('privacy_Main_Settings', false);
    if (isset($privacy_Main_Settings['privacy_collect_data'])) {
        $privacy_collect_data = $privacy_Main_Settings['privacy_collect_data'];
    } else {
        $privacy_collect_data = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_enabled'])) {
        $privacy_enabled = $privacy_Main_Settings['privacy_enabled'];
    } else {
        $privacy_enabled = '';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_partners'])) {
        $privacy_share_data_partners = $privacy_Main_Settings['privacy_share_data_partners'];
    } else {
        $privacy_share_data_partners = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_ads'])) {
        $privacy_share_data_ads = $privacy_Main_Settings['privacy_share_data_ads'];
    } else {
        $privacy_share_data_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_unlimited'])) {
        $privacy_share_data_unlimited = $privacy_Main_Settings['privacy_share_data_unlimited'];
    } else {
        $privacy_share_data_unlimited = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data_agr'])) {
        $privacy_share_data_agr = $privacy_Main_Settings['privacy_share_data_agr'];
    } else {
        $privacy_share_data_agr = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_share_data'])) {
        $privacy_share_data = $privacy_Main_Settings['privacy_share_data'];
    } else {
        $privacy_share_data = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_california'])) {
        $privacy_california = $privacy_Main_Settings['privacy_california'];
    } else {
        $privacy_california = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ssl'])) {
        $privacy_ssl = $privacy_Main_Settings['privacy_ssl'];
    } else {
        $privacy_ssl = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_ads'])) {
        $privacy_ads = $privacy_Main_Settings['privacy_ads'];
    } else {
        $privacy_ads = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_adsense'])) {
        $privacy_adsense = $privacy_Main_Settings['privacy_adsense'];
    } else {
        $privacy_adsense = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_cookies'])) {
        $privacy_cookies = $privacy_Main_Settings['privacy_cookies'];
    } else {
        $privacy_cookies = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_pass'])) {
        $privacy_pass = $privacy_Main_Settings['privacy_pass'];
    } else {
        $privacy_pass = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_arb'])) {
        $privacy_arb = $privacy_Main_Settings['privacy_arb'];
    } else {
        $privacy_arb = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_child'])) {
        $privacy_child = $privacy_Main_Settings['privacy_child'];
    } else {
        $privacy_child = 'pri_YES';
    }
    if (isset($privacy_Main_Settings['privacy_added_text'])) {
        $privacy_added_text = $privacy_Main_Settings['privacy_added_text'];
    } else {
        $privacy_added_text = '';
    }
    if (isset($privacy_Main_Settings['privacy_owner_loc'])) {
        $privacy_owner_loc = $privacy_Main_Settings['privacy_owner_loc'];
    } else {
        $privacy_owner_loc = '';
    }
    if (isset($privacy_Main_Settings['privacy_owner_email'])) {
        $privacy_owner_email = $privacy_Main_Settings['privacy_owner_email'];
    } else {
        $privacy_owner_email = '';
    }
    if (isset($privacy_Main_Settings['privacy_email'])) {
        $privacy_email = $privacy_Main_Settings['privacy_email'];
    } else {
        $privacy_email = '';
    }
    if (isset($privacy_Main_Settings['privacy_mail'])) {
        $privacy_mail = $privacy_Main_Settings['privacy_mail'];
    } else {
        $privacy_mail = '';
    }
    if (isset($privacy_Main_Settings['language'])) {
        $language = $privacy_Main_Settings['language'];
    } else {
        $language = '';
    }
?>
<script>
                var privacy_admin_json = {
                    privacy_collect_data: '<?php
    echo $privacy_collect_data;
?>',
                    privacy_share_data: '<?php
    echo $privacy_share_data;
?>',
                    privacy_share_data_partners: '<?php
    echo $privacy_share_data_partners;
?>',
                    privacy_share_data_ads: '<?php
    echo $privacy_share_data_ads;
?>',
                    privacy_share_data_unlimited: '<?php
    echo $privacy_share_data_unlimited;
?>',
                    privacy_share_data_agr: '<?php
    echo $privacy_share_data_agr;
?>',
                    privacy_california: '<?php
    echo $privacy_california;
?>',
                    privacy_email: '<?php
    echo $privacy_email;
?>',
                    privacy_mail: '<?php
    echo $privacy_mail;
?>',
                    privacy_ssl: '<?php
    echo $privacy_ssl;
?>',
                    privacy_ads: '<?php
    echo $privacy_ads;
?>',
                    privacy_adsense: '<?php
    echo $privacy_adsense;
?>',
                    privacy_cookies: '<?php
    echo $privacy_cookies;
?>',
                    privacy_pass: '<?php
    echo $privacy_pass;
?>',
                    privacy_owner_loc: '<?php
    echo $privacy_owner_loc;
?>',
                    privacy_owner_email: '<?php
    echo $privacy_owner_email;
?>',
                    privacy_arb: '<?php
    echo $privacy_arb;
?>',
                    privacy_child: '<?php
    echo $privacy_child;
?>',
                    privacy_added_text: '<?php
    echo str_replace(["\r\n", "\r", "\n"], "<br/>", $privacy_added_text);
?>',
                    language: '<?php
    echo $language;
?>'
}
            </script>
<script type="text/javascript">
    window.onload = mainChanged;
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))   
            jQuery(".hideMain").show();
        else
            jQuery(".hideMain").hide();
        if(jQuery('.california_dream').is(":checked"))   
            jQuery(".privHide").show();
        else
            jQuery(".privHide").hide();
    }
    
    </script>
            <?php
    $the_page_id = get_option('privacy_policy_id');
?>
<div ng-app="prisettingsApp" ng-controller="prisettingsController" ng-cloak ng-init="initialized()">
<div>
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Privacy Policy Generator:</b>&nbsp;&nbsp;&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Privacy Policy page generation.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="privacy_enabled" name="privacy_Main_Settings[privacy_enabled]" onchange="mainChanged()" <?php
    if ($privacy_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="privacy_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Privacy Policy Page Language:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the language of your Privacy policy Page. If you require further languages, e-mail me please at: kisded@yahoo.com.";
?>
                                        </div>
                                    </div>
                                </div>
                                </td><td>
                                <select name="privacy_Main_Settings[language]" style="width:100px;max-width:180px;">
                                  <option value="English"<?php if($language == "English"){echo " selected";}?>>English</option>
                                  <option value="German"<?php if($language == "German"){echo " selected";}?>>German</option>
                                </select>
                            </div>
                        </div>
                        </td></tr><tr><td>
<span class="gs-sub-heading">This website Collects User Data:&nbsp;&nbsp;&nbsp;</span></td><td>
                        
                        <label><input type="radio" name="privacy_Main_Settings[privacy_collect_data]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_collect_data"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_collect_data]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_collect_data"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Does this website collect user data from it's users?";
?>
                                </div>
                            </div>
                            </td></tr><tr>
                            <td>
                        <span class="gs-sub-heading">This website Shares User Data:&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_share_data"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_share_data"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will any of the user data (individual data or aggregate data) be shared outside of the site owner itself?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">This website Shares User Data with Partners:&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_partners]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_share_data_partners"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_partners]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_share_data_partners"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will any user data be shared with those who help the site owner operate and manage the site?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">This website Shares User Data with Advertisers:&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_ads]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_share_data_ads"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_ads]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_share_data_ads"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will any user data be shared with advertisers or marketing partners?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">This website Shares User Data with Other Peers:&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_unlimited]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_share_data_unlimited"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_unlimited]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_share_data_unlimited"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will any user data be shared with others other than those who help operate and manage the site, and other than advertisers or marketing partners?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">This website Shares User Data Only Grouped:&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_agr]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_share_data_agr"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_share_data_agr]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_share_data_agr"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will all user data be shared only in grouped form, so that individual users are not identified and individual user data is not shared?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        
                        <span class="gs-sub-heading">Does this website use SSL?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_ssl]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_ssl"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_ssl]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_ssl"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Does this site use SSL? Does this website use HTTPS? (https://)";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this website use 3rd party advertising?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_ads]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_ads"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_ads]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_ads"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will this site use a 3rd party network to provide advertising?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this website use Google AdSense?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_adsense]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_adsense"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_adsense]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_adsense"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will this site use Google AdSense to provide advertising?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this website use Cookies?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_cookies]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_cookies"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_cookies]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_cookies"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will this site use cookies (apart from cookies that the site has as part of advertising tools like Google Analytics)?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this website use Any kind of Passwords?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_pass]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_pass"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_pass]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_pass"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will any part of this site require a password for access? Will the user be prompted for an user account on this website?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Do you require Arbitration?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_arb]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_arb"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_arb]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_arb"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Do you want to require all of the site's users to arbitrate (rather than litigate) any claims against the site?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Does this website Target as an Audience Children Under 13 years?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="privacy_Main_Settings[privacy_child]" value="pri_YES"
                            id="radio_seoi_yes" ng-model="settings.privacy_child"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_child]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_child"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Will this site target as it's users, children under the age of 13?";
?>
                                </div>
                            </div>
                        </td></tr><tr><td>
                        <span class="gs-sub-heading">Is this website located in the state of California?&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" class="california_dream" name="privacy_Main_Settings[privacy_california]" value="pri_YES"
                            id="california_dream" ng-model="settings.privacy_california" onchange="mainChanged()"> YES</label>&nbsp; 
                        <label><input type="radio" name="privacy_Main_Settings[privacy_california]" value="pri_NO" 
                            id="radio_seoi_no" ng-model="settings.privacy_california" onchange="mainChanged()"> NO</label>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                <div class="bws_hidden_help_text" style="min-width: 260px;">
                                   <?php
    echo "Is site's locality within the state of California? If it is, it must comply to the California Online Privacy Protection Act (CalOPPA)";
?>
                                </div>
                            </div>
                        </td><td></tr></table>
                        <div class="privHide">
                            <div class="gs_radio_related_row">
                                <div class="gs_radio_related_cell">
                                    <div>
                                        CalOPPA Privacy Contact e-mail:
                                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                            <div class="bws_hidden_help_text" style="min-width: 260px;">
                                                <?php
    echo "What is the contact e-mail for privacy matters (California)?";
?>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="email" name="privacy_Main_Settings[privacy_email]" ng-model="settings.privacy_email" ng-trim="false" size="68" placeholder="Insert contact e-mail address">
                                </div>
                            </div>
                            <div class="gs_radio_related_row">
                                <div class="gs_radio_related_cell">
                                    <div>
                                        CalOPPA Privacy Contact Adress:
                                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                            <div class="bws_hidden_help_text" style="min-width: 260px;">
                                                <?php
    echo "What is the physical mailing address for privacy matters (California)?";
?>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="text" name="privacy_Main_Settings[privacy_mail]" ng-model="settings.privacy_mail" ng-trim="false" size="68" placeholder="Insert contact mailing address">
                                </div>
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Website's Owner locality:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the legal physical locality for the site. (i.e. City, State/Provence)";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="text" name="privacy_Main_Settings[privacy_owner_loc]" ng-model="settings.privacy_owner_loc" ng-trim="false" size="68" placeholder="Insert owner locality">
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Website Owner's e-mail:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "What is the contact email of the site owner or responsible legal party?";
?>
                                        </div>
                                    </div>
                                </div>
                                <input type="email" name="privacy_Main_Settings[privacy_owner_email]" ng-model="settings.privacy_owner_email" ng-trim="false" size="68" placeholder="Insert owner e-mail address">
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    Privacy Policy Custom Text:
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input here your custom text that you wish to append at the end of the Privacy Policy Page. Leave this field blank to disable this feature. HTML code is also accepted.";
?>
                                        </div>
                                    </div>
                                </div>
                                <textarea rows="4" cols="70" name="privacy_Main_Settings[privacy_added_text]" ng-model="settings.privacy_added_text"></textarea>
                            </div>
                        </div>
                        <hr/>
        <a href="admin.php?page=privacy_publish">After you saved your changes, you must publish your Privacy Policy page for your changes to go live! Click here after you saved your changes!</a>
        </div>
        </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div><?php
}
?>