<?php

function privacy_publish()
{
?>
<script>
                var privacy_admin_json = {}
            </script>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="admin.php?page=privacy_publish"><?php
    $privacy_Main_Settings  = get_option('privacy_Main_Settings', false);
    $privacy_enabled        = $privacy_Main_Settings['privacy_enabled'];
    $privacy_Terms_Settings = get_option('privacy_Terms_Settings', false);
    $terms_enabled          = $privacy_Terms_Settings['terms_enabled'];
?>
            <script type="text/javascript" >
                        function updatePolicy()
                        {
                            if (confirm("Are you sure you want to publish/update yout Privacy Policy page?") == true) {
                                var data = {
                                    action: 'privacy_my_action'
                                };
                                jQuery.post(ajaxurl, data, function(response) {
                                });
                            } else {
                                return;
                            }
                        }
                        function updateTerms()
                        {
                            if (confirm("Are you sure you want to publish/update yout Terms of Service page?") == true) {
                                var data = {
                                    action: 'terms_my_action'
                                };
                                jQuery.post(ajaxurl, data, function(response) {
                                });
                            } else {
                                return;
                            }
                        }
                        </script>
<div ng-app="prisettingsApp" ng-controller="prisettingsController" ng-cloak ng-init="initialized()">
<hr/>
<div>
                        <img src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/banner.jpg';
?>" alt="Legalize Privacy Policy and Terms of Service Generator">
                    </div>
                    <hr/>
<?php
    if ($privacy_enabled == "on" || $terms_enabled == "on") {
?>
    <b>Available <a href="https://codex.wordpress.org/Shortcode_API" target="_blank">shortcodes:</a></b><br/><br/>
    <?php
        if ($privacy_enabled == "on") {
?>
        <b>[legalize_privacy]</b> - automatically includes a link to your <a href="<?php
            echo get_page_link(get_option('privacy_policy_id'));
?>" target="_blank">"Privacy Policy"</a> page<br/>
        <?php
        }
        if ($terms_enabled == "on") {
?>
        <b>[legalize_terms]</b> - automatically includes a link to your <a href="<?php
            echo get_page_link(get_option('terms_policy_id'));
?>" target="_blank">"Terms of Service"</a> page<br/>
        <?php
        }
?>
    <hr/>
    <table><tr><td>
        <div><p class="submit"><input type="submit" name="btnSubmit2" id="btnSubmit2" class="button button-primary" value="Update Privacy Policy" onclick="updatePolicy()"<?php
        if ($privacy_enabled != "on") {
            echo " disabled title='You must go first to the Privacy Policy Settings page and enable this feature!'";
        }
?>/></p></div></td><td>
        <div><p class="submit"><input type="submit" name="btnSubmit3" id="btnSubmit3" class="button button-primary" value="Update Terms of Service" onclick="updateTerms()"<?php
        if ($terms_enabled != "on") {
            echo " disabled title='You must go first to the Terms of Service Settings page and enable this feature!'";
        }
?>/></p></div></td></tr></table>
<?php
    } else {
        echo "To publish your Privacy Policy page or your Terms of Service page, you must enable them in the plugin settings! Go now to the <a href='admin.php?page=privacy_admin_settings'>Privacy Policy Settings Page</a> or the <a href='admin.php?page=privacy_terms_settings'>Terms of Service Settings Page</a>!";
    }
?>
        </div>
    </form>
</div>
</div><?php
}
?>